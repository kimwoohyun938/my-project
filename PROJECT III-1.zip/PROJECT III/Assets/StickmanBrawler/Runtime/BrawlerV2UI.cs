using System;
using UnityEngine;
using StickmanBrawler.Core;
namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        bool DrawV2Effect(Effect e,Vector2 p,float k,Color c)
        {
            if(e.Shape==Shape.Summon)
            {
                Vector2 body=p;Color tint=Alpha(c,.72f);float s=.65f*k;
                if(e.Tag=="mirror") { Ring(p,k*.85f,Alpha(c,.5f),2);tint=Alpha(Color.white,.55f); }
                if(e.Tag=="puppet")
                {
                    Vector2 anchor=ScreenPoint(world.Players[e.Owner].Pos)+new Vector2(0,-2*k);
                    Line(anchor,p+new Vector2(-s*.3f,0),Alpha(c,.35f),1);
                    Line(anchor,p+new Vector2(s*.3f,0),Alpha(c,.35f),1);
                    Box(new Rect(p.x-s*.23f,p.y-s*.25f,s*.46f,s*.55f),tint);
                }
                Disc(body+new Vector2(0,-s*.7f),s*.22f,tint);
                Line(body-new Vector2(0,s*.45f),body+new Vector2(0,s*.2f),tint,Mathf.Max(2,s*.09f));
                for(int side=-1;side<=1;side+=2)
                {Line(body+new Vector2(0,s*.2f),body+new Vector2(side*s*.3f,s*.8f),tint,3);Line(body-new Vector2(0,s*.2f),body+new Vector2(side*s*.4f,s*.1f),tint,3);}
                if(e.Tag=="phantom"||e.Tag=="phantom-rush")Disc(body,k,Alpha(c,.18f),true);
                Text(new Rect(p.x-65,p.y-k*1.6f,130,20),"P"+(e.Owner+1)+" "+e.Tag.ToUpperInvariant(),9,c,TextAnchor.MiddleCenter);
                Box(new Rect(p.x-18,p.y-k*1.15f,36,3),Panel);
                Box(new Rect(p.x-18,p.y-k*1.15f,36*Mathf.Clamp01(e.Health/(e.Tag=="puppet"?150:e.Tag=="phantom"||e.Tag=="phantom-rush"?40:100)),3),c);
                return true;
            }
            if(e.Tag=="nisemono-blade")
            {
                Vector2 d=new Vector2(e.Vel.x,-e.Vel.y).normalized;
                Color steel=e.Style==0?Color.white:new Color(.07f,.08f,.12f);
                Line(p-d*k*1.4f,p,Alpha(e.Style==0?Color.white:Gold,.35f),4);
                Sword(p,d,e.Style==0?Gold:Color.white,k*.95f);
                Sword(p,d,steel,k*.80f);return true;
            }
            if(e.Tag=="inferno")
            {
                float radius=e.Radius*k;Color fire=new Color(1,.35f,.08f);
                Disc(p,radius*1.2f,Alpha(fire,.27f),true);Ring(p,radius,Alpha(Gold,.7f),2);
                for(int i=0;i<9;i++)
                {
                    float x=(i/8f-.5f)*radius*1.8f;
                    float height=radius*(1.0f+.15f*Mathf.Sin(world.Time*10+i));
                    Vector2 bottom=p+new Vector2(x,radius*.4f);
                    Vector2 top=bottom+new Vector2(Mathf.Sin(i+world.Time*6)*k*.1f,-height);
                    Line(bottom,top,Alpha(fire,.22f),radius*.23f);
                    Line(bottom,top,Alpha(Gold,.55f),Mathf.Max(2,radius*.05f));
                }
                Text(new Rect(p.x-90,p.y-radius-25,180,22),"INFERNO  "+Mathf.Max(0,e.Expires-world.Time).ToString("0.0"),12,Gold,TextAnchor.MiddleCenter,true);return true;
            }
            if(e.Tag=="hassan-arm"||e.Tag=="assassin-chain")
            {
                Vector2 from=ScreenPoint(world.Players[e.Owner].Pos);Color tint=e.Tag=="hassan-arm"?new Color(.7f,.4f,1):Gold;
                Line(from,p,Alpha(tint,.22f),8);Line(from,p,tint,3);
                if(e.Tag=="assassin-chain")for(int i=1;i<=8;i++)Ring(Vector2.Lerp(from,p,i/9f),3,tint,1);
                Disc(p,k*.15f,Color.white);return true;
            }
            if(e.Tag=="twin-field") { Ring(p,e.Radius*k,Alpha(c,.5f),2);Disc(p,e.Radius*k,Alpha(c,.12f),true);return true; }
            return false;
        }
        void DrawV2Status()
        {
            foreach(var f in world.Players)
            {
                string text="";float t=world.Time;
                if(f.Job==Job.Undying&&f.UndyingUntil>t)text="UNDYING "+(f.UndyingUntil-t).ToString("0.0")+"s / DEBT "+Mathf.RoundToInt(f.UndyingDebt*.3f);
                if(f.Job==Job.TimeMurder&&f.Overclock)text="OVERCLOCK / 100 HITS PER SECOND / NO HIT GAUGE";
                if(f.Job==Job.MirrorAssassin)text="MIRROR "+(world.FindSummon(f,"mirror")!=null?"ACTIVE":"NONE");
                if(f.Job==Job.TwinFang)text="TWIN LINK"+(f.TwinUltUntil>t?" / SKILL ECHO":"");
                if(f.Job==Job.PhantomLegion)text="PHANTOMS "+world.CountSummons(f,"phantom");
                if(f.Job==Job.Puppeteer){var e=world.FindSummon(f,"puppet");text=e==null?"Q: SUMMON PUPPET":"HOLD Q + MOVE/JUMP: COMMAND / STORED "+Mathf.RoundToInt(e.AccumulatedDamage);}
                if(f.Job==Job.Mimic){var enemy=world.Enemy(f);text="COPY E: "+(enemy.LastSkillJob>=0&&t-enemy.LastSkillTime<=3?Roster.Get((Job)enemy.LastSkillJob).Name:"NO RECENT SKILL")+" / R: "+(enemy.LastUltimateJob>=0?Roster.Get((Job)enemy.LastUltimateJob).Name:"NONE");}
                if(f.Job==Job.LTiming)text=(world.TimingReturnReady(f)?"Q 반격 가능":"Q 대기")+" / "+(world.TimingInterceptReady(f)?"E 가로채기 가능":"E 대기")+(f.TimingCritReady?" / 다음 평타 치명타 70%":"")+(f.TimingUltUntil>t?" / 쿨 절반 "+(f.TimingUltUntil-t).ToString("0.0")+"초":"");
                if(f.Job==Job.Cybercrud)text="죽음의 표식 "+world.Enemy(f).CyberMarks[f.Id]+"/4"+(world.InsideCyberZone(f)?" / 일반 공격 차단":"")+(f.CyberUltUntil>t?" / 평타 "+f.CyberUltInterval.ToString("0.0")+"초":"");
                for(int slot=1;slot<=3;slot++)if(f.SlotLockedUntil[slot]>t)text+=" / "+(slot==1?"Q":slot==2?"E":"R")+" 봉쇄 "+(f.SlotLockedUntil[slot]-t).ToString("0.0")+"초";
                if(f.CyberSlowUntil>t)text+=" / 이동·공격 -30%";
                if(f.ChronoUntil>t)text+=" / TIME RATE "+Mathf.RoundToInt(world.ChronoRate(f)*100)+"%";
                if(text.Length>0)Text(new Rect(f.Id==0?40:774,112,466,36),text,10,Team[f.Id]);
                if(f.UndyingUntil>t)Ring(ScreenPoint(f.Pos),1280/camWidth*1.4f,new Color(.6f,1,.5f),3);
            }
        }
    }
}
