using UnityEngine;
using StickmanBrawler.Core;
namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        readonly float[] trailHP=new float[4],trailHold=new float[4],trailTime=new float[4];
        readonly Fighter[] trailFighter=new Fighter[4];
        float HealthTrail(Fighter f)
        {
            int i=f.Id;float hp=Mathf.Clamp01(f.HP/f.MaxHP),now=Time.unscaledTime;
            // Snapshot worlds replace Fighter instances, so online resets by match ID below.
            int match=OnlineActive?online.Match:-1;
            if(trailMatch!=match){System.Array.Clear(trailFighter,0,4);trailMatch=match;}
            if(trailFighter[i]==null||(!OnlineActive&&trailFighter[i]!=f)||hp>trailHP[i]){trailHP[i]=hp;trailHold[i]=now+.2f;}
            if(hp<trailLast[i])trailHold[i]=now+.2f;
            if(now>trailHold[i])trailHP[i]=Mathf.MoveTowards(trailHP[i],hp,Mathf.Max(0,now-trailTime[i])*.7f);
            trailFighter[i]=f;trailTime[i]=now;trailLast[i]=hp;return reduceMotion?hp:trailHP[i];
        }
        int trailMatch=-2;readonly float[] trailLast=new float[4];
    }
}
