using UnityEngine;
using StickmanBrawler.Core;
namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        void TrioPauseUI()
        {
            Box(new Rect(0,0,1280,720),new Color(.01f,.02f,.04f,.97f));
            Text(new Rect(100,20,1080,60),"3인 개인전 · 일시정지",32,Gold,TextAnchor.MiddleCenter,true);
            for(int id=0;id<3;id++)
            {
                FighterCard(id,(int)world.Players[id].Job,new Rect(35+id*420,100,370,385));
                Text(new Rect(35+id*420,495,370,62),"좌 "+GameKey(id,0)+" / 점프 "+GameKey(id,2)+" / 우 "+GameKey(id,1)+"\n평타 "+GameKey(id,3)+" / 스킬 "+GameKey(id,4)+", "+GameKey(id,5)+" / 궁 "+GameKey(id,6),14,Team[id]);
            }
            if(Button(new Rect(35,610,370,48),"계속 [ESC]",Team[0]))paused=false;
            if(Button(new Rect(455,610,370,48),"다시 시작"))StartMatch();
            if(Button(new Rect(875,610,370,48),"메인 메뉴")){menu=true;paused=false;}
        }
        void EventHUD()
        {
            Text(new Rect(480,20,320,60),"남은 시간 "+world.EventRemaining.ToString("0.0")+"초",26,Gold,TextAnchor.MiddleCenter,true);
            for(int id=0;id<2;id++)
            {
                float x=id==0?25:805;Box(new Rect(x,20,450,110),Panel);
                Text(new Rect(x+12,25,425,30),SeatLabel(id)+" · "+world.Players[id].Def.Name,20,Team[id],TextAnchor.MiddleLeft,true);
                Text(new Rect(x+12,58,425,52),"누적 피해 "+world.EventDamage[id].ToString("N0")+"\n평균 DPS "+world.EventDps(id).ToString("N1"),20,Gold);
                int controller=ControllerFor(id);if(controller<0)continue;
                var f=world.Players[id];float[] cds={f.QAt,f.EAt,0};string[] names={f.Def.QName,f.Def.EName,f.Def.RName};
                for(int slot=0;slot<3;slot++)
                {
                    float sx=(id==0?30:750)+slot*158;Box(new Rect(sx,610,150,54),Panel);
                    string ready=cds[slot]>world.Time?(cds[slot]-world.Time).ToString("0.0")+"초":slot==2&&f.Gauge<100?"궁 "+Mathf.FloorToInt(f.Gauge)+"%":"준비";
                    Text(new Rect(sx+6,614,138,23),GameKey(controller,slot+4)+" · "+ready,12,Team[id]);Text(new Rect(sx+6,637,138,24),names[slot],10,Muted);
                }
            }
            Text(new Rect(270,140,740,30),"각자 전용 허수아비 공격 · 캐릭터와 허수아비 처치 불가",15,Muted,TextAnchor.MiddleCenter);
        }
    }
}
