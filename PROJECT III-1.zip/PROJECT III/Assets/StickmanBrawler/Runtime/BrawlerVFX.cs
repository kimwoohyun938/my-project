using System;
using UnityEngine;
using StickmanBrawler.Core;

namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        Color ArtColor(uint rgb) { return new Color(((rgb>>16)&255)/255f,((rgb>>8)&255)/255f,(rgb&255)/255f); }
        Vector2 WeaponPoint(Vector2 origin,float x,float y,float k,float face,float angle)
        {
            float a=angle*Mathf.Deg2Rad;
            return origin+new Vector2((x*Mathf.Cos(a)-y*Mathf.Sin(a))*face,-(x*Mathf.Sin(a)+y*Mathf.Cos(a)))*k;
        }
        // Same vector geometry is exported in WEAPON_SHEET.svg. Weapons follow the hand transform.
        void DrawWeapon(Job job,Vector2 origin,float k,float face,bool striking,float alpha)
        {
            float angle=striking?-75:12;
            foreach(var s in WeaponArt.Strokes[(int)job])
            {
                Color c=Alpha(ArtColor(s.Color),alpha);
                Vector2 a=WeaponPoint(origin,s.X,s.Y,k,face,angle);
                if(s.Kind==0)Line(a,WeaponPoint(origin,s.A,s.B,k,face,angle),c,Mathf.Max(1,s.W*k));
                else if(s.Kind==1)Disc(a,s.A*k,c);
                else Ring(a,s.A*k,c,Mathf.Max(1,s.W*k));
            }
        }
        void DrawCostume(Fighter f,Vector2 p,float k,float alpha)
        {
            Job visualJob=f.DisguiseUntil>world.Time?world.Enemy(f).Job:f.PowerJob;
            Color c=Alpha(ArtColor(WeaponArt.Colors[(int)visualJob]),alpha);
            Color gold=Alpha(Gold,alpha),white=Alpha(Color.white,alpha);
            float face=f.Facing,wave=Mathf.Sin(world.Time*7f+f.Id)*k*.08f;
            Vector2 head=p+new Vector2(0,-.64f*k),shoulder=p+new Vector2(0,-.30f*k),hip=p+new Vector2(0,.14f*k);
            switch(visualJob)
            {
                case Job.Knight:
                case Job.King:
                case Job.QinShi:
                case Job.YiSunGod:
                    // Royal / Commander mantle + crown or crest
                    Line(shoulder,p+new Vector2(-face*.65f*k,.48f*k+wave),visualJob==Job.Knight?Alpha(new Color(.15f,.38f,1),alpha):c,.18f*k);
                    for(int i=-1;i<=1;i++)Line(head+new Vector2(i*.14f*k,-.14f*k),head+new Vector2(i*.18f*k,(-.38f+Mathf.Abs(i)*.07f)*k),gold,.055f*k);
                    break;
                case Job.Samurai:
                case Job.Ronin:
                case Job.BladeMaster:
                case Job.TwinFang:
                    // Conical kasa hat / flowing headband + haori coat tail
                    if(visualJob==Job.Samurai||visualJob==Job.Ronin)
                    {Line(head+new Vector2(-.42f*k,-.12f*k),head+new Vector2(0,-.36f*k),c,.07f*k);Line(head+new Vector2(.42f*k,-.12f*k),head+new Vector2(0,-.36f*k),c,.07f*k);}
                    Line(head+new Vector2(-face*.1f*k,-.08f*k),head+new Vector2(-face*.75f*k,-.16f*k+wave),c,.065f*k);
                    Line(hip,hip+new Vector2(-face*.45f*k,.35f*k),Alpha(c,alpha*.7f),.12f*k);
                    break;
                case Job.Berserker:
                case Job.Werewolf:
                case Job.DinoMan:
                    // Horns / beast ears + tail or jagged mane
                    Line(head+new Vector2(-.12f*k,-.12f*k),head+new Vector2(-.28f*k,-.42f*k),c,.07f*k);
                    Line(head+new Vector2(.12f*k,-.12f*k),head+new Vector2(.28f*k,-.42f*k),c,.07f*k);
                    Line(hip,hip+new Vector2(-face*.75f*k,.28f*k+wave),c,.11f*k);
                    break;
                case Job.Lancer:
                    // Crimson Lancer: flowing shoulder scarf + rune headband
                    Line(shoulder,p+new Vector2(-face*.78f*k,-.18f*k+wave),Alpha(new Color(.18f,.45f,1),alpha),.12f*k);
                    Line(head+new Vector2(-.22f*k,-.1f*k),head+new Vector2(.22f*k,-.1f*k),c,.065f*k);
                    break;
                case Job.Archer:
                case Job.Nisemono:
                    // Ranger / Arcane coat + back quiver
                    Line(shoulder,hip,Alpha(new Color(.8f,.16f,.16f),alpha),.18f*k);
                    Line(shoulder+new Vector2(-face*.18f*k,.1f*k),shoulder+new Vector2(-face*.32f*k,-.38f*k),gold,.08f*k);
                    break;
                case Job.GravityMage:
                case Job.Magician:
                case Job.Thunder:
                case Job.Cross:
                case Job.Luminary:
                case Job.FrostReaper:
                case Job.VoidWalker:
                case Job.Prism:
                case Job.Poltergeist:
                    // Floating arcane halo / circlet + mystic collar
                    Ring(head+new Vector2(0,-.18f*k),.28f*k,visualJob==Job.Cross?gold:c,2);
                    Line(shoulder+new Vector2(-.26f*k,0),shoulder+new Vector2(0,-.18f*k),c,.06f*k);
                    Line(shoulder+new Vector2(.26f*k,0),shoulder+new Vector2(0,-.18f*k),c,.06f*k);
                    break;
                case Job.Assassin:
                case Job.Hassan:
                case Job.ShadowClone:
                case Job.MirrorAssassin:
                case Job.Director:
                case Job.Depth:
                case Job.BloodApostle:
                    // Fluttering ninja scarf + dark hood crest
                    Line(shoulder,shoulder+new Vector2(-face*.88f*k,-.08f*k+wave),c,.09f*k);
                    Line(shoulder,shoulder+new Vector2(-face*.68f*k,.12f*k-wave),Alpha(c,alpha*.75f),.07f*k);
                    break;
                case Job.Guardian:
                case Job.Reflector:
                case Job.IronWall:
                case Job.Undying:
                case Job.Grappler:
                case Job.Vertebrate:
                case Job.Tether:
                    // Heavy armored pauldrons + chest plate
                    Disc(shoulder+new Vector2(-.22f*k,.02f*k),.13f*k,c);
                    Disc(shoulder+new Vector2(.22f*k,.02f*k),.13f*k,c);
                    Line(shoulder,hip,Alpha(c,alpha*.65f),.2f*k);
                    break;
                case Job.Engineer:
                case Job.Reactor:
                case Job.Cybercrud:
                case Job.Pendulum:
                    // Tech visor goggles + back jetpack/core
                    Line(head+new Vector2(-.2f*k,-.02f*k),head+new Vector2(.2f*k,-.02f*k),gold,.08f*k);
                    Box(new Rect(shoulder.x-face*.32f*k,shoulder.y-.05f*k,.2f*k,.32f*k),c);
                    break;
                case Job.TimeMurder:
                case Job.LTiming:
                case Job.Maestro:
                case Job.CardMan:
                case Job.Gambler:
                case Job.Institutor:
                case Job.Master:
                case Job.Dystopia:
                case Job.Zephyr:
                case Job.PhantomLegion:
                case Job.Mimic:
                case Job.Puppeteer:
                    // Chrono / Maestro / Trickster back emblem & coat tails
                    Ring(shoulder+new Vector2(-face*.2f*k,-.1f*k),.34f*k,Alpha(c,alpha*.65f),2);
                    Line(hip,hip+new Vector2(-face*.52f*k,.38f*k+wave),c,.1f*k);
                    break;
                case Job.Rider:
                    // Gorgon blindfold visor + long flowing violet hair
                    Line(head+new Vector2(-.24f*k,-.02f*k),head+new Vector2(.24f*k,-.02f*k),Alpha(new Color(.85f,.58f,1),alpha),.11f*k);
                    Line(head+new Vector2(-face*.12f*k,.05f*k),p+new Vector2(-face*.95f*k,.38f*k+wave),Alpha(new Color(.78f,.49f,1),alpha),.14f*k);
                    break;
            }
        }
        void DrawDuel()
        {
            if(world.DuelUntil<=world.Time||world.Phase!=Phase.Fight)return;
            Color c=new Color(.65f,.35f,1);float k=1280/camWidth;Vector2 p=ScreenPoint(world.DuelCenter);
            Disc(p,6*k,Alpha(c,.08f));Ring(p,6*k,Alpha(c,.8f),4);Ring(p,5.85f*k,Alpha(c,.3f),1);
            for(int i=0;i<12;i++){float a=i*Mathf.PI/6;Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));Line(p+d*5.7f*k,p+d*6.1f*k,c,3);}
            Text(new Rect(420,158,440,25),"SEALED DUEL  /  "+(world.DuelUntil-world.Time).ToString("0.0")+"s",14,c,TextAnchor.MiddleCenter,true);
        }
        void DrawExpansionStatus(Fighter f,Vector2 p,float k)
        {
            float t=world.Time;Color ice=new Color(.55f,.9f,1),violet=new Color(.7f,.45f,1);
            if(f.FreezeUntil>t)
            {
                Vector2 a=p+Vector2.up*k,b=p+Vector2.right*k*.6f,c=p-Vector2.up*k,d=p-Vector2.right*k*.6f;
                Line(a,b,ice,3);Line(b,c,ice,3);Line(c,d,ice,3);Line(d,a,ice,3);Line(a,c,Alpha(ice,.45f),2);Disc(p,k,Alpha(ice,.2f));
            }
            if(f.StealthUntil>t||f.VoidPhaseUntil>t)
                for(int i=0;i<8;i++){float a=i*Mathf.PI/4+t;Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));Line(p+d*k,p+d*k*1.2f,Alpha(violet,.7f),2);}
            if(f.BloodBoostUntil>t||f.BloodGuardUntil>t||f.BloodUltUntil>t)
            {
                Color red=new Color(1,.22f,.35f);Ring(p,k*1.25f,Alpha(red,.75f),2);
                for(int i=0;i<4;i++){float a=t*2+i*Mathf.PI/2;Disc(p+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*k*1.25f,k*.09f,red);}
            }
            float shield=world.TotalShield(f);
            if(shield>0||f.IronGuardUntil>t||f.IronUltUntil>t)
            {Ring(p,k*1.22f,Alpha(ice,.7f),3);Box(new Rect(p.x-k,p.y+k*1.13f,k*2,4),Panel);Box(new Rect(p.x-k,p.y+k*1.13f,k*2*Mathf.Clamp01(shield/650),4),ice);}
            int marks=0,frost=0,alchemy=0;
            foreach(var other in world.Players)if(world.Opponents(f.Id,other.Id))
            {marks=Mathf.Max(marks,f.ShadowMarks[other.Id]);frost=Mathf.Max(frost,f.FrostHits[other.Id]%3);alchemy=Mathf.Max(alchemy,f.AlchemyStacks[other.Id]);}
            for(int i=0;i<3;i++)if(marks>0)Disc(p+new Vector2((i-1)*.22f*k,-1.2f*k),k*.07f,i<marks?violet:Muted);
            if(frost>0)Text(new Rect(p.x-35,p.y+k,70,20),"FROST "+frost+"/3",10,ice,TextAnchor.MiddleCenter);
            if(alchemy>0)Text(new Rect(p.x-45,p.y+k*1.22f,90,20),"CATALYST "+alchemy+"/3",10,new Color(.36f,.9f,.63f),TextAnchor.MiddleCenter);
            if(f.AlchemistUltUntil>t)Ring(p,k*1.32f,new Color(.36f,.9f,.63f),3);
            if(f.RoninDrawReady)Ring(p,k*1.18f,new Color(1,.42f,.29f),2);
            if(f.Job==Job.Maestro&&f.MaestroBeatEnd>t)
            {
                bool beat=t>=f.MaestroBeatStart&&t<=f.MaestroBeatEnd;
                Ring(p,k*(beat?1.35f:1.1f),beat?Gold:Alpha(Gold,.35f),beat?3:1);
            }
            if(f.TetherUntil>t&&f.TetherTarget>=0&&f.TetherTarget<world.Players.Length)
            {
                Vector2 tp=ScreenPoint(world.Players[f.TetherTarget].Pos);
                Line(p,tp,new Color(.88f,.48f,.37f,.85f),3);
            }
            if(f.PoltergeistDebris>0)
                for(int i=0;i<f.PoltergeistDebris;i++){float a=t*3+i*2.094f;Disc(p+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*k*1.15f,k*.1f,new Color(.61f,.36f,.9f));}
            if(f.RiderPegasusUntil>t)Ring(p,k*1.38f,Color.white,3);
        }
        bool DrawExpansionEffect(Effect e,Vector2 p,float k,Color c)
        {
            if(e.Tag=="acid-pool")
            {
                Color acid=new Color(.36f,.9f,.63f);Disc(p,e.Radius*k,Alpha(acid,.16f));Ring(p,e.Radius*k,Alpha(acid,.8f),3);
                for(int i=0;i<6;i++){float a=i*Mathf.PI/3+world.Time*2;Vector2 b=p+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*e.Radius*k*.6f;Ring(b,k*.18f,Alpha(acid,.65f),2);}
                Text(new Rect(p.x-110,p.y-e.Radius*k-22,220,20),"산성 지대 "+Mathf.Max(0,e.Expires-world.Time).ToString("0.0")+"s",11,acid,TextAnchor.MiddleCenter);return true;
            }
            if(e.Tag=="cold-veil")
            {
                Disc(p,4*k,Alpha(c,.1f));Ring(p,4*k,Alpha(c,.65f),2);
                for(int i=0;i<14;i++){float a=i*2.399f;float r=(.4f+(i%4)*.22f)*4*k;Vector2 q=p+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*r;Line(q-Vector2.up*5,q+Vector2.up*5,Alpha(c,.65f),1);Line(q-Vector2.right*5,q+Vector2.right*5,Alpha(c,.65f),1);}
                Text(new Rect(p.x-130,p.y-4*k-24,260,22),"COLD VEIL  "+Mathf.Max(0,e.Expires-world.Time).ToString("0.0")+"s",12,c,TextAnchor.MiddleCenter);return true;
            }
            if(e.Tag=="shadow-clone")
            {
                c=Alpha(c,.5f);Disc(p+Vector2.up*.6f*k,.2f*k,c);Line(p+Vector2.up*.4f*k,p+Vector2.down*.15f*k,c,.08f*k);
                for(int side=-1;side<=1;side+=2){Line(p+Vector2.down*.15f*k,p+new Vector2(side*.3f*k,.85f*k),c,.07f*k);Line(p,p+new Vector2(side*.5f*k,0),c,.07f*k);}
                DrawWeapon(Job.ShadowClone,p+Vector2.right*k*.5f,k,1,false,.4f);Text(new Rect(p.x-60,p.y-k*1.2f,120,20),"CLONE",10,c,TextAnchor.MiddleCenter);return true;
            }
            if(e.Shape!=Shape.Shot||e.Tag=="gae-bolg")return false;
            Vector2 d=new Vector2(e.Vel.x,-e.Vel.y).normalized,n=new Vector2(-d.y,d.x);
            Job job=world.Players[e.Owner].Job;
            if(e.Tag=="king-gate"||e.Tag=="frost-spear")
            {Disc(p,k*.65f,Alpha(c,.22f),true);Sword(p,d,c,k*1.1f);Line(p-d*k*.8f,p-d*k*1.7f,Alpha(c,.5f),3);return true;}
            if(job==Job.Archer||job==Job.Lancer)
            {Line(p-d*k*.65f,p+d*k*.3f,c,3);Line(p+d*k*.3f,p+n*k*.14f,c,2);Line(p+d*k*.3f,p-n*k*.14f,c,2);return true;}
            if(job==Job.CardMan)
            {for(int s=-1;s<=1;s+=2){Line(p+d*k*.25f+n*s*k*.16f,p-d*k*.25f+n*s*k*.16f,c,2);Line(p+n*k*.16f+d*s*k*.25f,p-n*k*.16f+d*s*k*.25f,c,2);}return true;}
            if(job==Job.GravityMage||job==Job.Magician||job==Job.VoidWalker||job==Job.FrostReaper)
            {Disc(p,k*.6f,Alpha(c,.35f),true);Ring(p,e.Radius*k,c,2);Ring(p,e.Radius*k*.6f,Color.white,1);Line(p,p-d*k*.8f,Alpha(c,.6f),3);return true;}
            return false;
        }
        void DrawEnergyBeam(Vector2 a,Vector2 b,float width,Color c,Job job)
        {
            // The outer edges show beam height; brightness stays concentrated at the center.
            Line(a,b,Alpha(c,c.a*.18f),width);
            Line(a,b,Alpha(c,c.a*.7f),width*.3f);
            Line(a,b,Alpha(Color.white,c.a*.9f),Mathf.Max(3,width*.065f));
            Vector2 edge=new Vector2(-(b-a).y,(b-a).x).normalized*width*.5f;
            Line(a+edge,b+edge,Alpha(c,c.a*.8f),2);Line(a-edge,b-edge,Alpha(c,c.a*.8f),2);

            Vector2 d=(b-a).normalized,n=new Vector2(-d.y,d.x);
            for(int i=0;i<12;i++)
            {
                float x=(i+.5f)/12;Vector2 q=Vector2.Lerp(a,b,x);
                float bend=job==Job.Thunder?Mathf.Sin(i*7.1f+(reduceMotion?0:world.Time*12))*width*.35f:width*.12f;
                Line(q-d*12+n*bend,q+d*12-n*bend,Alpha(c,c.a*.7f),job==Job.Thunder?3:1);
            }
        }
        bool DrawExpansionCue(Cue cue,Vector2 p,float k,Color c,float life)
        {
            float radius=cue.Size*k;
            if(cue.Kind=="cast-vfx")
            {
                Job job=world.Players[cue.Owner].Job;int rays=4+(int)job%5;
                Ring(p,radius*(.65f+life*.35f),c,2);
                for(int i=0;i<rays;i++){float a=i*Mathf.PI*2/rays+(int)job*.17f;Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));Line(p+d*radius*.65f,p+d*radius,c,2);}return true;
            }
            if(cue.Kind=="slash")
            {
                Vector2 end=ScreenPoint(cue.End);Line(p,end,Alpha(c,c.a*.25f),12);Line(p,end,c,3);
                Vector2 center=(p+end)*.5f;float r=Vector2.Distance(p,end)*.45f;
                for(int i=0;i<10;i++){float a=-1.2f+i*.22f,b=a+.22f;Line(center+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*r,center+new Vector2(Mathf.Cos(b),Mathf.Sin(b))*r,c,2);}return true;
            }
            if(cue.Kind=="bolt")
            {
                Vector2 end=ScreenPoint(cue.End),n=new Vector2(-(end-p).y,(end-p).x).normalized;
                for(int i=0;i<8;i++){Vector2 a=Vector2.Lerp(p,end,i/8f)+n*(i==0?0:Mathf.Sin(i*13f)*k*.25f);Vector2 b=Vector2.Lerp(p,end,(i+1)/8f)+n*(i==7?0:Mathf.Sin((i+1)*13f)*k*.25f);Line(a,b,c,4);Line(a,b,Alpha(Color.white,c.a),1);}return true;
            }
            if(cue.Kind=="ice-field"||cue.Kind=="ice-break")
            {
                Ring(p,radius*(.3f+.7f*life),c,2);
                for(int i=0;i<12;i++){float a=i*Mathf.PI/6;Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a)),n=new Vector2(-d.y,d.x);Vector2 tip=p+d*radius*(.3f+.7f*life);Line(p+d*radius*.2f,tip,c,3);Line(tip,tip-d*k*.25f+n*k*.15f,c,2);}return true;
            }
            if(cue.Kind=="aura"||cue.Kind=="portal"||cue.Kind=="shield"||cue.Kind=="rebirth"||cue.Kind=="smoke")
            {
                Ring(p,radius*(.6f+.4f*life),c,2);Disc(p,radius,Alpha(c,c.a*.15f),true);
                for(int i=0;i<7;i++){float a=i*2.399f;Vector2 q=p+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*radius*life;Disc(q,k*.08f,c);}
                if(cue.Text.Length>0)Text(new Rect(p.x-130,p.y-radius-22,260,25),cue.Text,12,c,TextAnchor.MiddleCenter,true);return true;
            }
            return false;
        }
        string FortuneName(int rank) { return rank==2?"AWAKENING II":rank==1?"AWAKENING I":"NO AWAKENING"; }
        void DrawExpansionHUD(Fighter f,float x)
        {
            Color c=ArtColor(WeaponArt.Colors[(int)f.Job]);string detail="";float t=world.Time;
            if(f.Job==Job.Gambler&&f.FortuneResultUntil>t)
            {
                Color result=f.FortuneResult==2?new Color(.8f,.5f,1):f.FortuneResult==1?Gold:Muted;
                Box(new Rect(x+12,123,476,66),Alpha(Ink,.96f));Box(new Rect(x+12,123,5,66),result);
                Text(new Rect(x+25,128,450,26),FortuneName(f.FortuneResult),20,result,TextAnchor.MiddleCenter,true);
                Text(new Rect(x+25,157,450,24),f.FortuneResult==0?"NO COMBAT BUFF  /  GAUGE CONSUMED":f.FortuneResult==1?"POWER +47%  /  NO KNOCKBACK  /  7.77s":"POWER +777%  /  CC IMMUNE  /  7.77s",11,result,TextAnchor.MiddleCenter);
            }
            if(f.Job==Job.FrostReaper)detail="FROST HITS "+(world.Enemy(f).FrostHits[f.Id]%3)+"/3  /  R: 6m FREEZE + THAW";
            if(f.Job==Job.BloodApostle)detail="REBIRTH: "+(f.BloodReviveUsed?"USED":f.BloodReviveArmed?"ARMED":"USE ULT TO ARM")+"  /  STORED HEAL "+(f.BloodStoredDamage*.5f).ToString("0");
            if(f.Job==Job.ShadowClone)detail="SHADOW MARKS "+world.Enemy(f).ShadowMarks[f.Id]+"/3  /  ASSAULT "+Mathf.Max(0,f.ShadowAssaultUntil-t).ToString("0.0")+"s";
            if(f.Job==Job.IronWall)detail="SHIELD "+world.TotalShield(f).ToString("0")+"  /  ARMOR: "+(f.IronGuardUntil>t?.4f:0)+(f.IronUltUntil>t?" +100%":"")+"  /  1v1: NO ALLY SHARE";
            if(f.Job==Job.VoidWalker)detail="PHASE "+Mathf.Max(0,f.VoidPhaseUntil-t).ToString("0.0")+"s  /  RECAST "+Mathf.Max(0,f.VoidRecastUntil-t).ToString("0.0")+"s";
            if(f.Job==Job.Alchemist)detail="CATALYST "+world.Enemy(f).AlchemyStacks[f.Id]+"/3  /  STONE "+(f.AlchemistUltUntil>t?(f.AlchemistUltUntil-t).ToString("0.0")+"s":"READY ON R");
            if(f.Job==Job.Ronin)detail="STANCE: "+(f.RoninDrawReady?"발도 준비 (1.5x + 회복)":"일반")+"  /  GALE "+Mathf.Max(0,f.RoninWindUntil-t).ToString("0.0")+"s";
            if(f.Job==Job.Maestro)detail="TEMPO x"+f.MaestroTempo+"/4  /  "+(t>=f.MaestroBeatStart&&t<=f.MaestroBeatEnd?"[정박 입력 창!]":"박자 간격 0.52~0.76s")+"  /  스킬 교차 시 중첩";
            if(f.Job==Job.Pendulum)detail="SPEED "+f.Vel.Length.ToString("0.0")+"m/s  /  MOMENTUM BONUS +"+Mathf.RoundToInt(Rules.Clamp(f.Vel.Length/20f,0,.8f)*100)+"%";
            if(f.Job==Job.Tether)detail="CHAIN: "+(f.TetherUntil>t?(f.TetherUntil-t).ToString("0.0")+"s (MAX 5.5m)":"UNLINKED");
            if(f.Job==Job.Prism)detail="PRISM CORE: "+(world.FindSummon(f,"prism-lens")!=null?"DEPLOYED (굴절 사격 활성)":"NONE (Q로 배치)");
            if(f.Job==Job.Reactor)detail="HEAT "+Mathf.RoundToInt(f.ReactorHeat)+"% "+((f.ReactorHeat>=50&&f.ReactorHeat<=85)||f.ReactorUltUntil>t?"[임계 출력 +35%]":"(50~85% 임계 구간)");
            if(f.Job==Job.Poltergeist)detail="DEBRIS "+f.PoltergeistDebris+"/3  /  공중 적 평타 추가 피해";
            if(f.Job==Job.Rider)detail="CYBELE: 4.5m/마주봄 석화  /  PEGAUS "+Mathf.Max(0,f.RiderPegasusUntil-t).ToString("0.0")+"s";
            if(f.Job==Job.Lancer)detail="전투속행: "+(f.LancerGutsUsed?"발동됨":"준비됨 (치명상 시 350 HP 부활)")+(f.LancerFuryUntil>t?"  /  폭주 "+(f.LancerFuryUntil-t).ToString("0.0")+"s":"");
            if(f.Job==Job.Luminary)detail="광휘 조각: "+f.LuminaryShards+"/9  /  압도 중첩: "+world.Enemy(f).OverwhelmStacks[f.Id]+"/6 (6중첩 자동 폭발 · E 즉시 해방)";
            if(detail.Length>0)Text(new Rect(x+12,552,475,44),detail,12,c);
        }
    }
}
