using UnityEngine;
using StickmanBrawler.Core;
namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        bool DrawTimingCyberEffect(Effect e,Vector2 p,float k)
        {
            Color violet=new Color(.72f,.43f,1),cyan=new Color(.35f,.95f,1);
            if(e.Tag.StartsWith("code:"))
            {
                Vector2 tail=p-new Vector2(e.Vel.x,-e.Vel.y).normalized*k*.65f;
                Line(tail,p,Alpha(violet,.35f),k*.18f);Disc(p,k*.36f,Alpha(violet,.2f),true);
                string code=e.Tag.Substring(5);float width=Mathf.Max(48,code.Length*11);
                Box(new Rect(p.x-width/2-4,p.y-14,width+8,28),new Color(.06f,.02f,.12f,.93f));
                Text(new Rect(p.x-width/2,p.y-13,width,26),code,16,code=="return"?Color.white:violet,TextAnchor.MiddleCenter,true);
                return true;
            }
            if(e.Tag=="cyber-zone")
            {
                Disc(p,e.Radius*k,Alpha(violet,.075f));Ring(p,e.Radius*k,violet,3);Ring(p,e.Radius*k-5,Alpha(cyan,.5f),1);
                for(int i=0;i<8;i++){float a=i*Mathf.PI/4;Vector2 point=p+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*e.Radius*k;Disc(point,3,cyan);}
                Text(new Rect(p.x-150,p.y-e.Radius*k-30,300,25),"프라이빗 존 · "+Mathf.Max(0,e.Expires-world.Time).ToString("0.0")+"초",13,violet,TextAnchor.MiddleCenter,true);return true;
            }
            if(e.Tag=="cyber-throttle")
            {
                Disc(p,k*.72f,Alpha(violet,.3f),true);Ring(p,k*.65f,violet,3);Ring(p,k*.43f,cyan,2);
                Text(new Rect(p.x-40,p.y-13,80,26),"-30%",15,Color.white,TextAnchor.MiddleCenter,true);return true;
            }
            if(e.Tag=="code-hole")
            {Disc(p,k*.55f,new Color(.015f,0,.035f));Ring(p,k*.65f,violet,3);Ring(p,k*(.7f+.12f*Mathf.Sin(world.Time*20)),Alpha(violet,.4f),2);return true;}
            return false;
        }
        bool DrawTimingCyberCue(Cue cue,Vector2 p,float k,Color c,float life)
        {
            if(!cue.Kind.StartsWith("timing-")&&cue.Kind!="cyber-execute")return false;
            Ring(p,k*(.8f+life*1.4f),c,3);Ring(p,k*(.6f+life),Alpha(Color.white,1-life),1);
            if(cue.Kind=="timing-return"||cue.Kind=="timing-steal")
            {Vector2 end=ScreenPoint(cue.End);Line(p,end,Alpha(c,.6f),3);Ring(end,k*(.6f+life),c,2);}
            Text(new Rect(p.x-180,p.y-70-life*20,360,42),cue.Text,18,c,TextAnchor.MiddleCenter,true);return true;
        }
        void DrawTimingCyberFighter(Fighter f,Vector2 p,float k)
        {
            int marks=0;foreach(var other in world.Players)if(world.Opponents(f.Id,other.Id))marks=Mathf.Max(marks,f.CyberMarks[other.Id]);Color violet=new Color(.8f,.5f,1);
            for(int i=0;i<marks;i++)
            {
                Vector2 skull=p+new Vector2((i-(marks-1)*.5f)*17,-k*2.1f);
                Disc(skull,7,violet);Box(new Rect(skull.x-4,skull.y+3,8,6),violet);
                Disc(skull+new Vector2(-2.5f,-1),1.8f,Color.black);Disc(skull+new Vector2(2.5f,-1),1.8f,Color.black);
                Line(skull+new Vector2(-2,6),skull+new Vector2(2,6),Color.black,1);
            }
            if(f.TimingUltUntil>world.Time)
            {
                Color cyan=new Color(.4f,1,1);float radius=k*1.2f;Ring(p,radius,Alpha(cyan,.6f),2);
                for(int i=0;i<12;i++){float a=i*Mathf.PI/6;Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));Line(p+d*radius*.9f,p+d*radius,cyan,2);}
                float angle=world.Time*5;Line(p,p+new Vector2(Mathf.Cos(angle),Mathf.Sin(angle))*radius*.8f,cyan,2);
            }
        }
    }
}
