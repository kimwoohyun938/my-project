using System;
using UnityEngine;
using StickmanBrawler.Core;

namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        void DrawLuminaryFighterVisuals(Fighter f, Vector2 p, float k)
        {
            float t = world.Time;
            Color goldBright = new Color(1f, 0.92f, 0.48f);
            Color cyanLight = new Color(0.65f, 0.96f, 1f);

            // Render orbiting Radiance Shards (0..9) around Luminary
            if (f.LuminaryShards > 0)
            {
                for (int i = 0; i < f.LuminaryShards; i++)
                {
                    float angle = t * 3.2f + i * (Mathf.PI * 2f / Mathf.Max(1, f.LuminaryShards));
                    Vector2 offset = new Vector2(Mathf.Cos(angle) * 1.18f, Mathf.Sin(angle) * 0.68f - 0.35f) * k;
                    Vector2 sp = p + offset;
                    Disc(sp, k * 0.13f, Alpha(goldBright, 0.35f), true);
                    Line(sp + new Vector2(0, -k * 0.11f), sp + new Vector2(0, k * 0.11f), goldBright, 2.5f);
                    Line(sp + new Vector2(-k * 0.08f, 0), sp + new Vector2(k * 0.08f, 0), Color.white, 2f);
                }
                Text(new Rect(p.x - 65, p.y - 2.05f * k, 130, 22), "광휘 조각 " + f.LuminaryShards + "/9", 11, goldBright, TextAnchor.MiddleCenter, true);
            }

            // Dash speedlines & aura while dashing
            if (f.LuminaryDashUntil > t)
            {
                Ring(p, k * 1.25f, goldBright, 3f);
                for (int i = -1; i <= 1; i++)
                {
                    Vector2 s = p + new Vector2(-f.Facing * 0.3f * k, i * 0.32f * k);
                    Line(s, s + new Vector2(-f.Facing * 1.35f * k, 0), Alpha(cyanLight, 0.8f), 2.5f);
                }
            }

            // Render Overwhelm stacks accumulated on this fighter by any opponent
            int overwhelm = 0;
            foreach (var other in world.Players)
                if (world.Opponents(f.Id, other.Id))
                    overwhelm = Mathf.Max(overwhelm, f.OverwhelmStacks[other.Id]);

            if (overwhelm > 0)
            {
                Color markCol = overwhelm >= 5 ? new Color(1f, 0.45f, 0.2f) : goldBright;
                Ring(p, k * (0.85f + overwhelm * 0.07f), Alpha(markCol, 0.85f), 2f);
                for (int i = 0; i < overwhelm; i++)
                {
                    Vector2 pip = p + new Vector2((i - (overwhelm - 1) * 0.5f) * 13f, -k * 2.3f);
                    Disc(pip, 4.5f, markCol);
                }
                Text(new Rect(p.x - 60, p.y - k * 2.65f, 120, 20), "압도 " + overwhelm + "/6", 11, markCol, TextAnchor.MiddleCenter, true);
            }
        }

        bool DrawLuminaryCue(Cue cue, Vector2 p, float k, Color c, float life)
        {
            Color goldBright = new Color(1f, 0.92f, 0.48f, 1f - life);
            if (cue.Kind == "luminary-afterimage")
            {
                Vector2 end = ScreenPoint(cue.End);
                BrightLine(p, end, goldBright, Mathf.Max(4f, k * 0.22f));
                Ring(end, k * (0.5f + life * 0.6f), goldBright, 2f);
                return true;
            }
            if (cue.Kind == "luminary-sigil")
            {
                float r = cue.Size * k * (0.45f + 0.55f * life);
                Disc(p, r, Alpha(goldBright, 0.16f * (1f - life)), true);
                Ring(p, r, goldBright, 3f);
                Ring(p, r * 0.68f, Alpha(Color.white, 0.8f * (1f - life)), 1.5f);
                for (int i = 0; i < 8; i++)
                {
                    float a = i * Mathf.PI / 4f + life * 1.2f;
                    Vector2 d = new Vector2(Mathf.Cos(a), Mathf.Sin(a));
                    Line(p + d * r * 0.55f, p + d * r * 1.05f, goldBright, 2f);
                }
                if (!string.IsNullOrEmpty(cue.Text))
                    Text(new Rect(p.x - 140, p.y - r - 26, 280, 24), cue.Text, 13, goldBright, TextAnchor.MiddleCenter, true);
                return true;
            }
            return false;
        }
    }
}
