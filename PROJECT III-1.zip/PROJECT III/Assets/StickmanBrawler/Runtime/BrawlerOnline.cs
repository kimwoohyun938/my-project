using System;
using UnityEngine;
using StickmanBrawler.Core;
using StickmanBrawler.Online;
namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        RoomSession online;bool onlineMenu,onlineOverlay,onlineFocused=true,visualLead=true;
        string onlineAddress="127.0.0.1",onlinePort="7777",onlineError="";int onlineHits,onlineMatch;
        readonly ViewPresentation presentation=new ViewPresentation();Controls onlineControls;
        bool OnlineActive {get{return online!=null;}}
        void UpdateOnline()
        {
            if(online==null){if(Input.GetKeyDown(KeyCode.Escape))onlineMenu=false;return;}
            if(Input.GetKeyDown(KeyCode.Escape))onlineOverlay=!onlineOverlay;
            onlineControls=new Controls();if(onlineFocused&&!onlineOverlay&&online.State==RoomState.Playing)Sample(0,ref onlineControls);
            if(!onlineFocused||onlineOverlay)online.ClearLocalInput();else online.Capture(onlineControls);
            online.Pump(Time.unscaledDeltaTime);
            if(online.View!=null)
            {
                world=online.View;mode=0;presentation.Update(world,online.Match,Time.unscaledDeltaTime);
                if(online.Match!=onlineMatch){onlineMatch=online.Match;onlineHits=world.HitSerial;onlineOverlay=false;}
                if(world.HitSerial!=onlineHits){onlineHits=world.HitSerial;Sound(hitSound);shake=.12f;}
                TrackCamera();
            }
        }
        void ConnectOnline(bool host)
        {
            int port;if(!int.TryParse(onlinePort,out port)||port<1||port>65535){onlineError="포트는 1~65535 숫자로 입력하세요.";return;}
            if(!host&&string.IsNullOrWhiteSpace(onlineAddress)){onlineError="방장 주소를 입력하세요.";return;}
            if(online!=null)online.Dispose();
            var transport=host?TcpRoomTransport.Host(port):TcpRoomTransport.Join(onlineAddress.Trim(),port);
            online=new RoomSession(transport,host);onlineOverlay=false;onlineError="";onlineMatch=onlineHits=0;mode=0;
            pendingA=pendingB=pendingC=new Controls();settings=false;paused=false;
        }
        void ExitOnline()
        {if(online!=null){online.Leave();online.Dispose();online=null;}onlineMenu=false;onlineOverlay=false;menu=true;paused=false;world=null;pendingA=pendingB=pendingC=new Controls();}
        void OnlineUI()
        {
            if(online!=null&&(online.State==RoomState.Playing||online.State==RoomState.Results)&&online.View!=null)
            {
                var rendering=world;var positions=new[]{world.Players[0].Pos,world.Players[1].Pos};
                try{for(int i=0;i<2;i++)world.Players[i].Pos=presentation.Position(i,onlineControls,online.LocalSeat,visualLead,online.PingMs);GameUI();}
                finally{for(int i=0;i<2;i++)rendering.Players[i].Pos=positions[i];}
                if(online==null)return;
                Text(new Rect(360,665,590,20),"온라인 · "+(online.IsHost?"방장":"참가자")+" · RTT "+online.PingMs.ToString("0")+"ms · 상태 지연 "+(online.SnapshotAge*1000).ToString("0")+"ms",11,Gold,TextAnchor.MiddleCenter);
                if(onlineOverlay&&online.State==RoomState.Playing)
                {
                    Box(new Rect(330,225,620,265),Alpha(Ink,.97f));Text(new Rect(350,245,580,65),"온라인 경기는 일시정지되지 않습니다.\n메뉴를 연 동안 내 입력만 중지합니다.",21,Gold,TextAnchor.MiddleCenter);
                    if(Button(new Rect(360,330,260,48),"돌아가기 [ESC]"))onlineOverlay=false;
                    if(Button(new Rect(645,330,270,48),visualLead?"이동 선행 표시: 켜짐":"이동 선행 표시: 꺼짐"))visualLead=!visualLead;
                    if(Button(new Rect(360,398,555,48),"방 나가기"))ExitOnline();
                }
                return;
            }
            Background();Text(new Rect(70,35,1140,65),"ONLINE 1v1 · 직접 연결",36,Gold,TextAnchor.MiddleCenter,true);
            if(online==null)
            {
                Text(new Rect(180,135,920,70),"두 PC에서 같은 버전을 실행하세요.\n방 생성 후 참가자는 방장 IP와 포트를 입력합니다.",21,Muted,TextAnchor.MiddleCenter);
                Text(new Rect(235,250,200,38),"방장 주소",18,Team[0]);onlineAddress=GUI.TextField(new Rect(450,250,590,38),onlineAddress,253);
                Text(new Rect(235,310,200,38),"TCP 포트",18,Team[0]);onlinePort=GUI.TextField(new Rect(450,310,590,38),onlinePort,5);
                if(Button(new Rect(235,390,385,58),"방 생성",Team[0],22))ConnectOnline(true);
                if(Button(new Rect(655,390,385,58),"방 참가",Team[1],22))ConnectOnline(false);
                Text(new Rect(165,478,950,85),"같은 PC 테스트: 127.0.0.1 · 같은 공유기: 방장 내부 IP\n인터넷: 방장 접속 가능한 IP/포트 또는 사설망 연결 필요\n온라인 조작은 두 PC 모두 설정의 1P 키를 사용합니다.",16,Muted,TextAnchor.MiddleCenter);
                Text(new Rect(150,578,980,35),onlineError,16,Team[1],TextAnchor.MiddleCenter);
            }
            else if(online.State==RoomState.Lobby)
            {
                Text(new Rect(70,110,1140,38),"나는 "+(online.LocalSeat+1)+"P · "+(online.IsHost?"방장":"참가자")+"   |   양쪽 준비 완료 시 시작",21,Muted,TextAnchor.MiddleCenter);
                for(int i=0;i<2;i++)Text(new Rect(110+i*550,165,510,45),(i+1)+"P "+Roster.All[online.Jobs[i]].Name+" · "+(online.Ready[i]?"준비 완료":"선택 중"),24,Team[i],TextAnchor.MiddleCenter,true);
                for(int i=0;i<Roster.All.Length;i++){int job=i;if(Button(new Rect(70+(i%10)*114,222+(i/10)*48,108,42),Roster.All[i].Name,online.Jobs[online.LocalSeat]==i?Team[online.LocalSeat]:Muted,11))online.Choose(job);}
                if(Button(new Rect(80,522,530,45),Arena.Create(online.Stage).Name+(online.IsHost?"  >":""),Muted,14)&&online.IsHost)online.SetStage((online.Stage+1)%Arena.Count);
                if(Button(new Rect(630,522,570,45),"호스트 입력 완충 "+online.DelayTicks+"틱"+(online.IsHost?"  >":""),Muted,14)&&online.IsHost)online.SetDelay(online.DelayTicks>=6?0:online.DelayTicks+1);
                if(Button(new Rect(280,590,720,50),online.Ready[online.LocalSeat]?"준비 취소":"준비 완료",Team[online.LocalSeat],23))online.SetReady(!online.Ready[online.LocalSeat]);
            }
            else Text(new Rect(120,220,1040,230),online.Status+(online.State==RoomState.Connecting?"\n방장은 상대 접속을 기다려주세요.\n참가자는 주소·포트·방화벽 설정을 확인하세요.":""),24,Muted,TextAnchor.MiddleCenter);
            if(Button(new Rect(440,656,400,42),online==null?"로컬 메뉴로":"연결 종료 / 로컬 메뉴로"))ExitOnline();
        }
        void OnlineResultsUI()
        {
            Box(new Rect(0,0,1280,720),Alpha(Ink,.95f));Text(new Rect(90,170,1100,85),world.Announcement,50,Gold,TextAnchor.MiddleCenter,true);
            Text(new Rect(180,275,920,50),"1P "+world.Players[0].Score+" : "+world.Players[1].Score+" 2P",36,Gold,TextAnchor.MiddleCenter);
            Text(new Rect(180,335,920,45),"양쪽 재대결 동의 후 캐릭터 선택으로 돌아갑니다.",18,Muted,TextAnchor.MiddleCenter);
            if(Button(new Rect(350,420,580,55),online.WantsRematch[online.LocalSeat]?"상대 재대결 동의 대기":"재대결 요청",Team[online.LocalSeat],22))online.Rematch();
            if(Button(new Rect(350,500,580,50),"방 나가기"))ExitOnline();
        }
    }
}
