using System;
using UnityEngine;
using StickmanBrawler.Core;

namespace StickmanBrawler
{
    public sealed partial class BrawlerApp : MonoBehaviour
    {
        World world;
        int p1,p2=5,p3=55,p4=55,stage,mode,selectedPlayer,rebinding=-1,lastHit;
        bool solo,humanRight,teamCoop;int killGoal=5;
        bool menu=true,paused,settings,reduceMotion,muted;
        float accumulator,camWidth=29,shake;
        V2 cam=new V2(0,3);
        Controls pendingA,pendingB,pendingC;
        float eventDuration=60;
        readonly KeyCode[,] trioKeys=new KeyCode[3,8] {{KeyCode.A,KeyCode.C,KeyCode.D,KeyCode.F,KeyCode.Q,KeyCode.W,KeyCode.E,KeyCode.S},{KeyCode.G,KeyCode.J,KeyCode.Y,KeyCode.M,KeyCode.N,KeyCode.B,KeyCode.V,KeyCode.K},{KeyCode.LeftArrow,KeyCode.RightArrow,KeyCode.UpArrow,KeyCode.Slash,KeyCode.Quote,KeyCode.RightBracket,KeyCode.Backslash,KeyCode.Period}};
        KeyCode[,] keys=new KeyCode[2,8] {{KeyCode.A,KeyCode.D,KeyCode.W,KeyCode.F,KeyCode.Q,KeyCode.E,KeyCode.R,KeyCode.S},
            {KeyCode.LeftArrow,KeyCode.RightArrow,KeyCode.UpArrow,KeyCode.L,KeyCode.U,KeyCode.I,KeyCode.O,KeyCode.DownArrow}};
        string[] actionNames={"LEFT","RIGHT","JUMP","ATTACK","SKILL 1","SKILL 2","ULTIMATE","가드"};
        AudioSource audioSource;
        AudioClip hitSound,selectSound,koSound;
        Phase lastPhase;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if(UnityEngine.Object.FindFirstObjectByType<BrawlerApp>()!=null)return;
            new GameObject("Stickman Brawler").AddComponent<BrawlerApp>();
        }
        void Awake()
        {
            Application.runInBackground=true;Application.targetFrameRate=120;QualitySettings.vSyncCount=1;
            if(Camera.main==null){var c=new GameObject("Camera").AddComponent<Camera>();c.tag="MainCamera";c.clearFlags=CameraClearFlags.SolidColor;c.backgroundColor=new Color(.025f,.04f,.065f);c.orthographic=true;}
            for(int p=0;p<2;p++)for(int k=0;k<8;k++)keys[p,k]=(KeyCode)PlayerPrefs.GetInt("SB.Key."+p+"."+k,(int)keys[p,k]);
            reduceMotion=PlayerPrefs.GetInt("SB.ReducedMotion",0)==1;muted=PlayerPrefs.GetInt("SB.Muted",0)==1;
            audioSource=gameObject.AddComponent<AudioSource>();audioSource.spatialBlend=0;audioSource.volume=.18f;
            hitSound=Tone(170,.07f);selectSound=Tone(510,.06f);koSound=Tone(75,.35f);
        }
        AudioClip Tone(float frequency,float seconds)
        {
            int count=(int)(22050*seconds);float[] data=new float[count];
            for(int i=0;i<count;i++)
            {
                float t=i/22050f,env=Mathf.Pow(1-i/(float)count,1.4f);
                float wave=Mathf.Sin(t*frequency*6.28318f)*.65f+Mathf.Sin(t*frequency*12.56636f)*.25f+Mathf.Sin(t*frequency*3.14159f)*.1f;
                data[i]=wave*env*.38f;
            }
            var clip=AudioClip.Create("Procedural tone",count,1,22050,false);clip.SetData(data,0);return clip;
        }
        void Sound(AudioClip clip) { if(!muted&&clip!=null)audioSource.PlayOneShot(clip); }
        void OnApplicationFocus(bool focused) { onlineFocused=focused;if(OnlineActive)return;if(!focused&&!menu){paused=true;pendingA=pendingB=pendingC=new Controls();} }
        void OnDestroy()
        { if(online!=null)online.Dispose();if(hitSound)Destroy(hitSound);if(selectSound)Destroy(selectSound);if(koSound)Destroy(koSound);if(circle)Destroy(circle);if(glow)Destroy(glow);if(slashMask)Destroy(slashMask);if(ringTex)Destroy(ringTex); }
        void Update()
        {
            if(onlineMenu||OnlineActive){UpdateOnline();return;}
            if(rebinding>=0)return;
            if(Input.GetKeyDown(KeyCode.Escape))
            { if(settings)settings=false;else if(!menu){paused=!paused;pendingA=pendingB=pendingC=new Controls();} }
            if(settings)return;
            if(menu)
            {
                int count=Roster.All.Length+1;
                if(Input.GetKeyDown(GameKey(0,0)))p1=(p1+count-1)%count;
                if(Input.GetKeyDown(GameKey(0,1)))p1=(p1+1)%count;
                if(!ThreeHumans&&Input.GetKeyDown(keys[1,0]))p2=(p2+count-1)%count;
                if(!ThreeHumans&&Input.GetKeyDown(keys[1,1]))p2=(p2+1)%count;
                if(ThreeHumans){if(Input.GetKeyDown(KeyCode.G))p2=(p2+count-1)%count;if(Input.GetKeyDown(KeyCode.J))p2=(p2+1)%count;if(Input.GetKeyDown(KeyCode.LeftArrow))p3=(p3+count-1)%count;if(Input.GetKeyDown(KeyCode.RightArrow))p3=(p3+1)%count;}
                if(Input.GetKeyDown(KeyCode.Tab))stage=mode==(int)BattleMode.BossRaid||mode==(int)BattleMode.DpsEvent?3+(stage-3+1)%3:(stage+1)%Arena.Count;
                if(Input.GetKeyDown(KeyCode.Return))StartMatch();return;
            }
            if(paused)return;
            if(world.Phase==Phase.Finished){if(Input.GetKeyDown(KeyCode.Return))StartMatch();return;}
            if(world.NeedsSelection){ResolveCpuPicks();pendingA=pendingB=pendingC=new Controls();accumulator=0;if(world.NeedsSelection||world.Phase==Phase.Finished)return;}
            if(world.Training)
            { if(Input.GetKeyDown(KeyCode.H))world.RefillTraining();if(Input.GetKeyDown(KeyCode.Backspace))world.ResetTraining(); }
            Sample(0,ref pendingA);if(HumanCount>=2)Sample(1,ref pendingB);if(ThreeHumans)Sample(2,ref pendingC);
            if(Input.GetKeyDown(KeyCode.Tab))world.CycleTarget(HumanSeat(0));
            if(HumanCount>=2&&Input.GetKeyDown(KeyCode.RightShift))world.CycleTarget(HumanSeat(1));
            if(ThreeHumans&&Input.GetKeyDown(KeyCode.RightControl))world.CycleTarget(2);
            accumulator=Mathf.Min(accumulator+Time.unscaledDeltaTime,.1f);
            while(accumulator>=Rules.Dt)
            {
                var controls=new Controls[world.Players.Length];
                for(int i=0;i<controls.Length;i++){int controller=ControllerFor(i);controls[i]=controller==0?pendingA:controller==1?pendingB:controller==2?pendingC:world.Players[i].IsBoss?new Controls():world.IsDummy(world.Players[i])?new Controls():Bot(world.Players[i]);}
                world.Tick(controls);pendingA.ClearEdges();pendingB.ClearEdges();pendingC.ClearEdges();accumulator-=Rules.Dt;
                if(world.NeedsSelection){ResolveCpuPicks();accumulator=0;break;}
            }
            if(world.HitSerial!=lastHit){lastHit=world.HitSerial;Sound(hitSound);shake=.12f;}
            if(world.Phase!=lastPhase){if(world.Phase==Phase.RoundOver||world.Phase==Phase.Finished)Sound(koSound);lastPhase=world.Phase;}
            TrackCamera();
        }
        void Sample(int p,ref Controls c)
        {
            c.Move=(Input.GetKey(GameKey(p,1))?1:0)-(Input.GetKey(GameKey(p,0))?1:0);
            c.Guard=Input.GetKey(GameKey(p,7));
            c.Command=Input.GetKey(GameKey(p,4));
            c.Jump|=Input.GetKeyDown(GameKey(p,2));c.Attack=Input.GetKey(GameKey(p,3));
            c.Skill1|=Input.GetKeyDown(GameKey(p,4));c.Skill2|=Input.GetKeyDown(GameKey(p,5));c.Ultimate|=Input.GetKeyDown(GameKey(p,6));
        }
        Controls Bot(Fighter f)
        {
            if(!world.Alive(f)||!world.Alive(world.Enemy(f)))return new Controls();
            Fighter enemy=world.Enemy(f);float dx=enemy.Pos.x-f.Pos.x,dist=Mathf.Abs(dx);
            bool ranged=f.Job==Job.Maestro||f.Job==Job.Prism||f.Job==Job.Poltergeist||f.Job==Job.Alchemist||f.Job==Job.Cybercrud||f.Job==Job.PhantomLegion||f.Job==Job.Puppeteer||f.Job==Job.Archer||f.Job==Job.Magician||f.Job==Job.Thunder||f.Job==Job.CardMan||f.Job==Job.Engineer||f.Job==Job.King||f.Job==Job.Nisemono||f.Job==Job.FrostReaper||f.Job==Job.VoidWalker||world.IsShip(f);
            float move=dist>(ranged?6:1.5f)?Mathf.Sign(dx):dist<3&&ranged?-Mathf.Sign(dx):(Mathf.Abs(dx)>.05f&&f.Facing!=(dx>0?1:-1)?Mathf.Sign(dx):0);
            bool jump=(enemy.Pos.y-f.Pos.y>1.8f&&f.Grounded)||(!f.Grounded&&f.Pos.y<1&&f.Vel.y<0);
            if(Mathf.Abs(f.Pos.x)>10){move=-Mathf.Sign(f.Pos.x);jump|=f.Pos.y<2;}
            // Seeded cadence, no input reading or reaction to hidden button presses.
            int beat=(int)(world.Time*60);bool decision=beat%24==0;
            bool q=decision&&dist<7,e=decision&&dist<6;
            if(f.Job==Job.Nisemono){q=decision;e=decision&&enemy.EmbeddedBlades[f.Id]+enemy.EmbeddedCaladbolgs[f.Id]>0;if(e)q=false;}
            if(f.Job==Job.QinShi){e=decision&&enemy.QinMarkOwner==f.Id&&f.EAt<=world.Time;q=decision&&!e&&enemy.QinMarkOwner==f.Id&&dist>3;}
            if(f.Job==Job.Institutor){e=decision&&f.YangSwords>=3&&f.EAt<=world.Time;q=decision&&!e&&f.YangSwords>1&&dist>6;}
            if(f.Job==Job.Gambler){e=decision&&f.HP>60&&dist<10;q=decision&&!e&&dist<6;}
            if(f.Job==Job.DinoMan){e=decision&&dist<3.8f&&f.EAt<=world.Time;q=decision&&!e&&dist<12;}
            if(f.Job==Job.Luminary){q=decision&&f.LuminaryShards<=6&&f.QAt<=world.Time;e=decision&&enemy.OverwhelmStacks[f.Id]>=3&&f.EAt<=world.Time;}
            return new Controls(move,jump,dist<10,q,e,decision&&f.Gauge>=100);
        }
        void StartMatch()
        {
            Job[] jobs=mode==(int)BattleMode.BossRaid?new[]{ResolveJob(p1),ResolveJob(p2),Job.Grappler}:mode==(int)BattleMode.DpsEvent?new[]{ResolveJob(p1),ResolveJob(p2),Job.Knight,Job.Knight}:ThreeHumans?new[]{ResolveJob(p1),ResolveJob(p2),ResolveJob(p3)}:FourPlayers?new[]{ResolveJob(p1),ResolveJob(p2),ResolveJob(p3),ResolveJob(p4)}:new[]{ResolveJob(p1),ResolveJob(p2)};
            world=new World(jobs,new MatchOptions{Mode=(BattleMode)mode,KillLimit=killGoal,DummyId=1-HumanSeat(0),TeamCoop=teamCoop,EventDuration=eventDuration},stage,UnityEngine.Random.Range(1,1000000));
            menu=paused=settings=false;accumulator=0;pendingA=pendingB=pendingC=new Controls();cam=new V2(0,3);camWidth=29;lastHit=0;lastPhase=Phase.Countdown;
            Sound(selectSound);
        }
        void TrackCamera()
        {
            float minX=float.MaxValue,maxX=float.MinValue,minY=float.MaxValue,maxY=float.MinValue;
            foreach(var f in world.Players)if(!f.Dead){minX=Mathf.Min(minX,f.Pos.x);maxX=Mathf.Max(maxX,f.Pos.x);minY=Mathf.Min(minY,f.Pos.y);maxY=Mathf.Max(maxY,f.Pos.y);}
            if(minX==float.MaxValue){minX=-6;maxX=6;minY=maxY=1;}
            V2 target=new V2((minX+maxX)*.5f,(minY+maxY)*.5f+1.1f);
            target.x=Rules.Clamp(target.x,world.Arena.Left+5,world.Arena.Right-5);target.y=Rules.Clamp(target.y,world.Arena.Bottom+4,world.Arena.Top-4);
            bool ultActive=Array.Exists(world.Players,p=>!p.Dead&&p.UltimateCastingUntil>world.Time);
            float width=Mathf.Clamp(Mathf.Max(maxX-minX+(ultActive?8:10),(maxY-minY+5)*1280/440),ultActive?21:25,96);
            float t=1-Mathf.Exp(-Time.unscaledDeltaTime*5);cam=V2.Lerp(cam,target,t);camWidth=Mathf.Lerp(camWidth,width,1-Mathf.Exp(-Time.unscaledDeltaTime*(width>camWidth?10:4)));
            shake=Mathf.Max(0,shake-Time.unscaledDeltaTime);
            Camera.main.transform.position=new Vector3(cam.x,cam.y,-10);Camera.main.orthographicSize=camWidth*9/32;
        }
        void SaveSettings()
        {
            for(int p=0;p<2;p++)for(int k=0;k<8;k++)PlayerPrefs.SetInt("SB.Key."+p+"."+k,(int)keys[p,k]);
            PlayerPrefs.SetInt("SB.ReducedMotion",reduceMotion?1:0);PlayerPrefs.SetInt("SB.Muted",muted?1:0);PlayerPrefs.Save();
        }
    }
}
