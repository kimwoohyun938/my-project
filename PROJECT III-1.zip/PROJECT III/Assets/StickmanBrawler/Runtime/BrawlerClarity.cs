using UnityEngine;
using StickmanBrawler.Core;

namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        Texture2D slashMask;
        void EnsureClarity()
        {
            if(slashMask)return;
            const int size=192;
            slashMask=new Texture2D(size,size,TextureFormat.RGBA32,false);
            slashMask.wrapMode=TextureWrapMode.Clamp;slashMask.filterMode=FilterMode.Bilinear;
            Color[] pixels=new Color[size*size];
            for(int y=0;y<size;y++)for(int x=0;x<size;x++)
            {
                float px=(x+.5f-size/2f)/(size/2f),py=(y+.5f-size/2f)/(size/2f);
                float angle=Mathf.Atan2(py,px),r=Mathf.Sqrt(px*px+py*py);
                float taper=Mathf.Clamp01(1-Mathf.Abs(angle)/1.4f);
                float outer=.88f,inner=outer-.32f*taper;
                float a=Mathf.Clamp01((outer-r)*size)*Mathf.Clamp01((r-inner)*size)*Mathf.Clamp01(taper*12);
                pixels[y*size+x]=new Color(1,1,1,a);
            }
            slashMask.SetPixels(pixels);slashMask.Apply();
        }
        void Crescent(Vector2 p,float r,float angle,Color c)
        {
            Matrix4x4 saved=GUI.matrix;Color previous=GUI.color;
            try
            {
                GUI.matrix=saved*Matrix4x4.TRS(new Vector3(p.x,p.y,0),Quaternion.Euler(0,0,angle),Vector3.one);
                GUI.color=c;GUI.DrawTexture(new Rect(-r,-r,2*r,2*r),slashMask);
            }
            finally { GUI.matrix=saved;GUI.color=previous; }
        }
        void BrightLine(Vector2 a,Vector2 b,Color c,float width)
        {
            Line(a,b,Alpha(Ink,c.a*.85f),width+4);
            Line(a,b,Alpha(c,c.a*.16f),width*2.4f);
            Line(a,b,c,width);
            Line(a,b,Alpha(Color.white,c.a*.9f),Mathf.Max(1,width*.23f));
        }
        void Sparks(Vector2 p,float radius,float life,Color c,int count=10)
        {
            if(reduceMotion)count=4;
            for(int i=0;i<count;i++)
            {
                float a=i*2.399963f;
                Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));
                float offset=radius*(.2f+life*(.6f+.2f*(i%3)));
                Line(p+d*offset,p+d*(offset+radius*.17f*(1-life)),Alpha(c,c.a*(1-life)),2);
            }
        }
        bool DrawClarityEffect(Effect e,Vector2 p,float k,Color c)
        {
            if(e.Dead)return true;
            bool tell=world.Time<e.ActiveAt;
            float r=Mathf.Max(5,e.Radius*k);
            if(e.Shape==Shape.Shot)
            {
                Vector2 d=new Vector2(e.Vel.x,-e.Vel.y).normalized;
                float trail=Mathf.Clamp(e.Vel.Length*.07f*k,14,95);
                BrightLine(p-d*trail,p,c,Mathf.Max(3,r*.5f));
                Disc(p,r+3,Ink);Disc(p,r,c);Disc(p,r*.38f,Color.white);
                // Layer the existing job-specific weapon silhouette over the readable projectile core.
                return false;
            }
            if(e.Shape==Shape.Beam)
            {DrawEnergyBeam(p,ScreenPoint(e.Pos+e.Vel*e.Width),e.Height*k,c,world.Players[e.Owner].Job);return true;}
            if(e.Tag=="world-beam")return true; // Its full-width beam cue supplies the visual.
            if(e.Tag=="blackhole")
            {
                Disc(p,r,Alpha(c,.2f));Ring(p,r,Alpha(c,.65f),3);Disc(p,r*.45f,Alpha(c,.25f),true);
                Disc(p,r*.27f,Ink);Ring(p,r*.3f,c,5);Ring(p,r*.32f,Color.white,1);
                for(int i=0;i<6;i++)
                {float a=i*Mathf.PI/3+(reduceMotion?0:world.Time*1.6f);Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));BrightLine(p+d*r*.75f,p+d*r*.45f,Alpha(c,.7f),2);}
                return true;
            }
            if(e.Shape==Shape.Zone&&e.Hit!=null)
            {
                Disc(p,r,Alpha(c,tell?.07f:.19f));Ring(p,r,Alpha(Ink,.9f),5);Ring(p,r,Alpha(c,tell?.65f:.9f),3);
                if(!tell)Ring(p,r*.93f,Alpha(Color.white,.55f),1);
                // Non-generic fields retain their own distinctive animation on top.
                return e.Tag==""||e.Tag=="zone";
            }
            return false;
        }
        bool DrawClarityCue(Cue cue,Vector2 p,float k,Color c,float life)
        {
            if(cue.Kind=="slash")
            {
                Vector2 end=ScreenPoint(cue.End),delta=end-p;
                float angle=Mathf.Atan2(delta.y,delta.x)*Mathf.Rad2Deg;
                float r=Mathf.Max(20,cue.Size*k*.7f)*(reduceMotion?1:1+life*.2f);
                Job job=world.Players[cue.Owner].Job;
                if(job==Job.Lancer)
                {BrightLine(p,end,c,Mathf.Max(4,k*.15f));Sparks(end,r*.5f,life,c,6);return true;}
                if(job==Job.Grappler||job==Job.Master||job==Job.QinShi||job==Job.IronWall||job==Job.Vertebrate)
                {BrightLine(p,end,c,Mathf.Max(7,k*.24f));Disc(end,k*.27f,c);Ring(end,k*(.3f+life*.3f),c,3);Sparks(end,r*.45f,life,c,6);return true;}
                if(job==Job.Werewolf||job==Job.DinoMan)
                {Vector2 n=new Vector2(-delta.y,delta.x).normalized*k*.17f;for(int i=-1;i<=1;i++)BrightLine(p+n*i,end+n*i,c,3);Sparks(end,r*.5f,life,c,6);return true;}
                if(job==Job.Nisemono||job==Job.BladeMaster||job==Job.ShadowClone)
                {Crescent(p,r*1.08f,angle-24,Alpha(c,c.a*.65f));Crescent(p,r*.73f,angle+28,Alpha(Color.white,c.a*.6f));}
                Crescent(p,r+3,angle,Alpha(Ink,c.a*.85f));
                Crescent(p,r,angle,Alpha(c,c.a*.9f));
                Crescent(p,r*.91f,angle,Alpha(Color.white,c.a*.8f));
                if(!reduceMotion)Crescent(p,r*1.12f,angle-10,Alpha(c,c.a*.18f));
                Sparks(end,r*.6f,life,c,6);return true;
            }
            if(cue.Kind=="burst")
            {
                float r=Mathf.Max(12,cue.Size*k),expand=reduceMotion?1:.45f+life*.9f;
                Disc(p,r*expand,Alpha(c,.23f*(1-life)),true);
                Ring(p,r*expand,Alpha(Ink,c.a),5);Ring(p,r*expand,c,3);
                if(life<.45f){Disc(p,r*.22f,Alpha(c,.8f*(1-life)));Disc(p,r*.12f,Alpha(Color.white,.9f*(1-life)));}
                Sparks(p,r,life,c);return true;
            }
            if(cue.Kind=="warning")
            {
                float r=cue.Size*k;
                Disc(p,r,Alpha(Gold,.1f));Ring(p,r,Ink,5);Ring(p,r,Gold,3);
                Ring(p,r*(.15f+.85f*life),Alpha(Gold,.5f),2);
                Text(new Rect(p.x-12,p.y-16,24,32),"!",24,Gold,TextAnchor.MiddleCenter,true);return true;
            }
            if(cue.Kind=="warning-line")
            {
                Vector2 end=ScreenPoint(cue.End);BrightLine(p,end,Alpha(c,.6f),2);
                Disc(p,Mathf.Max(10,k*(.2f+life*.5f)),Alpha(c,.4f),true);
                Ring(p,k*(.7f-.4f*life),c,2);return true;
            }
            if(cue.Kind=="gate")
            {
                float r=cue.Size*k;Disc(p,r,Alpha(Gold,.28f));Ring(p,r,Ink,6);Ring(p,r,Gold,4);Ring(p,r*.7f,Alpha(Color.white,c.a),1);
                Sparks(p,r,life,Gold,6);return true;
            }
            if(cue.Kind=="fortune-rune")
            {
                int rank=world.Players[cue.Owner].FortuneResult;
                Color result=rank==2?new Color(.8f,.5f,1):rank==1?Gold:Muted;
                float r=Mathf.Max(24,cue.Size*k);Disc(p,r,Alpha(Ink,.9f));Ring(p,r,result,4);
                Text(new Rect(p.x-r,p.y-r,r*2,r*2),rank==2?"II":rank==1?"I":"-",28,result,TextAnchor.MiddleCenter,true);
                if(rank>0)Sparks(p,r,life,result,rank==2?16:8);return true;
            }
            return false;
        }
        void DrawReadableDamage(Cue cue,Vector2 p,float life)
        {
            // Deterministic lanes prevent simultaneous hits from drawing all numbers on one pixel.
            int lane=0;
            foreach(var other in world.Cues)
            {
                if(object.ReferenceEquals(other,cue))break;
                if(other.Kind=="damage"&&other.Owner==cue.Owner&&Mathf.Abs(other.Start-cue.Start)<.08f&&V2.Distance(other.Pos,cue.Pos)<2)lane++;
            }
            float x=p.x+(lane%3-1)*48,y=p.y-35-life*32-(lane/3)*23;
            Rect r=new Rect(x-66,y,132,29);bool critical=cue.Text.StartsWith("CRIT");
            Color color=critical?Gold:Color.white;Box(r,Alpha(Ink,.8f*(1-life)));
            Text(r,cue.Text,critical?22:20,Alpha(color,1-life),TextAnchor.MiddleCenter,true);
        }
    }
}
