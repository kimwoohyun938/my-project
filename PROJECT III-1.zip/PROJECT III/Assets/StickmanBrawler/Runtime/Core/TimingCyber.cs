using System;
using System.Collections.Generic;
using System.Reflection;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public int CombatTick;
        int activeCast,castSerial;
        readonly Dictionary<int,CastTrace> castTraces=new Dictionary<int,CastTrace>();
        readonly int[] lastCast=new int[4],lastUltimateCast=new int[4];
        readonly DamageReceipt[] receipts=new DamageReceipt[4];
        sealed class CastTrace
        {
            public readonly List<Effect> Summons=new List<Effect>();public int ExecutionSlot;
            public int Swords,Blades,Caladbolgs,Shadow,Marks;public bool Spear,Qin,Dino;public float Mark;
            public int Target=-1;
            public int Id,Owner,Slot,Tick;public Job Kit;public bool Canceled,Persistent,Ship;
            public readonly List<StateDelta> Undo=new List<StateDelta>();
        }
        sealed class DamageReceipt
        {public int Cast,Tick;public float Damage,Stun,Root,Silence;public V2 Position;}
        int ActiveSlot {get{CastTrace c;return castTraces.TryGetValue(activeCast,out c)?c.Slot:0;}}
        bool CastCanceled(int id){CastTrace c;return id!=0&&castTraces.TryGetValue(id,out c)&&c.Canceled;}
        bool TracksTiming {get{return Array.Exists(Players,p=>p.NativeJob==Job.LTiming||p.CopiedPowers[(int)Job.LTiming]>Time);}}
        int PassiveCast(Fighter f){return lastUltimateCast[f.Id];}
        void ResetTiming()
        {castTraces.Clear();activeCast=castSerial=0;Array.Clear(lastCast,0,lastCast.Length);Array.Clear(lastUltimateCast,0,lastUltimateCast.Length);Array.Clear(receipts,0,receipts.Length);}
        bool PersistentUltimate(Job job)
        {
            switch(job)
            {
                case Job.Nisemono:case Job.YiSunGod:case Job.Guardian:case Job.Assassin:
                case Job.Vertebrate:case Job.Director:case Job.Cross:case Job.Reflector:
                case Job.Gambler:case Job.Institutor:case Job.BloodApostle:case Job.IronWall:
                case Job.VoidWalker:case Job.Undying:case Job.MirrorAssassin:case Job.TwinFang:
                case Job.PhantomLegion:case Job.LTiming:case Job.Cybercrud:case Job.Alchemist:case Job.Maestro:case Job.Pendulum:case Job.Tether:case Job.Prism:case Job.Reactor:case Job.Poltergeist:
                case Job.Magician:case Job.Archer:case Job.GravityMage:case Job.Engineer:case Job.Zephyr:case Job.Luminary:return true;
                default:return false;
            }
        }
        void RunAction(Fighter f,int slot,Action body)
        {
            // A copied kit remains part of the same action, not a second cast.
            if(activeCast!=0)
            {
                CastTrace parent;
                if(castTraces.TryGetValue(activeCast,out parent)&&parent.Owner==f.Id&&parent.Kit==Job.Mimic)
                {parent.Kit=f.Job;parent.ExecutionSlot=slot;parent.Persistent=slot==3&&PersistentUltimate(f.Job);}
                body();return;
            }
            var c=new CastTrace{Id=++castSerial,Owner=f.Id,Slot=slot,Tick=CombatTick,Kit=f.Job,
                Target=Enemy(f).Id,Persistent=slot==3&&PersistentUltimate(f.Job),Ship=IsShip(f)};
            c.ExecutionSlot=slot;
            foreach(var summon in Effects)if(summon.Owner==f.Id&&!summon.Dead&&summon.Shape==Shape.Summon){var payload=CloneEffect(summon);payload.Pos=summon.Pos-f.Pos;c.Summons.Add(payload);}
            c.Swords=f.YangSwords;c.Spear=f.HasSpear;var target=Enemy(f);
            c.Blades=target.EmbeddedBlades[f.Id];c.Caladbolgs=target.EmbeddedCaladbolgs[f.Id];c.Shadow=target.ShadowMarks[f.Id];c.Marks=target.CyberMarks[f.Id];
            c.Qin=target.QinMarkOwner==f.Id;c.Dino=target.DinoMarkOwner==f.Id;c.Mark=target.MarkUntil;
            castTraces.Add(c.Id,c);
            if(slot>0)lastCast[f.Id]=c.Id;
            if(slot==3)lastUltimateCast[f.Id]=c.Id;
            using(CastScope(c.Id))body();
        }
        // A short, per-action mutation journal. It does not restore the clock,
        // random generator, opponent input, or a whole-world snapshot.
        sealed class StateDelta
        {
            public object Target;public FieldInfo Field;public object Before,After;public int Index=-1;
            object Current(){return Index<0?Field.GetValue(Target):((Array)Field.GetValue(Target)).GetValue(Index);}
            void Set(object value){if(Index<0)Field.SetValue(Target,value);else ((Array)Field.GetValue(Target)).SetValue(value,Index);}
            public void Undo()
            {
                object current=Current();string n=Field.Name;
                // HP and resources use a delta so unrelated hits/heals survive.
                if(Before is float&&(n=="HP"||n=="Gauge"||n=="Health"))
                {float restored=(float)current+(float)Before-(float)After;var f=Target as Fighter;if(f!=null)restored=Rules.Clamp(restored,0,n=="HP"?f.MaxHP:100);Set(restored);}
                else if(n=="Pos"&&Before is V2)Set((V2)current+(V2)Before-(V2)After);
                else if(Equals(current,After))Set(Before);
            }
        }
        sealed class StateSample
        {
            public object Target;public FieldInfo Field;public object Value;public int Index=-1;
            public object Current(){return Index<0?Field.GetValue(Target):((Array)Field.GetValue(Target)).GetValue(Index);}
        }
        static readonly FieldInfo[] fighterFields=typeof(Fighter).GetFields(BindingFlags.Instance|BindingFlags.Public);
        static readonly FieldInfo[] effectFields=typeof(Effect).GetFields(BindingFlags.Instance|BindingFlags.Public);
        static void Sample(List<StateSample> list,object target,FieldInfo[] fields)
        {
            foreach(var field in fields)
            {
                object value=field.GetValue(target);
                var array=value as Array;
                if(array!=null){for(int i=0;i<array.Length;i++)list.Add(new StateSample{Target=target,Field=field,Index=i,Value=array.GetValue(i)});}
                else if(!field.IsInitOnly&&(field.FieldType.IsValueType||field.FieldType==typeof(string)))
                    list.Add(new StateSample{Target=target,Field=field,Value=value});
            }
        }
        sealed class ActionScope:IDisposable
        {
            readonly World w;readonly int previous,id;readonly List<StateSample> samples;
            readonly HashSet<Effect> oldEffects;
            public ActionScope(World world,int action)
            {
                w=world;previous=w.activeCast;id=action;w.activeCast=action;
                CastTrace c;
                if(action!=previous&&w.TracksTiming&&w.castTraces.TryGetValue(action,out c)&&c.Slot>0&&w.CombatTick-c.Tick<=3&&!c.Canceled)
                {
                    samples=new List<StateSample>();foreach(var f in w.Players)Sample(samples,f,fighterFields);
                    oldEffects=new HashSet<Effect>(w.Effects);
                    foreach(var e in w.Effects)if(e.CastId!=action)Sample(samples,e,effectFields);
                    foreach(string name in new[]{"DuelUntil","DuelOwner","DuelTarget","DuelCenter"})
                    {var field=typeof(World).GetField(name);samples.Add(new StateSample{Target=w,Field=field,Value=field.GetValue(w)});}
                }
            }
            public void Dispose()
            {
                foreach(var effect in w.Effects)if(effect.CastId==id&&id!=0&&effect.Hit!=null&&effect.Hit.CastId==0){effect.Hit.CastId=id;effect.Hit.Slot=w.ActiveSlot;}
                if(samples!=null)
                {
                    CastTrace c=w.castTraces[id];
                    foreach(var s in samples)
                    {object after=s.Current();if(!Equals(s.Value,after))c.Undo.Add(new StateDelta{Target=s.Target,Field=s.Field,Index=s.Index,Before=s.Value,After=after});}
                    foreach(var e in w.Effects)if(!oldEffects.Contains(e)){if(e.CastId==0)e.CastId=id;if(e.Hit!=null&&e.Hit.CastId==0){e.Hit.CastId=id;e.Hit.Slot=c.Slot;}}
                }
                w.activeCast=previous;
            }
        }
        IDisposable CastScope(int id){return new ActionScope(this,id);}
        void CancelCast(CastTrace c,bool rollback)
        {
            c.Canceled=true;pendingReactions.RemoveAll(p=>p.CastId==c.Id);
            if(rollback)for(int i=c.Undo.Count-1;i>=0;i--)
            {c.Undo[i].Undo();var restored=c.Undo[i].Target as Effect;if(restored!=null&&!restored.Dead&&restored.Expires>Time&&!Effects.Contains(restored)&&restored.CastId!=c.Id)Effects.Add(restored);}
            foreach(var e in Effects)if(e.CastId==c.Id||(e.Hit!=null&&e.Hit.CastId==c.Id))e.Dead=true;
            scheduled.RemoveAll(s=>s.CastId==c.Id);
            Fighter source=Players[c.Owner];
            if(lastCast[c.Owner]==c.Id||lastUltimateCast[c.Owner]==c.Id)
            {source.CastUntil=Time;source.UltimateCastingUntil=Time;source.InterruptVersion++;}
            c.Undo.Clear();
        }
        void UpdateTimingTimers()
        {
            foreach(var f in Players)
            {
                if(f.TimingUltUntil>0&&Time>=f.TimingUltUntil)
                {f.QAt=Time+Math.Max(0,f.QAt-Time)*1.5f;f.EAt=Time+Math.Max(0,f.EAt-Time)*1.5f;f.TimingUltUntil=0;Cue(f.Pos,"타이밍 종료","text",f.Id);}
            }
            // Only the three-tick interception window needs state deltas.
            foreach(var c in castTraces.Values)if(CombatTick-c.Tick>3)c.Undo.Clear();
            if(CombatTick%120==0)
            {
                var live=new HashSet<int>(lastCast);foreach(int id in lastUltimateCast)live.Add(id);
                foreach(var e in Effects){live.Add(e.CastId);if(e.Hit!=null)live.Add(e.Hit.CastId);}
                foreach(var s in scheduled)live.Add(s.CastId);
                foreach(var reaction in pendingReactions)live.Add(reaction.CastId);
                foreach(var receipt in receipts)if(receipt!=null)live.Add(receipt.Cast);
                var remove=new List<int>();foreach(var c in castTraces.Values)if(CombatTick-c.Tick>3&&!live.Contains(c.Id))remove.Add(c.Id);
                foreach(int id in remove)castTraces.Remove(id);
            }
        }
        float TimingCooldown(Fighter f,float seconds){return seconds*(f.TimingUltUntil>Time?.5f:1);}
        public bool TimingReturnReady(Fighter f)
        {if(RemoteView)return f.Id<2&&RemoteReturn[f.Id];var r=receipts[f.Id];return r!=null&&CombatTick-r.Tick<=1&&!CastCanceled(r.Cast)&&f.QAt<=Time;}
        public bool TimingInterceptReady(Fighter f)
        {if(RemoteView)return f.Id<2&&RemoteIntercept[f.Id];CastTrace c;return castTraces.TryGetValue(lastCast[Enemy(f).Id],out c)&&c.Slot>0&&!c.Canceled&&CombatTick-c.Tick<=3&&f.EAt<=Time;}
        bool TimingGrace(Fighter f)
        {return f.NativeJob==Job.LTiming&&f.SilenceUntil<=Time&&f.SkillLockUntil<=Time&&((TimingReturnReady(f)&&CombatTick==receipts[f.Id].Tick)||TimingInterceptReady(f));}
        void ProcessTimingInput(Fighter f,Controls input)
        {
            if(input.Guard||f.NativeJob!=Job.LTiming||f.Dead||(input.Ultimate&&!InHitstop(f)&&!InHitstun(f))||f.StunUntil>Time)return;
            // Incoming stun starts after the counter grace window. Existing explicit stun,
            // silence and explicit slot locks still prevent counters.
            if(f.SilenceUntil>Time||f.SkillLockUntil>Time)return;
            if(input.Skill1&&f.QAt<=Time&&f.SlotLockedUntil[1]<=Time)Skill1(f);
            else if(input.Skill2&&f.EAt<=Time&&f.SlotLockedUntil[2]<=Time)Skill2(f);
        }
        void TimingReturn(Fighter f)
        {
            var receipt=receipts[f.Id];bool valid=TimingReturnReady(f);
            f.QAt=Time+TimingCooldown(f,valid?8:5);
            if(!valid){Cue(f.Pos,"리턴 실패","text",f.Id,1,.65f);return;}
            CastTrace c=castTraces[receipt.Cast];CancelCast(c,false);
            f.HitstopEndTick=0;f.HitstunUntil=Time;
            f.Pos=receipt.Position;f.RootPos=f.Pos;f.Vel=new V2();f.RecoilUntil=Time;
            f.StunUntil=receipt.Stun;f.RootUntil=receipt.Root;f.SilenceUntil=receipt.Silence;
            f.HP=Math.Min(f.MaxHP,f.HP+receipt.Damage);
            Fighter foe=Players[c.Owner];float floor=foe.UndyingUntil>Time?1:0;
            foe.HP=Math.Max(floor,foe.HP-(foe.IsBoss?Math.Min(600,receipt.Damage):receipt.Damage));foe.LastAttacker=f.Id;foe.LastAttackedAt=Time;
            if(foe.UndyingUntil>Time)foe.UndyingDebt+=receipt.Damage;
            receipts[f.Id]=null;
            Cue(f.Pos,"리턴 성공 +"+Math.Round(receipt.Damage),"timing-return",f.Id,2,.8f,foe.Pos);
        }
        void TimingIntercept(Fighter f)
        {
            CastTrace c;bool valid=TimingInterceptReady(f)&&castTraces.TryGetValue(lastCast[Enemy(f).Id],out c);
            f.EAt=Time+TimingCooldown(f,6);
            if(!valid){Cue(f.Pos,"인터셉트 실패","text",f.Id,1,.65f);return;}
            c=castTraces[lastCast[Enemy(f).Id]];
            // Capture identity before undoing the enemy's last-action fields.
            Job kit=c.Kit;int slot=c.ExecutionSlot;bool ship=c.Ship;
            CancelCast(c,true);Players[c.Owner].SlotLockedUntil[c.Slot]=Time+10;
            Cue(f.Pos,"인터셉트 / "+(c.Slot==1?"Q":c.Slot==2?"E":"R")+" 10초 봉쇄","timing-steal",f.Id,2,1,Enemy(f).Pos);
            if(kit==Job.LTiming&&slot<3)return; // no recursive counter-copy loop
            f.CopiedPowers[(int)kit]=Time+(slot==3?PowerDuration(kit):20);
            if(slot==3){f.CopiedPowerJob=(int)kit;f.CopiedPowerUntil=Time+PowerDuration(kit);}
            float q=f.QAt,e=f.EAt;int context=activeCast;
            // Copy through the same skill path; it can itself be intercepted.
            activeCast=0;
            try
            {
                WithKit(f,kit,1,()=>RunAction(f,slot,()=>
                {
                    Fighter target=Enemy(f);
                    foreach(var payload in c.Summons)
                    {
                        if(FindSummon(f,payload.Tag)!=null&&payload.Tag!="phantom")continue;
                        var summon=CloneEffect(payload);summon.Owner=f.Id;summon.CastId=activeCast;
                        summon.Pos=f.Pos+new V2(-payload.Pos.x,payload.Pos.y);summon.Origin=f.Pos;
                        if(summon.Hit!=null)summon.Hit.Owner=f.Id;Effects.Add(summon);
                    }
                    if(kit==Job.Institutor)f.YangSwords=c.Swords;
                    if(kit==Job.Lancer)f.HasSpear=c.Spear;
                    if(kit==Job.Nisemono){target.EmbeddedBlades[f.Id]=c.Blades;target.EmbeddedCaladbolgs[f.Id]=c.Caladbolgs;}
                    if(kit==Job.QinShi&&c.Qin)target.QinMarkOwner=f.Id;
                    if(kit==Job.DinoMan&&c.Dino){target.DinoMarkOwner=f.Id;target.DinoMarkUntil=Time+8;}
                    if(kit==Job.ShadowClone)target.ShadowMarks[f.Id]=c.Shadow;
                    if(kit==Job.Cybercrud)target.CyberMarks[f.Id]=c.Marks;
                    if(kit==Job.Depth||kit==Job.Director)target.MarkUntil=Math.Max(Time+1,c.Mark);
                    if(ship&&kit==Job.YiSunGod&&slot<3)
                    {if(slot==1)RunAction(f,1,()=>ShipLaser(f));else RunAction(f,2,()=>Control(Enemy(f),CC.Slow,3,.8f));}
                    else if(slot==1)Skill1(f);else if(slot==2)Skill2(f);else Ultimate(f);
                }));
            }
            finally{activeCast=context;f.QAt=q;f.EAt=e;}
        }
        static Effect CloneEffect(Effect original)
        {
            var copy=new Effect();foreach(var field in effectFields)if(!field.IsInitOnly)field.SetValue(copy,field.GetValue(original));
            if(original.Hit!=null)copy.Hit=original.Hit.Copy();return copy;
        }
        void ShipLaser(Fighter f){Beam(f,50,16,false,5);Effects[Effects.Count-1].Height=.6f;}
        void TimingUltimate(Fighter f)
        {
            if(f.TimingUltUntil<=Time){f.QAt=Time+Math.Max(0,f.QAt-Time)*.5f;f.EAt=Time+Math.Max(0,f.EAt-Time)*.5f;}
            f.TimingUltUntil=Time+15;Cue(f.Pos,"퍼펙트 타이밍 · 15초","timing-ult",f.Id,2,1);
        }
        void TimingCyberOnHit(Fighter source,Fighter victim,Hit hit,float actual,V2 before,float stun,float root,float silence)
        {
            CastTrace cast;
            if(actual>0&&hit.Slot==0&&!hit.Reflected&&!hit.Summoned)
            {
                source.BasicLandedTick=CombatTick;source.BasicLandedTarget=victim.Id;
                if(victim.BasicLandedTick==CombatTick&&victim.BasicLandedTarget==source.Id)
                    foreach(var p in new[]{source,victim})if(p.NativeJob==Job.LTiming){p.TimingCritReady=true;p.TimingCritTick=CombatTick;Cue(p.Pos,"교차 적중 · 다음 1타 70%","text",p.Id,1,.8f);}
            }
            if(actual>0&&victim.NativeJob==Job.LTiming&&hit.Slot>0&&!hit.Reflected&&hit.Tag!="burn"&&hit.Tag!="yi-burn"&&castTraces.TryGetValue(hit.CastId,out cast)&&!cast.Persistent)
                receipts[victim.Id]=new DamageReceipt{Cast=hit.CastId,Tick=CombatTick,Damage=actual,Position=before,Stun=stun,Root=root,Silence=silence};
            if(hit.Tag=="cyber-throttle")
            {if(!ImmuneControl(victim))victim.CyberSlowUntil=Time+(HasPower(victim,Job.Knight)&&victim.BuffUntil>Time?2:4);source.CyberHasteUntil=Time+4;Cue(victim.Pos,"스로틀 -30%","text",source.Id);}
            if(!hit.Tag.StartsWith("code:"))return;
            string code=hit.Tag.Substring(5);
            switch(code)
            {
                case "void":
                    V2 center=victim.Pos+new V2(victim.Pos.x>=source.Pos.x?1.6f:-1.6f,0);
                    Effects.Add(new Effect{CastId=activeCast,Owner=source.Id,Shape=Shape.Zone,Pos=center,Radius=2,Pull=30,Expires=Time+.45f,Tag="code-hole"});break;
                case "for":source.AttackAt=Time;break;
                case "return":victim.CyberMarks[source.Id]=Math.Min(4,victim.CyberMarks[source.Id]+1);Cue(victim.Pos,"죽음의 표식 "+victim.CyberMarks[source.Id]+"/4","text",source.Id);break;
            }
        }
        public static int CyberCodeIndex(float roll)
        {return roll<.30f?0:roll<.47f?1:roll<.63f?2:roll<.73f?3:roll<.82f?4:roll<.92f?5:6;}
        public static readonly string[] CyberCodes={"using","void","for","private","static","Error","return"};
        static readonly float[] CyberDamage={40,45,35,45,50,55,100};
        void CyberBasic(Fighter f)
        {
            int code=CyberCodeIndex(Roll());CC control=code==3?CC.Root:code==4?CC.Stun:code==5?CC.Silence:CC.None;
            var e=Shoot(f,CyberDamage[code],18,.25f,0,false,"code:"+CyberCodes[code],control,.8f,direction:(Enemy(f).Pos-f.Pos).Normal);
            e.Hit.Physical=false;e.Hit.FixedGauge=11f;
        }
        void CyberZone(Fighter f)
        {
            foreach(var e in Effects)if(e.Owner==f.Id&&e.Tag=="cyber-zone")e.Dead=true;
            Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Zone,Pos=f.Pos,Radius=3,Expires=Time+3.5f,Tag="cyber-zone"});
        }
        public bool InsideCyberZone(Fighter f)
        {foreach(var e in Effects)if(e.Owner==f.Id&&!e.Dead&&e.Expires>Time&&e.Tag=="cyber-zone"&&V2.Distance(f.Pos,e.Pos)<=e.Radius)return true;return false;}
        float CyberAttackInterval(Fighter f,float interval)
        {
            if(InsideCyberZone(f)||f.CyberHasteUntil>Time)interval=Math.Min(interval,.65f);
            if(f.CyberUltUntil>Time)interval=Math.Min(interval,f.CyberUltInterval);
            return interval;
        }
        void CyberThrottle(Fighter f)
        {var e=Shoot(f,0,13,.7f,0,false,"cyber-throttle",CC.Slow,4,direction:(Enemy(f).Pos-f.Pos).Normal);e.Hit.Slow=.7f;e.Hit.Stun=0;e.Hit.Knock=0;e.Hit.Physical=false;}
        void CyberUltimate(Fighter f)
        {
            Fighter target=Enemy(f);int marks=target.CyberMarks[f.Id];if(marks<1)return;
            target.CyberMarks[f.Id]=0;f.CyberUltUntil=Time+5;f.CyberUltInterval=marks==1?.6f:marks==2?.5f:.4f;
            var hit=StatusHit(f,marks==1?CC.Root:CC.Stun,marks==1?2:marks==4?4:3,true);
            bool landed=ApplyHit(target,hit);
            if(landed&&((marks==3&&target.HP<150)||(marks==4&&target.HP<300)))
            {var execution=MakeHit(f,target.HP,0,true);execution.TrueDamage=true;execution.BypassOneHitShield=true;execution.Tag="cyber-execute";ApplyHit(target,execution);}
            Cue(target.Pos,"데스 리턴 · "+marks+"단계","cyber-execute",f.Id,marks,1);
        }
    }
}
