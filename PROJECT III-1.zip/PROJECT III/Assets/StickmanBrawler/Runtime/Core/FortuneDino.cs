using System;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public int Fortune(Fighter f)
        { return HasPower(f,Job.Gambler)&&f.FortuneUntil>Time?f.FortuneRank:0; }

        // One exclusive combat outcome: greater 1/77, normal 1/7; exclusive, one roll.
        public static int FortuneOutcome(float value)
        { return value<1f/77f?2:value<1f/77f+1f/7f?1:0; }

        void ActivateFortune(Fighter f)
        {
            int rank=FortuneOutcome(Roll());f.FortuneRank=rank;f.FortuneResult=rank;f.FortuneResultUntil=Time+4;
            f.FortuneUntil=rank>0?Time+7.77f:0;
            if(rank==2)
            {
                f.StunUntil=f.RootUntil=f.SilenceUntil=f.SkillLockUntil=f.SlowUntil=0;
                f.SlowFactor=1;f.RecoilUntil=0;f.Vel=new V2();
            }
            Cue(f.Pos,rank==2?"GREATER AWAKENING":rank==1?"AWAKENING":"RUNE FADED","text",f.Id,1,1.2f);
            Cue(f.Pos,"","fortune-rune",f.Id,rank==2?2:1,.8f);
        }
    }
}
