using System;
using System.Collections.Generic;

namespace StickmanBrawler.Core
{
    // Engine-independent deterministic fixed-step combat. Positions are in metres.
    public struct V2
    {
        public float x, y;
        public V2(float x, float y) { this.x = x; this.y = y; }
        public float Length { get { return (float)Math.Sqrt(x * x + y * y); } }
        public V2 Normal { get { float n = Length; return n < .0001f ? new V2(1, 0) : this / n; } }
        public static V2 operator +(V2 a, V2 b) { return new V2(a.x+b.x,a.y+b.y); }
        public static V2 operator -(V2 a, V2 b) { return new V2(a.x-b.x,a.y-b.y); }
        public static V2 operator *(V2 a, float s) { return new V2(a.x*s,a.y*s); }
        public static V2 operator /(V2 a, float s) { return new V2(a.x/s,a.y/s); }
        public static float Distance(V2 a, V2 b) { return (a-b).Length; }
        public static V2 Lerp(V2 a,V2 b,float t) { return a+(b-a)*Rules.Clamp(t,0,1); }
    }
    public static class Rules
    {
        public const float Dt = 1f/60f, Gravity = 32, Jump = 13.8f;
        public const int TargetScore = 5;
        public const float UltimateDamageScale=1.2f,PassiveGaugePerSecond=1.6f,DealtGaugePerHP=.13f,ReceivedGaugePerHP=.065f;
        public const float UltimateBeamHeight=12f,HassanUltimateReach=18f,KingShotGap=.08f;
        public static float Clamp(float v,float lo,float hi) { return Math.Max(lo,Math.Min(hi,v)); }
        public static float Approach(float a,float b,float step) { return a < b ? Math.Min(a+step,b) : Math.Max(a-step,b); }
        public static float Knockback(float hp,float maxHp) { return 1+1.65f*(1-Clamp(hp/maxHp,0,1)); }
        public static float ControlScale(int chain) { return chain==0?1:chain==1?.5f:chain==2?.25f:0; }
        public static bool SegmentCircle(V2 a,V2 b,V2 p,float radius)
        { V2 ab=b-a; float n=ab.x*ab.x+ab.y*ab.y; float t=n<.00001f?0:Clamp(((p.x-a.x)*ab.x+(p.y-a.y)*ab.y)/n,0,1);return V2.Distance(a+ab*t,p)<=radius; }
    }
    public enum Job { Knight,Berserker,Samurai,BladeMaster,Lancer,Archer,GravityMage,Thunder,Magician,Assassin,Hassan,Dystopia,TimeMurder,CardMan,Guardian,Reflector,Grappler,King,Werewolf,Vertebrate,Director,Depth,Cross,Master,Engineer,Zephyr,QinShi,Nisemono,YiSunGod,Institutor,Gambler,DinoMan,FrostReaper,BloodApostle,ShadowClone,IronWall,VoidWalker,Undying,MirrorAssassin,TwinFang,PhantomLegion,Mimic,Puppeteer,LTiming,Cybercrud,Alchemist,Ronin,Maestro,Pendulum,Tether,Prism,Reactor,Poltergeist,Rider,Luminary }
    public enum Phase { Countdown,Fight,RoundOver,Finished }
    public enum CC { None,Stun,Root,Silence,SkillLock,Slow }
    public enum Shape { Shot,Zone,Beam,Trap,Wall,Turret,Wind,Spear,Summon }
    public struct Controls
    {
        public float Move;
        public bool Jump,Attack,Skill1,Skill2,Ultimate,Command,Guard;
        public Controls(float move,bool jump=false,bool attack=false,bool q=false,bool e=false,bool r=false)
        { Move=move;Jump=jump;Attack=attack;Skill1=q;Skill2=e;Ultimate=r;Command=Guard=false; }
        public void ClearEdges() { Jump=Skill1=Skill2=Ultimate=false; }
    }
    public sealed class Platform
    {
        public float X,Y,Width;
        public Platform(float x,float y,float width) { X=x;Y=y;Width=width; }
    }
    public sealed class Arena
    {
        public string Name;
        public bool Closed;
        public const int Count=6;
        public Platform[] Platforms;
        // Blast zone is fixed in world coordinates; camera never changes it.
        public float Left=-19,Right=19,Bottom=-11,Top=16;
        public static Arena Create(int index)
        {
            if(index>=3)
            {
                var a=new Arena{Closed=true,Left=-16,Right=16,Bottom=0,Top=14,
                    Name=index==3?"IRON COURT / HP ONLY":index==4?"MIRROR HALL / HP ONLY":"SKY DOME / HP ONLY"};
                a.Platforms=index==3?new[]{new Platform(0,0,32)}:
                    index==4?new[]{new Platform(0,0,32),new Platform(-7,3,6),new Platform(7,3,6)}:
                    new[]{new Platform(0,0,32),new Platform(-8,3,5),new Platform(0,5.5f,5),new Platform(8,3,5)};
                return a;
            }
            if(index==1)return new Arena{Name="SKY FOUNDRY",Platforms=new[]{new Platform(-6,0,9),new Platform(6,0,9),new Platform(0,3.4f,5),new Platform(-9,5.5f,4),new Platform(9,5.5f,4)}};
            if(index==2)return new Arena{Name="LAST SANCTUM",Platforms=new[]{new Platform(0,0,23),new Platform(-7,3.4f,5),new Platform(7,3.4f,5),new Platform(0,6.4f,5)}};
            return new Arena{Name="NEON ROOFTOP",Platforms=new[]{new Platform(0,0,24),new Platform(-6,3.5f,5),new Platform(6,3.5f,5)}};
        }
    }
    public sealed class Fighter
    {
        public bool Guarding;
        public readonly int[] BufferedUntil=new int[5]; // jump, Q, E, R, basic; simulation ticks

        public float TimingUltUntil,CyberHasteUntil,CyberUltUntil,CyberUltInterval=.8f,CyberSlowUntil;
        public readonly int[] CyberMarks=new int[4];
        public readonly float[] SlotLockedUntil=new float[4];
        public int BasicLandedTarget=-1;
        public int BasicLandedTick=-100,TimingCritTick=-100;
        public bool TimingCritReady;
        public bool IsBoss;public float BossHealthBonus;
        public int TeamId,TargetId=-1,LastAttacker=-1,DoomOwner=-1;
        public float LastAttackedAt=-100,RespawnAt;
        public bool AwaitingPick;
        public int InterruptVersion;
        public int Id,Facing=1,Score,Jumps,CCChain,Combo,Card,Deity=-1;
        public Job Job;
        public Definition Def { get { return Roster.Get(NativeJob); } }
        public V2 Pos,Vel;
        public readonly Job NativeJob;
        public int CopiedPowerJob=-1,LastSkillJob=-1,LastSkillSlot,LastUltimateJob=-1;
        public float RapidScale=1;
        public float CopyScale=1,CopiedPowerUntil,LastSkillTime=-100,LastUltimateTime=-100;
        public Job PowerJob { get { return Job!=NativeJob?Job:CopiedPowerJob>=0?(Job)CopiedPowerJob:Job; } }
        public float ChronoStart,ChronoUntil,RapidBudget,NextRapidVisual;
        public float UndyingGuardUntil,UndyingHealGuardUntil,UndyingUntil,UndyingDebt;
        public float MirrorFadeUntil,MirrorUltUntil,NextMirrorSwap,TwinUltUntil,DisguiseUntil;
        public float PuppetMove,PuppetLift;public bool PuppetCommand;
        public readonly float[] CopiedPowers=new float[55];
        public int LuminaryShards,LuminaryTargetId=-1;
        public float LuminaryDashUntil;
        public V2 LuminaryDashOrigin;
        public readonly int[] OverwhelmStacks=new int[4];
        public int MaestroTempo,MaestroLastSlot,TetherTarget=-1,PoltergeistDebris;
        public float MaestroBeatStart,MaestroBeatEnd,MaestroTempoUntil,MaestroFinaleUntil;
        public float PendulumSwingUntil,PendulumOrbitUntil,NextPendulumTick;
        public float TetherUntil,PrismBuffUntil;
        public float ReactorHeat,ReactorGuardUntil,ReactorUltUntil;
        public float PoltergeistStormUntil,RiderPegasusUntil,GorgonSlowUntil;
        public bool LancerGutsUsed;
        public float LancerFuryUntil,LancerCurseUntil,ArcherHasteUntil;
        public int ArcherShots;
        public readonly int[] AlchemyStacks=new int[4];
        public float AlchemistHasteUntil,AlchemistUltUntil,RoninWindUntil;
        public bool RoninDrawReady;
        public int BladeSerial;public float SpearRecallAt;
        public int HitstopEndTick,HitstopStartTick;
        public float HitstopPoseTime;
        public float HP,Gauge,AttackAt,QAt,EAt,UltAt,HitstunUntil,StunUntil,RootUntil,SilenceUntil,SkillLockUntil,SlowUntil,SlowFactor=1;
        public float CCResetAt,InvulnUntil,ArmorUntil,BuffUntil,Buff2Until,FormUntil,ReflectUntil,ParryUntil,ShieldUntil,GuardUntil;
        public float DodgeUntil,StealthUntil,CritUntil,MarkUntil,DoomAt,DoomStartHP,LastHitAt=-100,CastUntil,RecoilUntil,LastGrounded=-10;
        public float SigilDamageTaken,BodyScale=1;
        public float AirUntil,CounterBonusUntil,HitFlashUntil,AttackVisualUntil,ComboUntil;
        public int QinMarkOwner=-1,RealmVolleyIndex;
        public float KnockbackBonus,AvalonReadyAt,RealmUntil,NextRealmVolley;
        public bool AvalonActive;
        public int YangSwords,BurnOwner=-1,BurnTicks;
        public float NextYangAt,YangSprintUntil,YangUltimateUntil,NextBurnAt;
        public float UltimateCastingUntil;
        public int FortuneRank,DinoMarkOwner=-1;
        public float FortuneUntil,CoinCritUntil,DinoMarkUntil;
        public int FortuneResult=-1;
        public float FortuneResultUntil,FreezeUntil,FrostThawAt;
        public int FrostThawOwner=-1;
        public readonly int[] FrostHits=new int[4],ShadowMarks=new int[4],ShadowCycles=new int[4];
        public float BloodBoostUntil,BloodGuardUntil,BloodStoredDamage,BloodUltUntil,MaxHPBonus;
        public bool BloodReviveArmed,BloodReviveUsed;
        public float ShadowAssaultUntil,IronPassiveShield,IronActiveShield,IronShieldUntil,IronGuardUntil,IronUltUntil;
        public float VoidRecastUntil,VoidPhaseUntil;
        public bool VoidRecastAvailable;
        public float MaxHP { get { return Def.HP+MaxHPBonus+BossHealthBonus; } }
        public readonly int[] EmbeddedBlades=new int[4],EmbeddedCaladbolgs=new int[4];
        public V2 RootPos;
        public bool Overclock,HasSpear=true,NextCrit,Dead,Grounded;
        public string LastAction="READY";
        public Fighter(int id,Job job) { Id=id;Job=NativeJob=job; }
        public void Reset(float now,float hp=-1)
        {
            TimingUltUntil=CyberHasteUntil=CyberUltUntil=CyberSlowUntil=0;CyberUltInterval=.8f;
            Array.Clear(CyberMarks,0,CyberMarks.Length);Array.Clear(AlchemyStacks,0,AlchemyStacks.Length);Array.Clear(OverwhelmStacks,0,OverwhelmStacks.Length);Array.Clear(SlotLockedUntil,0,4);
            AlchemistHasteUntil=AlchemistUltUntil=RoninWindUntil=0;RoninDrawReady=false;
            MaestroTempo=MaestroLastSlot=PoltergeistDebris=0;TetherTarget=-1;
            MaestroBeatStart=MaestroBeatEnd=MaestroTempoUntil=MaestroFinaleUntil=0;
            PendulumSwingUntil=PendulumOrbitUntil=NextPendulumTick=0;
            TetherUntil=PrismBuffUntil=ReactorHeat=ReactorGuardUntil=ReactorUltUntil=0;
            PoltergeistStormUntil=RiderPegasusUntil=GorgonSlowUntil=0;
            LancerGutsUsed=false;LancerFuryUntil=LancerCurseUntil=ArcherHasteUntil=0;ArcherShots=0;LuminaryShards=0;LuminaryTargetId=-1;LuminaryDashUntil=0;LuminaryDashOrigin=new V2();
            BasicLandedTarget=-1;BasicLandedTick=TimingCritTick=-100;TimingCritReady=false;
            TargetId=LastAttacker=DoomOwner=-1;LastAttackedAt=-100;RespawnAt=0;AwaitingPick=false;
            Array.Clear(CopiedPowers,0,CopiedPowers.Length);
            CopiedPowerJob=LastSkillJob=LastUltimateJob=-1;LastSkillSlot=0;CopyScale=RapidScale=1;
            CopiedPowerUntil=ChronoStart=ChronoUntil=RapidBudget=NextRapidVisual=0;
            LastSkillTime=LastUltimateTime=-100;
            UndyingGuardUntil=UndyingHealGuardUntil=UndyingUntil=UndyingDebt=0;
            MirrorFadeUntil=MirrorUltUntil=NextMirrorSwap=TwinUltUntil=DisguiseUntil=0;
            PuppetMove=PuppetLift=0;PuppetCommand=false;BladeSerial=0;SpearRecallAt=0;
            InterruptVersion++;SigilDamageTaken=0;BodyScale=1;Pos=new V2(Id==0?-6:6,1);Vel=new V2();Facing=Id==0?1:-1;
            QinMarkOwner=-1;KnockbackBonus=AvalonReadyAt=RealmUntil=NextRealmVolley=0;AvalonActive=false;RealmVolleyIndex=0;
            YangSwords=BurnTicks=0;BurnOwner=-1;NextYangAt=now+3;YangSprintUntil=YangUltimateUntil=NextBurnAt=0;
            FortuneResult=-1;FortuneResultUntil=FreezeUntil=FrostThawAt=0;FrostThawOwner=-1;
            Array.Clear(FrostHits,0,FrostHits.Length);Array.Clear(ShadowMarks,0,ShadowMarks.Length);Array.Clear(ShadowCycles,0,ShadowCycles.Length);
            BloodBoostUntil=BloodGuardUntil=BloodStoredDamage=BloodUltUntil=MaxHPBonus=0;
            ShadowAssaultUntil=IronPassiveShield=IronActiveShield=IronShieldUntil=IronGuardUntil=IronUltUntil=0;
            VoidRecastUntil=VoidPhaseUntil=0;VoidRecastAvailable=false;
            UltimateCastingUntil=0;FortuneRank=0;FortuneUntil=CoinCritUntil=DinoMarkUntil=0;DinoMarkOwner=-1;
            Array.Clear(EmbeddedBlades,0,EmbeddedBlades.Length);Array.Clear(EmbeddedCaladbolgs,0,EmbeddedCaladbolgs.Length);
            HP=hp>0?Math.Min(hp,Def.HP):Def.HP;Gauge=Math.Min(Gauge,50);Dead=false;Jumps=CCChain=Combo=Card=0;Deity=-1;
            HitstopEndTick=HitstopStartTick=0;HitstopPoseTime=0;
            Guarding=false;Array.Clear(BufferedUntil,0,BufferedUntil.Length);
            AttackAt=QAt=EAt=UltAt=HitstunUntil=StunUntil=RootUntil=SilenceUntil=SkillLockUntil=SlowUntil=CCResetAt=0;
            InvulnUntil=now+.9f;ArmorUntil=BuffUntil=Buff2Until=FormUntil=ReflectUntil=ParryUntil=ShieldUntil=GuardUntil=0;
            DodgeUntil=StealthUntil=CritUntil=MarkUntil=DoomAt=CastUntil=RecoilUntil=AirUntil=CounterBonusUntil=0;
            HitFlashUntil=AttackVisualUntil=ComboUntil=0;LastHitAt=-100;LastGrounded=-10;SlowFactor=1;
            Overclock=NextCrit=Grounded=false;HasSpear=true;LastAction="READY";
        }
        public float Scale(float now) { return IsBoss?1.8f:FormUntil>now && (PowerJob==Job.Guardian || PowerJob==Job.Vertebrate)?1.65f:1; }
        public float Radius(float now) { return .45f*Scale(now); }
        public float HalfHeight(float now) { return .9f*Scale(now); }
        public float KnockbackScale { get { return Rules.Knockback(HP,MaxHP)+1.65f*KnockbackBonus; } }
    }
    public sealed class Hit
    {
        public int CastId,Slot;
        public int Owner;
        public float Damage,Knock=5,Hitstun=0,Duration,Slow=.65f;
        // Compatibility alias: contact hitstun, never the CC.Stun status.
        public float Stun {get{return Hitstun;}set{Hitstun=value;}}
        public V2 Direction;
        public CC Control;
        public bool Ultimate,Critical,Reflected,NoGauge,NoLeech;
        public bool Unavoidable,PreserveQinMark,TrueDamage,Physical,Summoned;
        public float KnockbackGain;
        public float CriticalMultiplier=1.6f;
        public string Tag="";
        public bool Projectile,BypassInvulnerability,BypassOneHitShield;
        public float CurrentPercent,MaximumPercent,FixedGauge=-1;
        public Effect SummonCredit;
        public Hit Copy() { return (Hit)MemberwiseClone(); }
    }
    public sealed class Effect
    {
        public readonly Dictionary<Effect,float> SummonNextHit=new Dictionary<Effect,float>();
        public Shape Shape;
        public int TargetId=-1;
        public readonly int[] PlayerHits=new int[4];
        public readonly float[] PlayerNextHit=new float[4];
        public int CastId;
        public int Owner,Hits,MaxHits=1,Group;
        public V2 Pos,Vel;
        public float Health=100,Travel,MaxRange=24;
        public float GuaranteedAt;
        public float Radius=.25f,Width,Height,Expires,ActiveAt,NextTick,Interval=.2f,Gravity,Home,Pull;
        public bool Pierce,Dead,Ultimate,FollowOwner;
        public Hit Hit;
        public float AccumulatedDamage,BoostUntil,Power=1;
        public int Style;public V2 Origin;
        public string Tag="";
    }
    public sealed class Cue
    {
        public V2 Pos,End;
        public float Start,Expires,Size;
        public int Owner;
        public string Text,Kind;
    }
    internal sealed class Scheduled
    {
        public int CastId;
        public float At;
        public int Owner;
        public bool Interruptible;
        public int Version;
        public Action Run;
    }
}
