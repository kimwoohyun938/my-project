using System;
namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public Effect FindSummon(Fighter f,string tag)
        {foreach(var e in Effects)if(!e.Dead&&e.Expires>Time&&e.Owner==f.Id&&e.Shape==Shape.Summon&&e.Tag==tag)return e;return null;}
        public int CountSummons(Fighter f,string tag)
        {int n=0;foreach(var e in Effects)if(!e.Dead&&e.Expires>Time&&e.Owner==f.Id&&e.Tag==tag)n++;return n;}
        Effect Summon(Fighter f,string tag,V2 pos,float duration,float health)
        {
            var e=new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Summon,Tag=tag,Pos=pos,Origin=f.Pos,Expires=Time+duration,
                Health=health,Radius=.5f,NextTick=Time+.3f,Power=f.CopyScale};Effects.Add(e);return e;
        }
        void SwapSummon(Fighter f,Effect e)
        {
            if(e==null||e.Dead||f.RootUntil>Time)return;
            V2 old=f.Pos;if(Teleport(f,e.Pos,100)){e.Pos=old;Cue(e.Pos,"","smoke",f.Id,1,.3f);}
        }
        void MirrorStep(Fighter f)
        {
            foreach(var e in Effects)if(e.Owner==f.Id&&e.Tag=="mirror")e.Dead=true;
            V2 old=f.Pos;Summon(f,"mirror",old,3,100);Teleport(f,old-new V2(f.Facing*3,0),4);
        }
        void MirrorDance(Fighter f)
        {
            var e=FindSummon(f,"mirror");if(e==null)e=Summon(f,"mirror",f.Pos-new V2(f.Facing*3,0),6,100);
            e.Expires=Time+6;f.MirrorUltUntil=Time+6;f.NextMirrorSwap=Time;
        }
        void BreakLocks(Fighter f)
        {
            f.MarkUntil=f.DinoMarkUntil=f.DoomAt=0;f.QinMarkOwner=f.DinoMarkOwner=-1;
            Array.Clear(f.ShadowMarks,0,f.ShadowMarks.Length);Array.Clear(f.ShadowCycles,0,f.ShadowCycles.Length);
            foreach(var e in Effects)if(e.Owner!=f.Id&&e.Home>0){e.Home=0;e.Style=-1;}
            Cue(f.Pos,"LOCK BROKEN","smoke",f.Id,1.6f,.5f);
        }
        void TwinStrike(Fighter f,bool echo=false)
        {
            var twin=FindSummon(f,"twin");if(twin==null)return;
            V2 origin=echo?f.Pos:twin.Pos;
            var h=MakeHit(f,20,2);h.Tag="twin-clone-basic";h.Summoned=!echo;h.Stun=0;
            if(V2.Distance(origin,Enemy(f).Pos)<=2.1f)ApplyHit(Enemy(f),h);
            Cue(origin,"","slash",f.Id,1.3f,.15f,origin+new V2(f.Facing*1.5f,.2f));
        }
        void TwinField(Fighter f,V2 p)
        {var h=MakeHit(f,20,1);h.Stun=0;h.Tag="twin-field";var e=Zone(f,p,1.5f,h,2,0,4,.5f);e.Tag="twin-field";}
        void TwinExchange(Fighter f)
        {
            var e=FindSummon(f,"twin");if(e==null)return;
            V2 a=f.Pos,b=e.Pos;SwapSummon(f,e);TwinField(f,a);TwinField(f,b);
            if(f.TwinUltUntil>Time){TwinField(f,a);TwinField(f,b);}
        }
        void SpawnLegion(Fighter f,int count,float duration)
        {
            int existing=CountSummons(f,"phantom");
            for(int i=0;i<count;i++){var e=Summon(f,"phantom",f.Pos+new V2((i%3-1)*.9f,1+(i/3)*.6f),duration,40);e.Style=existing+i;}
        }
        void LegionRise(Fighter f)
        {
            SpawnLegion(f,5,8);
            foreach(var e in Effects)if(!e.Dead&&e.Owner==f.Id&&e.Tag=="phantom"){e.BoostUntil=Time+8;e.Expires=Math.Max(e.Expires,Time+8);}
        }
        void LegionRush(Fighter f)
        {
            foreach(var e in Effects)if(!e.Dead&&e.Owner==f.Id&&e.Tag=="phantom")
            {e.Tag="phantom-rush";e.Expires=Time+2;e.NextTick=Time;e.Origin=e.Pos;}
        }
        void SpawnPuppet(Fighter f)
        {
            foreach(var e in Effects)if(e.Owner==f.Id&&e.Tag=="puppet")e.Dead=true;
            Summon(f,"puppet",f.Pos+new V2(f.Facing*1.5f,0),10,150);
        }
        void PuppetFinale(Fighter f)
        {
            var e=FindSummon(f,"puppet");if(e==null)return;
            var h=MakeHit(f,e.AccumulatedDamage*1.5f/Rules.UltimateDamageScale,10,true);
            h.Summoned=true;h.Critical=false;V2 p=e.Pos;e.Dead=true;
            Zone(f,p,4,h,.2f).Tag="puppet-blast";Cue(p,"PUPPET FINALE","burst",f.Id,4,.6f);SpawnPuppet(f);
        }
        void SetPuppetInput(Fighter f,Controls c)
        {
            f.PuppetCommand=c.Command&&CanAct(f)&&FindSummon(f,"puppet")!=null;
            f.PuppetMove=c.Move;f.PuppetLift=c.Jump?1:0;
        }
        void UpdateSummoner(Fighter f)
        {
            if(HasPower(f,Job.TwinFang)&&FindSummon(f,"twin")==null)Summon(f,"twin",f.Pos+new V2(f.Facing*.8f,0),f.NativeJob==Job.Mimic?Math.Max(.01f,f.CopiedPowers[(int)Job.TwinFang]-Time):100000,100);
            if((f.MirrorFadeUntil>Time||f.MirrorUltUntil>Time)&&Time>=f.NextMirrorSwap)
            {f.NextMirrorSwap=Time+(f.MirrorFadeUntil>Time?.1f:.5f);SwapSummon(f,FindSummon(f,"mirror"));}
        }
        bool SummonerEffect(Effect e,Fighter owner,Fighter target)
        {
            if(e.Shape!=Shape.Summon)return false;
            if(DuelUntil>Time&&(owner.Id==DuelOwner||owner.Id==DuelTarget))return true;
            if(e.Tag=="mirror"||e.Tag=="prism-lens")return true;
            if(e.Tag=="twin")
            {e.Pos=V2.Lerp(e.Pos,owner.Pos+new V2(owner.Facing*.8f,0),Math.Min(1,8*Rules.Dt));return true;}
            if(e.Tag=="phantom-rush")
            {
                V2 old=e.Pos;e.Pos+=(target.Pos-e.Pos).Normal*(24*Rules.Dt);
                if(SegmentBox(old,e.Pos,target.Pos,.95f,1.4f))
                {var h=MakeHit(owner,25*e.Power,3);h.Summoned=true;h.Stun=0;h.NoGauge=true;Zone(owner,e.Pos,1.2f,h);Cue(e.Pos,"","burst",e.Owner,1.2f,.3f);e.Dead=true;}
                return true;
            }
            if(e.Tag=="puppet")
            {
                if(owner.PuppetCommand)e.Pos+=new V2(owner.PuppetMove,owner.PuppetLift)*(8*Rules.Dt);
                else e.Pos=V2.Lerp(e.Pos,owner.Pos+new V2(owner.Facing*2,1),Math.Min(1,3*Rules.Dt));
                V2 delta=e.Pos-owner.Pos;if(delta.Length>8)e.Pos=owner.Pos+delta.Normal*8;
            }
            else if(e.Tag=="phantom")e.Pos=V2.Lerp(e.Pos,owner.Pos+new V2((e.Style%5-2)*.8f,1.5f+(e.Style/5)*.6f),Rules.Dt*2);
            if(e.Tag!="puppet"&&e.Tag!="phantom")return true;
            if(Time>=e.NextTick&&V2.Distance(e.Pos,target.Pos)<14)
            {
                e.NextTick+=e.Tag=="puppet"?.6f:.65f;
                float damage=e.Tag=="puppet"?37*.5f:30*.4f*(e.BoostUntil>Time?2:1);
                var shot=Shoot(owner,damage*e.Power,18,.2f,0,false,"summon-shot",direction:(target.Pos-e.Pos).Normal);
                shot.Pos=e.Pos;shot.Hit.Summoned=true;shot.Hit.NoGauge=true;shot.Hit.Stun=0;shot.Hit.SummonCredit=e;shot.Hit.Knock=1;
            }
            return true;
        }
        void HurtSummon(Effect e,Hit h)
        {
            if(e.Dead)return;e.Health-=h.Damage*(h.Critical?h.CriticalMultiplier:1);
            if(e.Health>0)return;e.Dead=true;
            if(e.Tag=="mirror")
            {var owner=Players[e.Owner];var hit=MakeHit(owner,40*e.Power,3);hit.Summoned=true;Zone(owner,e.Pos,1.8f,hit);Cue(e.Pos,"MIRROR BREAK","burst",e.Owner,1.8f,.4f);}
        }
    }
}
