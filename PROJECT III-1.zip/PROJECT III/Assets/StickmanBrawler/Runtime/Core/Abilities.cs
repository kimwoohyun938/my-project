using System;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        bool InRange(Fighter f,float range) { return V2.Distance(f.Pos,Enemy(f).Pos)<=range; }
        bool CanSkill(Fighter f,int slot)
        {
            bool valid=true;
            if(f.Job==Job.Mimic&&slot==2&&!IsShip(f))return f.Overclock||CanCopy(f,false);
            if(f.Job==Job.MirrorAssassin)valid=slot==1||FindSummon(f,"mirror")!=null;
            if(f.Job==Job.TwinFang)valid=FindSummon(f,"twin")!=null;
            if(f.Job==Job.PhantomLegion&&slot==2)valid=CountSummons(f,"phantom")>0;
            if(f.Job==Job.Puppeteer&&slot==2)valid=FindSummon(f,"puppet")!=null;
            if(slot==2&&(f.Job==Job.MirrorAssassin||f.Job==Job.TwinFang||f.Job==Job.Puppeteer)&&f.RootUntil>Time)valid=false;
            if(f.Job==Job.VoidWalker&&slot==1)valid=f.RootUntil<=Time;
            if(f.Job==Job.Institutor)valid=f.YangSwords>0;
            if(f.Job==Job.Luminary&&slot==1)valid=f.LuminaryShards<LuminaryConfig.MaxShards;
            if(f.Job==Job.Gambler)valid=slot==1?InRange(f,6):f.HP>60;
            if(f.Job==Job.QinShi)valid=Enemy(f).QinMarkOwner==f.Id&&(slot!=1||f.RootUntil<=Time);
            if(f.Job==Job.Nisemono&&slot==2)valid=Enemy(f).EmbeddedBlades[f.Id]+Enemy(f).EmbeddedCaladbolgs[f.Id]>0;
            if(slot==1)
            {
                if(f.Job==Job.Magician)valid=InRange(f,8)&&f.RootUntil<=Time;
                if(f.Job==Job.Director)valid=Enemy(f).MarkUntil>Time&&InRange(f,9)&&f.RootUntil<=Time;
                if(f.Job==Job.King)valid=f.HP>0;
                if(f.Job==Job.Dystopia)valid=InRange(f,6);
            }
            else
            {
                if(f.Job==Job.BladeMaster||f.Job==Job.Dystopia)valid=InRange(f,7)&&f.RootUntil<=Time;
                if(f.Job==Job.Depth)valid=Enemy(f).MarkUntil>Time&&InRange(f,9)&&f.RootUntil<=Time;
                if(f.Job==Job.Magician)valid=InRange(f,6);
                if(f.Job==Job.Master)valid=InRange(f,6)&&ClearPath(f.Pos,Enemy(f).Pos);
            }
            if(!valid)Cue(f.Pos,"OUT OF RANGE / CONDITION","text",f.Id,1,.6f);
            return valid;
        }
        bool CanUltimate(Fighter f)
        {
            bool valid=true;
            if(f.Job==Job.Cybercrud)valid=Enemy(f).CyberMarks[f.Id]>0;
            if(f.Job==Job.Mimic)return CanCopy(f,true);
            if(f.Job==Job.Undying)valid=f.UndyingUntil<=Time;
            if(f.Job==Job.Puppeteer)valid=FindSummon(f,"puppet")!=null;
            if(f.Job==Job.Nisemono)valid=f.RealmUntil<=Time;
            if(f.Job==Job.YiSunGod)valid=!IsShip(f);
            if(f.Job==Job.FrostReaper)valid=InRange(f,6);
            if(f.Job==Job.ShadowClone)valid=Enemy(f).ShadowMarks[f.Id]>=3&&f.RootUntil<=Time;
            if(f.Job==Job.VoidWalker)valid=DuelUntil<=Time;
            if(f.Job==Job.BloodApostle)valid=f.BloodUltUntil<=Time;
            if(f.Job==Job.Gambler)valid=Fortune(f)==0;
            if(f.Job==Job.DinoMan)valid=Enemy(f).DinoMarkOwner==f.Id&&Enemy(f).DinoMarkUntil>Time;
            if(f.Job==Job.Master)valid=f.HP<=f.Def.HP*.4f||Mode==BattleMode.DpsEvent;
            if(f.Job==Job.Depth)valid=Enemy(f).MarkUntil>Time&&InRange(f,9)&&f.RootUntil<=Time;
            if(f.Job==Job.Dystopia)valid=InRange(f,6);
            if(f.Job==Job.Werewolf)valid=f.RootUntil<=Time;
            if(!valid)Cue(f.Pos,"OUT OF RANGE / CONDITION","text",f.Id);
            return valid;
        }
        void Announce(Fighter f,string name,bool ult=false)
        { f.LastAction=name;Cue(f.Pos,"","cast-vfx",f.Id,ult?2:1,ult?.7f:.35f);Cue(f.Pos+new V2(0,1.6f),name,"text",f.Id,ult?1.2f:1,ult?1.1f:.55f); }
        void Dash(Fighter f,float speed,float up=0,float time=.25f)
        { if(f.RootUntil>Time)return;f.Vel=new V2(f.Facing*speed,up);f.RecoilUntil=Time+time; }
        void Basic(Fighter f)
        { RunAction(f,0,()=>BasicBody(f)); }
        void BasicBody(Fighter f)
        {
            if(f.NativeJob==Job.Mimic&&f.Job==Job.Mimic&&IsShip(f)){WithKit(f,Job.YiSunGod,1,()=>Basic(f));return;}
            if(f.NativeJob==Job.Mimic&&f.Job==Job.Mimic&&f.Deity==3&&f.FormUntil>Time){WithKit(f,Job.Cross,1,()=>Basic(f));return;}
            Fighter enemy=Enemy(f);float d=f.Def.Damage;f.LastAction="BASIC";f.AttackVisualUntil=Time+.18f;
            switch(f.Job)
            {
                case Job.LTiming:Melee(f,40,2.3f,5,false,CC.None,0,"timing-basic");break;
                case Job.Cybercrud:CyberBasic(f);break;
                case Job.Alchemist:{var e=Shoot(f,d,19,.24f,0,false,"alchemist-basic",direction:(enemy.Pos-f.Pos).Normal);e.Hit.Physical=false;break;}
                case Job.Ronin:if(f.RoninDrawReady){f.RoninDrawReady=false;Dash(f,18,0,.18f);Melee(f,d*1.5f,2.6f,8,false,CC.None,0,"ronin-draw");}else Melee(f,d,2.1f,5,false,CC.None,0,"ronin-basic");break;
                case Job.Maestro:{AdvanceMaestroBeat(f,0);var e=Shoot(f,d,21,.24f,0,false,"maestro-basic",direction:(enemy.Pos-f.Pos).Normal);e.Hit.Physical=false;break;}
                case Job.Pendulum:Melee(f,d,2.1f,6+Rules.Clamp(f.Vel.Length*.35f,0,6),false,CC.None,0,"pendulum-basic");break;
                case Job.Tether:Melee(f,d,2.6f,5,false,CC.None,0,"tether-basic");break;
                case Job.Prism:
                {
                    var e=Shoot(f,d,21,.22f,0,false,"prism-basic",direction:(enemy.Pos-f.Pos).Normal);e.Hit.Physical=false;
                    var lens=FindSummon(f,"prism-lens");
                    if(lens!=null){var sub=Shoot(f,18,23,.18f,0,false,"prism-refract",direction:(enemy.Pos-lens.Pos).Normal);sub.Pos=lens.Pos;sub.Hit.Physical=false;sub.Hit.NoGauge=true;Cue(lens.Pos,"","ring",f.Id,.8f,.25f);}
                    break;
                }
                case Job.Reactor:AddReactorHeat(f,14);Melee(f,d,2f,6,false,CC.None,0,"reactor-basic");break;
                case Job.Poltergeist:{var e=Shoot(f,d,19,.24f,0,false,"poltergeist-basic",direction:(enemy.Pos-f.Pos).Normal);e.Hit.Physical=false;break;}
                case Job.Rider:Melee(f,d,2.4f,5,false,CC.None,0,"rider-basic");break;
                case Job.Luminary:ExecuteLuminaryBasic(f);break;
                case Job.Assassin:Melee(f,d,2.1f);break;
                case Job.TimeMurder:if(f.Overclock)RapidStrike(f);else Melee(f,35,1.8f,5,false,CC.None,0,"time-basic");break;
                case Job.Undying:Melee(f,14,1.9f,5,false,CC.None,0,"undying-basic");break;
                case Job.MirrorAssassin:Melee(f,40,1.9f,5,false,CC.None,0,"mirror-basic");break;
                case Job.TwinFang:Melee(f,36,1.9f,5,false,CC.None,0,"twin-basic");TwinStrike(f);break;
                case Job.PhantomLegion:Shoot(f,30,20,.23f,0,false,"phantom-basic");break;
                case Job.Mimic:Melee(f,34*(f.BloodBoostUntil>Time?1.45f:1),1.9f,5,false,CC.None,0,"mimic-basic");break;
                case Job.Puppeteer:Shoot(f,37,20,.23f,0,false,"puppet-basic");break;
                case Job.Samurai:
                    Melee(f,d/2,1.9f,3);Later(f,.1f,()=>Melee(f,d/2,2,5),true);break;
                case Job.YiSunGod:
                    if(IsShip(f)){var e=Shoot(f,80,20,.4f,0,false,"yi-basic");e.Hit.Knock=9;}
                    else Melee(f,60,1.9f,6,false,CC.None,0,"yi-basic");break;
                case Job.Institutor:Melee(f,30,2.3f,5,false,CC.None,0,"institutor-basic");break;
                case Job.Lancer:Melee(f,d*(f.HasSpear?1:.85f),f.HasSpear?3.2f:2.1f,7,false,CC.None,0,"lancer-basic");break;
                case Job.Archer:{var e=Shoot(f,d,25,.24f,1.6f,false,"archer-basic");e.MaxRange=28;break;}
                case Job.GravityMage:{var e=Shoot(f,d,13,.35f,1.4f,false,"gravity-orb");e.MaxRange=11;break;}
                case Job.Thunder:
                {
                    bool DragonScale=f.BuffUntil>Time;
                    CC cc=f.Buff2Until>Time?CC.Stun:CC.Slow;
                    float dur=f.Buff2Until>Time?.35f:.8f;
                    var orb=Shoot(f,d,26f,.34f,6.5f,false,"thunder-orb",cc,dur,direction:(enemy.Pos-f.Pos).Normal);
                    orb.Hit.Physical=false;orb.Hit.Slow=.75f;orb.MaxRange=26f;
                    if(DragonScale)
                    {
                        V2 p=enemy.Pos;var hit=MakeHit(f,24f,4,false,cc,dur);hit.Physical=false;hit.Slow=.75f;
                        Zone(f,p,2f,hit,.16f);Cue(p+new V2(0,6),"","bolt",f.Id,1.2f,.18f,p);
                    }
                    break;
                }
                case Job.Magician:{var e=Shoot(f,d,21,.25f);e.Pierce=true;e.MaxRange=26;break;}
                case Job.CardMan:
                { var e=Shoot(f,f.Card==1?62:d,f.Card==0?23:17,.24f,0,false,"card",f.Card==2?CC.Slow:CC.None,1.2f);e.Hit.Slow=.55f;if(f.Card==1)e.Hit.Knock=9;e.MaxRange=f.Card==0?17:11;break; }
                case Job.King:
                    KingGateShot(f,0);
                    Later(f,Rules.KingShotGap,()=>KingGateShot(f,1));break;
                case Job.QinShi:Melee(f,d,1.8f,6,false,CC.None,0,"qin-basic");break;
                case Job.Gambler:Melee(f,65,1.8f,6,false,CC.None,0,"gambler-basic");break;
                case Job.DinoMan:Melee(f,50,1.8f,6,false,CC.None,0,"dino-basic");break;
                case Job.FrostReaper:Shoot(f,45,20,.25f,0,false,"frost-basic",direction:(enemy.Pos-f.Pos).Normal);break;
                case Job.BloodApostle:Melee(f,42*(f.BloodBoostUntil>Time?1.45f:1),1.9f,5,false,CC.None,0,"blood-basic");break;
                case Job.ShadowClone:Melee(f,38,1.9f,5,false,CC.None,0,"shadow-basic");break;
                case Job.IronWall:Melee(f,25,1.8f,5,false,CC.None,0,"iron-basic");break;
                case Job.VoidWalker:Shoot(f,33,19,.25f,0,false,"void-basic",direction:(enemy.Pos-f.Pos).Normal);break;
                case Job.Nisemono:
                    bool close=InRange(f,2.5f);NisemonoBlade(f,close);
                    Later(f,.08f,()=>NisemonoBlade(f,close),true);break;
                case Job.Vertebrate:
                    if(f.Combo>=2 && f.ComboUntil>Time){Melee(f,120,2.1f,10);f.Combo=0;}else Melee(f,d,1.8f,5,false,CC.None,0,"combo");break;
                case Job.Director:
                    if(InRange(f,f.FormUntil>Time?5:2.5f))Melee(f,d,1.8f,4);
                    else Shoot(f,d,19,.22f,0,false,"mark");break;
                case Job.Depth:Melee(f,d,2.3f,7,false,CC.None,0,"depth-basic");break;
                case Job.Cross:
                    if(f.Deity==3 && f.FormUntil>Time){Shoot(f,d,26,.25f,0,false,"holy-sword");f.AttackAt=Time+.35f;}
                    else Melee(f,d);break;
                case Job.Engineer:
                {
                    Shoot(f,d,22,.24f,0,false,"engineer-basic");
                    foreach(var t in Effects)if(!t.Dead&&t.Owner==f.Id&&t.Shape==Shape.Turret)
                    {var sub=Shoot(f,18,26,.18f,0,false,"sentry",direction:(enemy.Pos-t.Pos).Normal);sub.Pos=t.Pos;sub.Hit.Summoned=true;sub.Hit.NoGauge=true;Cue(t.Pos,"","ring",f.Id,.7f,.2f);}
                    break;
                }
                case Job.Zephyr:Melee(f,d,2.1f,6);break;
                default:Melee(f,d);break;
            }
        }
        void Skill1(Fighter f)
        { RunAction(f,1,()=>Skill1Body(f)); }
        void Skill1Body(Fighter f)
        {
            Fighter enemy=Enemy(f);RecordSkill(f,1);Announce(f,Roster.Get(f.Job).QName);
            switch(f.Job)
            {
                case Job.LTiming:TimingReturn(f);break;
                case Job.Cybercrud:CyberZone(f);break;
                case Job.Alchemist:{var e=Shoot(f,20,15,.28f,0,false,"acid-flask",direction:new V2(f.Facing,.58f));e.Gravity=16;e.Expires=Time+1.4f;e.Hit.Physical=false;break;}
                case Job.Ronin:{f.ShieldUntil=Time+.45f;f.RoninDrawReady=true;Dash(f,16,2,.25f);var h=MakeHit(f,65,8);h.Direction=new V2(f.Facing,.55f);Zone(f,f.Pos,1.5f,h,.28f).FollowOwner=true;break;}
                case Job.Maestro:
                {
                    bool odd=f.MaestroTempo%2==1;AdvanceMaestroBeat(f,1);
                    if(odd){Teleport(f,enemy.Pos-new V2(enemy.Facing*1.2f,0),8);f.Facing=enemy.Pos.x>=f.Pos.x?1:-1;Melee(f,70,2.2f,7,false,CC.Stun,.4f);}
                    else{Dash(f,-14,8,.25f);var h=MakeHit(f,75,9);h.Physical=false;Zone(f,f.Pos+new V2(f.Facing*1.6f,0),2f,h,.22f);}
                    break;
                }
                case Job.Pendulum:{f.PendulumSwingUntil=Time+3;Dash(f,24,11,.32f);var h=MakeHit(f,65,9);Zone(f,f.Pos,1.6f,h,.32f).FollowOwner=true;break;}
                case Job.Tether:{var e=Shoot(f,60,23,.28f,0,false,"tether-hook",direction:(enemy.Pos-f.Pos).Normal);e.MaxRange=14;break;}
                case Job.Prism:
                {
                    foreach(var old in Effects)if(old.Owner==f.Id&&old.Tag=="prism-lens")old.Dead=true;
                    V2 lensPos=f.Pos+new V2(f.Facing*2.8f,1.8f);
                    Summon(f,"prism-lens",lensPos,8,120);
                    var h=MakeHit(f,55,6);h.Physical=false;Zone(f,lensPos,1.8f,h,.2f);Cue(lensPos,"PRISM CORE","ring",f.Id,1.8f,.4f);break;
                }
                case Job.Reactor:{AddReactorHeat(f,25);Dash(f,20,2,.26f);var h=MakeHit(f,70,10);Zone(f,f.Pos,1.5f,h,.26f).FollowOwner=true;break;}
                case Job.Poltergeist:
                {
                    f.PoltergeistDebris=Math.Min(3,f.PoltergeistDebris+2);
                    var h=MakeHit(f,55,13,false,CC.Slow,2);h.Slow=.7f;h.Direction=new V2(f.Facing*.15f,1);h.Physical=false;
                    Zone(f,enemy.Pos,2f,h,.22f);Cue(enemy.Pos,"반중력 리프트","ring",f.Id,2f,.45f);break;
                }
                case Job.Rider:
                {
                    Dash(f,26,3,.26f);f.Jumps=Math.Min(f.Jumps,1);
                    var h=MakeHit(f,75,6);h.Tag="rider-chain";
                    Zone(f,f.Pos,1.6f,h,.26f).FollowOwner=true;break;
                }
                case Job.Luminary:CastLuminaryPulse(f);break;
                case Job.Undying:f.UndyingGuardUntil=Time+3;break;
                case Job.MirrorAssassin:MirrorStep(f);break;
                case Job.TwinFang:TwinStrike(f);if(f.TwinUltUntil>Time)TwinStrike(f,true);break;
                case Job.PhantomLegion:SpawnLegion(f,2,4);break;
                case Job.Mimic:f.DisguiseUntil=Time+3;break;
                case Job.Puppeteer:SpawnPuppet(f);break;
                case Job.Knight:f.BuffUntil=Time+3;break;
                case Job.FrostReaper:Shoot(f,70,24,.3f,0,false,"frost-spear",CC.Stun,1.2f);break;
                case Job.BloodApostle:f.HP*=.85f;f.BloodBoostUntil=Time+3;Cue(f.Pos,"CRIMSON PACT","aura",f.Id,1.5f,3);break;
                case Job.ShadowClone:SpawnShadow(f);break;
                case Job.IronWall:f.IronActiveShield=150;f.IronShieldUntil=Time+6;Cue(f.Pos,"BULWARK 150","shield",f.Id,1.4f,.5f);break;
                case Job.VoidWalker:VoidStep(f);break;
                case Job.Gambler:
                    if(ApplyHit(enemy,StatusHit(f,CC.Root,1.75f)))Cue(enemy.Pos,"","doors",f.Id,1,1.75f);break;
                case Job.DinoMan:
                {var e=Shoot(f,60,18,.35f,0,false,"dino-egg",CC.Slow,2,direction:(enemy.Pos-f.Pos).Normal);e.Hit.Slow=.7f;break;}
                case Job.YiSunGod:
                    if(IsShip(f)){Beam(f,50,16,false,5);Effects[Effects.Count-1].Height=.6f;}
                    else {SummonSoldier(f);Later(f,.7f,()=>SummonSoldier(f));}break;
                case Job.Institutor:f.YangSwords--;f.YangSprintUntil=Time+5;break;
                case Job.Berserker:
                    f.ArmorUntil=Time+.5f;Dash(f,23,3,.35f);Zone(f,f.Pos,1.3f,MakeHit(f,65,9),.4f).FollowOwner=true;break;
                case Job.Samurai:
                    f.CastUntil=Time+.22f;Cue(f.Pos,"","warning-line",f.Id,8,.22f,f.Pos+new V2(f.Facing*8,0));
                    Later(f,.22f,()=>{Dash(f,32,0,.22f);Zone(f,f.Pos,1.3f,MakeHit(f,90,7),.25f).FollowOwner=true;},true);break;
                case Job.BladeMaster:f.GuardUntil=Time+.6f;break;
                case Job.Lancer:LancerCast(f);break;
                case Job.Archer:
                {
                    f.InvulnUntil=Time+.4f;f.ArcherHasteUntil=Time+3f;Dash(f,-15,12,.28f);
                    var e=Zone(f,new V2(f.Pos.x,FloorAt(f.Pos.x,f.Pos.y)+.2f),1.25f,MakeHit(f,60,3,false,CC.Root,1.3f),6,.05f);e.Shape=Shape.Trap;break;
                }
                case Job.GravityMage:f.AirUntil=Time+1.8f;f.Vel.y=3;break;
                case Job.Thunder:
                {
                    f.BuffUntil=Time+4f;f.IronActiveShield=Math.Max(f.IronActiveShield,110f);f.IronShieldUntil=Math.Max(f.IronShieldUntil,Time+4f);
                    var h=MakeHit(f,55f,8f);h.Physical=false;Zone(f,f.Pos,2.6f,h,.2f);
                    Cue(f.Pos+new V2(0,6),"","bolt",f.Id,1.4f,.25f,f.Pos);break;
                }
                case Job.Magician:BlinkVolley(f);break;
                case Job.Assassin:
                {
                    V2 from=f.Pos;Dash(f,30,0,.2f);Later(f,.3f,()=>{V2 to=f.Pos;var e=new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Beam,Pos=from,Vel=(to-from).Normal,Width=V2.Distance(from,to),Height=1,Hit=MakeHit(f,60,7),Expires=Time+.16f,NextTick=Time};Effects.Add(e);Cue(from,"","slash",f.Id,1,.3f,to);});break;
                }
                case Job.Hassan:
                { int group=++groupSerial;for(int i=-1;i<=1;i++){var e=Shoot(f,20,20,.18f,0,false,"shuriken",direction:new V2(f.Facing,i*.18f));e.Group=group;}break; }
                case Job.Dystopia:ApplyHit(enemy,StatusHit(f,CC.SkillLock,2));break;
                case Job.TimeMurder:f.InvulnUntil=Time+1.4f;f.BuffUntil=Time+1.4f;f.Vel=new V2();break;
                case Job.CardMan:f.Card=(f.Card+1)%3;break;
                case Job.Guardian:f.ReflectUntil=Time+3.8f;break;
                case Job.Reflector:f.ParryUntil=Time+.2f;break;
                case Job.Grappler:
                { f.ArmorUntil=Time+.65f;Dash(f,20,2,.5f);var h=MakeHit(f,60,1);h.Tag="grab";var e=Zone(f,f.Pos,1.4f,h,.55f);e.FollowOwner=true;e.Tag="drag";break; }
                case Job.King:f.HP=Math.Max(1,f.HP-75);f.Gauge=Math.Min(100,f.Gauge+40);break;
                case Job.QinShi:
                    if(Teleport(f,enemy.Pos-new V2(enemy.Facing*1.2f,0),100)){enemy.QinMarkOwner=-1;f.Facing=enemy.Pos.x>f.Pos.x?1:-1;}break;
                case Job.Nisemono:
                {var e=Shoot(f,80,24,.35f,0,false,"caladbolg",direction:(enemy.Pos-f.Pos).Normal);e.MaxRange=50;break;}
                case Job.Werewolf:foreach(var target in Players)if(Opponents(f.Id,target.Id)&&Alive(target)&&V2.Distance(f.Pos,target.Pos)<=4)ApplyHit(target,StatusHit(f,CC.Slow,4,false,.6f));Cue(f.Pos,"","ring",f.Id,4,.4f);break;
                case Job.Vertebrate:Shoot(f,35,25,.2f,0,false,"hook",direction:(enemy.Pos-f.Pos).Normal);break;
                case Job.Director:Teleport(f,enemy.Pos-new V2(enemy.Facing*1.2f,0),9);f.Facing=enemy.Pos.x>f.Pos.x?1:-1;break;
                case Job.Depth:{var e=Shoot(f,120,17,.55f,0,false,"depth-mark");e.Pierce=true;break;}
                case Job.Cross:Zone(f,f.Pos,2,MakeHit(f,75,7));Heal(f,150);Cue(f.Pos+new V2(0,7),"","bolt",f.Id,1,.4f,f.Pos);break;
                case Job.Master:f.ShieldUntil=Time+.35f;break;
                case Job.Engineer:
                    foreach(var e in Effects)if(e.Owner==f.Id&&e.Shape==Shape.Turret)e.Dead=true;
                    f.IronActiveShield=Math.Max(f.IronActiveShield,120);f.IronShieldUntil=Math.Max(f.IronShieldUntil,Time+4);
                    Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Turret,Pos=new V2(f.Pos.x,FloorAt(f.Pos.x,f.Pos.y)+.5f),Radius=.65f,Health=280,Expires=Time+8,NextTick=Time+.3f});
                    Cue(f.Pos,"SIEGE TURRET + SHIELD","shield",f.Id,1.4f,.45f);break;
                case Job.Zephyr:
                    Dash(f,26,5,.3f);f.Jumps=Math.Min(f.Jumps,1);Zone(f,f.Pos,1.2f,MakeHit(f,70,7),.3f).FollowOwner=true;break;
            }
        }
        void Skill2(Fighter f)
        { RunAction(f,2,()=>Skill2Body(f)); }
        void Skill2Body(Fighter f)
        {
            Fighter enemy=Enemy(f);RecordSkill(f,2);Announce(f,Roster.Get(f.Job).EName);
            switch(f.Job)
            {
                case Job.LTiming:TimingIntercept(f);break;
                case Job.Cybercrud:CyberThrottle(f);break;
                case Job.Alchemist:{f.IronActiveShield=120;f.IronShieldUntil=Time+4;f.AlchemistHasteUntil=Time+3;var h=MakeHit(f,55,6,false,CC.Root,.8f);h.Physical=false;Zone(f,f.Pos,2.4f,h,.22f);Cue(f.Pos,"등가교환","shield",f.Id,2.4f,.5f);break;}
                case Job.Ronin:{f.RoninWindUntil=Time+2.5f;var e=Shoot(f,75,24,.32f,0,false,"ronin-gale",CC.Slow,1.5f);e.Pierce=true;e.MaxRange=20;e.Hit.Slow=.7f;e.Hit.Knock=9;break;}
                case Job.Maestro:
                {
                    AdvanceMaestroBeat(f,2);
                    V2 focus=f.Pos+new V2(f.Facing*4.2f,0);
                    bool sweet=V2.Distance(enemy.Pos,focus)<=1.15f;
                    var h=MakeHit(f,sweet?110:55,sweet?10:5,false,sweet?CC.Stun:CC.None,sweet?.7f:0);h.Physical=false;
                    Zone(f,focus,sweet?1.3f:2.2f,h,.22f);
                    if(sweet){Heal(f,60);f.MaestroTempo=Math.Min(4,f.MaestroTempo+2);f.MaestroTempoUntil=Time+3.5f;Cue(focus,"카덴차 정점!","burst",f.Id,2f,.5f);}
                    else Cue(focus,"","ring",f.Id,2f,.35f);
                    break;
                }
                case Job.Pendulum:
                {
                    float bonus=Rules.Clamp(f.Vel.Length*3.5f,0,65);
                    var h=MakeHit(f,60+bonus,11,false,CC.Stun,.45f);
                    Zone(f,f.Pos+new V2(f.Facing*1.5f,0),2.1f,h,.22f);Cue(f.Pos+new V2(f.Facing*1.5f,0),"","burst",f.Id,2.1f,.4f);break;
                }
                case Job.Tether:
                {
                    if(f.TetherUntil>Time&&f.TetherTarget==enemy.Id)
                    {
                        float dist=Rules.Clamp(V2.Distance(f.Pos,enemy.Pos),0,8);
                        var h=MakeHit(f,55+dist*7.5f,4,false,CC.Stun,.5f);
                        if(ApplyHit(enemy,h)&&!IsFixedDummy(enemy)&&enemy.RootUntil<=Time)
                        {V2 mid=(f.Pos+enemy.Pos)*.5f;Teleport(enemy,mid+new V2(f.Facing*.6f,0),30);}
                        Cue(enemy.Pos,"장력 수축","burst",f.Id,2f,.45f);
                    }
                    else
                    {
                        var h=MakeHit(f,70,6,false,CC.Root,.6f);Zone(f,f.Pos,2.8f,h,.22f);
                    }
                    break;
                }
                case Job.Prism:
                {
                    Beam(f,70,15,false,6);
                    var lens=FindSummon(f,"prism-lens");
                    if(lens!=null)
                    {
                        V2 dir=(enemy.Pos-lens.Pos).Normal;
                        var h=MakeHit(f,50,5,false,CC.Slow,1.5f);h.Slow=.7f;h.Physical=false;h.Direction=dir;
                        Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Beam,Pos=lens.Pos,Vel=dir,Width=16,Height=1.2f,Hit=h,Expires=Time+.16f,ActiveAt=Time,NextTick=Time});
                        Cue(lens.Pos,"분광 굴절","ring",f.Id,1.6f,.35f);
                    }
                    break;
                }
                case Job.Reactor:
                {
                    float heat=f.ReactorHeat;f.ReactorHeat=0;f.ReactorGuardUntil=Time+3;
                    Heal(f,heat*.8f);
                    var h=MakeHit(f,45+heat*.7f,9);h.Physical=false;
                    Zone(f,f.Pos,2.8f,h,.25f);Cue(f.Pos,"증기 방출","burst",f.Id,2.8f,.45f);break;
                }
                case Job.Poltergeist:
                {
                    int count=1+f.PoltergeistDebris;f.PoltergeistDebris=0;
                    for(int i=0;i<count;i++)
                    {
                        int idx=i;bool last=idx==count-1;
                        Later(f,idx*.06f,()=>{
                            var e=Shoot(f,32,23,.25f,4,false,"poltergeist-debris",last?CC.Stun:CC.None,last?.4f:0,direction:(Enemy(f).Pos-f.Pos).Normal);
                            e.Pos=f.Pos+new V2((idx-1)*.35f,1.1f);e.Hit.Physical=false;
                        });
                    }
                    break;
                }
                case Job.Rider:
                {
                    Cue(f.Pos,"MYSTIC GAZE","portal",f.Id,3f,.6f);
                    foreach(var foe in Players)
                    {
                        if(!Opponents(f.Id,foe.Id)||!Alive(foe)||V2.Distance(f.Pos,foe.Pos)>7.5f||(foe.Pos.x-f.Pos.x)*f.Facing<-.5f)continue;
                        bool petrify=V2.Distance(f.Pos,foe.Pos)<=4.5f||foe.Facing!=f.Facing;
                        var h=MakeHit(f,45,3,false,petrify?CC.Stun:CC.Slow,petrify?1.4f:2.5f);
                        h.Slow=.6f;h.Physical=false;
                        if(petrify)h.Tag="frost-spear";
                        if(ApplyHit(foe,h)&&!ImmuneControl(foe))foe.GorgonSlowUntil=Time+2.5f;
                    }
                    break;
                }
                case Job.Luminary:CastLuminaryOverwhelmDetonate(f);break;
                case Job.Undying:Heal(f,(f.MaxHP-f.HP)*.12f);f.UndyingHealGuardUntil=Time+2;break;
                case Job.MirrorAssassin:f.MirrorFadeUntil=Time+.5f;f.NextMirrorSwap=Time;BreakLocks(f);break;
                case Job.TwinFang:TwinExchange(f);break;
                case Job.PhantomLegion:LegionRush(f);break;
                case Job.Mimic:if(f.Overclock)f.Overclock=false;else CopyEnemy(f,false);break;
                case Job.Puppeteer:SwapSummon(f,FindSummon(f,"puppet"));break;
                case Job.Knight:{var e=Shoot(f,75,20,.65f);e.Hit.Knock=13;break;}
                case Job.FrostReaper:Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Zone,Pos=f.Pos,Radius=4,Expires=Time+5,Tag="cold-veil"});break;
                case Job.BloodApostle:f.BloodGuardUntil=Time+3;f.BloodStoredDamage=0;break;
                case Job.ShadowClone:f.StealthUntil=Time+.8f;f.NextCrit=true;Cue(f.Pos,"VANISH","smoke",f.Id,2,.8f);break;
                case Job.IronWall:f.IronGuardUntil=Time+3;f.StunUntil=f.RootUntil=f.SlowUntil=f.SilenceUntil=f.SkillLockUntil=0;break;
                case Job.VoidWalker:f.VoidPhaseUntil=Time+2;Cue(f.Pos,"PHASE","aura",f.Id,1.5f,2);break;
                case Job.Gambler:
                    f.HP-=60;Shoot(f,25,20,.25f,0,false,"fortune-coin",direction:(enemy.Pos-f.Pos).Normal);break;
                case Job.DinoMan:Melee(f,80,3.2f,8,false,CC.None,0,"dino-mark");break;
                case Job.YiSunGod:
                    if(IsShip(f))ApplyHit(enemy,StatusHit(f,CC.Slow,3,false,.8f));
                    else
                    {
                        V2 target=enemy.Pos;var h=MakeHit(f,60,5);h.Tag="yi-fire";
                        Zone(f,target,2,h,.15f,.8f);Cue(target,"","warning",f.Id,2,.8f);
                        Cue(f.Pos,"","fire-arc",f.Id,1,.8f,target);
                    }
                    break;
                case Job.Institutor:LaunchYangSwords(f);break;
                case Job.QinShi:
                    for(int i=-1;i<=1;i++)
                    {var e=Shoot(f,20,16,.23f,7,false,"qin-seeker",direction:new V2(f.Facing,i*.35f));e.Hit.PreserveQinMark=true;e.Expires=Time+5;e.MaxRange=90;}
                    break;
                case Job.Nisemono:
                {
                    int blades=enemy.EmbeddedBlades[f.Id],bows=enemy.EmbeddedCaladbolgs[f.Id];
                    enemy.EmbeddedBlades[f.Id]=enemy.EmbeddedCaladbolgs[f.Id]=0;
                    ApplyHit(enemy,MakeHit(f,blades*10+bows*50,8));Cue(enemy.Pos,"BLADE DETONATION","burst",f.Id,2,.5f);break;
                }
                case Job.Berserker:Zone(f,f.Pos,2.6f,MakeHit(f,30,4,false,CC.Stun,.4f));break;
                case Job.Samurai:
                    Dash(f,10,16,.25f);Zone(f,f.Pos,1.4f,MakeHit(f,50,8),.3f).FollowOwner=true;
                    Later(f,.42f,()=>{Dash(f,3,-22,.4f);Zone(f,f.Pos,1.5f,MakeHit(f,65,8),.4f).FollowOwner=true;},true);break;
                case Job.BladeMaster:
                    Teleport(f,enemy.Pos-new V2(enemy.Facing*1.2f,0),7);f.Facing=enemy.Pos.x>f.Pos.x?1:-1;Melee(f,60,2,9);break;
                case Job.Lancer:
                {
                    f.ArmorUntil=Math.Max(f.ArmorUntil,Time+1f);f.GuardUntil=Math.Max(f.GuardUntil,Time+1f);
                    Dash(f,26,13,.26f);
                    var thrust=MakeHit(f,70,8);thrust.Direction=new V2(f.Facing,.85f);thrust.Tag="lancer-rune";
                    Zone(f,f.Pos,1.9f,thrust,.26f).FollowOwner=true;
                    Later(f,.28f,()=>{Dash(f,8,-26,.32f);var slam=MakeHit(f,110,11,false,CC.Stun,.55f);slam.Tag="lancer-rune";Zone(f,f.Pos,2.2f,slam,.38f).FollowOwner=true;Cue(f.Pos,"ATH NGABLA","burst",f.Id,2.2f,.4f);},true);
                    break;
                }
                case Job.Archer:{var e=Shoot(f,105,18,.34f,0,false,"grenade",CC.Stun,.4f,direction:new V2(f.Facing,.52f));e.Gravity=17;e.Expires=Time+1.4f;break;}
                case Job.GravityMage:Shoot(f,40,17,.3f,0,false,"bind",CC.Stun,.5f);break;
                case Job.Thunder:
                {
                    f.Buff2Until=Time+5f;
                    V2 p=enemy.Pos;var h=MakeHit(f,75f,7f,false,CC.Stun,.45f);h.Physical=false;
                    Zone(f,p,2.3f,h,.2f);Cue(p+new V2(0,7),"","bolt",f.Id,1.5f,.25f,p);break;
                }
                case Job.Magician:{var h=MakeHit(f,MagicianRiftDamage(f,enemy),4);h.Critical=false;ApplyHit(enemy,h);}Cue(enemy.Pos,"HEALTH RIFT","burst",f.Id,2,.4f);break;
                case Job.Assassin:AssassinVeil(f);break;
                case Job.Hassan:f.DodgeUntil=Time+2;f.Buff2Until=Time+2;break;
                case Job.Dystopia:Teleport(f,enemy.Pos+new V2(enemy.Facing*1.3f,0),7);f.Facing=enemy.Pos.x>f.Pos.x?1:-1;f.CritUntil=Time+1;break;
                case Job.TimeMurder:f.Overclock=!f.Overclock;f.RapidScale=f.CopyScale;break;
                case Job.CardMan:f.Buff2Until=Time+4;break;
                case Job.Guardian:
                {
                    V2 p=new V2(f.Pos.x+f.Facing*2.1f,FloorAt(f.Pos.x,f.Pos.y)+1.5f);
                    if(Math.Abs(enemy.Pos.x-p.x)<1&&Math.Abs(enemy.Pos.y-p.y)<2)p.x+=f.Facing*1.5f;
                    Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Wall,Pos=p,Width=.7f,Height=3,Expires=Time+4});break;
                }
                case Job.Reflector:TrackedStone(f);break;
                case Job.Grappler:Zone(f,f.Pos-new V2(0,.5f),2.6f,MakeHit(f,70,11));break;
                case Job.King:Shoot(f,40,21,.25f,0,false,"chain",CC.Root,.6f);break;
                case Job.Werewolf:Shoot(f,40,13,.3f,2.2f,false,"bind",CC.Root,1.2f);break;
                case Job.Vertebrate:Heal(f,150);Cue(f.Pos,"RECOVER","ring",f.Id,1.2f);break;
                case Job.Director:Melee(f,95,(f.FormUntil>Time?1.4f:1)*2.4f,10);break;
                case Job.Depth:Teleport(f,enemy.Pos-new V2(enemy.Facing*1.2f,0),9);f.Facing=enemy.Pos.x>f.Pos.x?1:-1;break;
                case Job.Cross:f.Buff2Until=Time+3;break;
                case Job.Master:
                    if(enemy.RootUntil<=Time && ApplyHit(enemy,MakeHit(f,35,2,false,CC.Root,f.HP<=f.Def.HP*.2f?1.5f:1))){enemy.RootPos=f.Pos+new V2(f.Facing*1.5f,0);enemy.Pos=enemy.RootPos;}break;
                case Job.Engineer:
                {
                    Dash(f,-12,6,.22f);
                    var h=MakeHit(f,100,10,false,CC.Stun,.55f);h.Tag="emp-mine";
                    var e=Zone(f,new V2(f.Pos.x+f.Facing*1.4f,FloorAt(f.Pos.x,f.Pos.y)+.25f),2.2f,h,5,.1f);e.Shape=Shape.Trap;break;
                }
                case Job.Zephyr:
                { var e=Zone(f,f.Pos+new V2(f.Facing*2,0),1.8f,MakeHit(f,45,3),3);e.Shape=Shape.Wind;break; }
            }
        }
        float FloorAt(float x,float y)
        {
            float best=Arena.Bottom+1;
            foreach(var p in Arena.Platforms)if(Math.Abs(x-p.X)<=p.Width/2 && p.Y<=y+.1f)best=Math.Max(best,p.Y);
            return best;
        }
    }
}
