using System;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public bool IsShip(Fighter f) { return HasPower(f,Job.YiSunGod)&&f.FormUntil>Time&&!f.Dead&&f.HP>0; }
        void SummonSoldier(Fighter f)
        {
            var e=Shoot(f,40,16,.3f,0,false,"yi-soldier");
            e.Hit.Unavoidable=true;e.Hit.Summoned=true;e.Hit.Knock=3;e.GuaranteedAt=Time+1.2f;
        }
        public V2 YangPosition(Fighter f,int index,int count)
        {
            int columns=Math.Min(8,count),column=index%8,row=index/8;
            return f.Pos+new V2((column-(columns-1)*.5f)*.7f,1.8f+row*.95f);
        }
        void LaunchYangSwords(Fighter f)
        {
            int count=f.YangSwords;f.YangSwords=0;
            for(int i=0;i<count;i++)
            {
                V2 from=YangPosition(f,i,count);
                var e=Shoot(f,60,24,.19f,0,false,"yang-sword",direction:(Enemy(f).Pos-from).Normal);
                e.Pos=from;e.Pierce=true;e.MaxRange=100;e.Expires=Time+8;
                e.Hit.Knock=1;e.Hit.Stun=0;
            }
        }
        void UpdateNavalPassives(Fighter f)
        {
            if(f.HP<=0||f.Dead)return;
            if(f.Job==Job.Institutor&&Time>=f.NextYangAt)
            {f.YangSwords++;f.NextYangAt+=3;}
            if(f.BurnTicks>0&&Time>=f.NextBurnAt)
            {
                f.BurnTicks--;f.NextBurnAt+=1;
                if(f.BurnOwner>=0)
                {
                    // Damage over time neither interrupts casts nor farms fixed hit gauges.
                    var h=new Hit{Owner=f.BurnOwner,Damage=8,Knock=0,Stun=0,NoGauge=true,NoLeech=true,Tag="burn"};
                    ApplyHit(f,h);
                }
                if(f.BurnTicks==0)f.BurnOwner=-1;
            }
        }
    }
}
