using System;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        void KingGateShot(Fighter f,int shot)
        {
            // Re-evaluate target and facing for each shot; no aim input is needed.
            V2 from=f.Pos+new V2(-f.Facing*(shot==0?1.4f:2f),shot==0?1.1f:1.6f);
            V2 direction=(Enemy(f).Pos-from).Normal;
            var e=Shoot(f,20,22,.23f,0,false,"king-gate",direction:direction);
            e.Pos=from;e.MaxRange=40;
            Cue(from,"","gate",f.Id,.5f,.25f);
        }
        void NisemonoBlade(Fighter f,bool close)
        {
            if(close)Melee(f,20,2.3f,4);
            else
            {
                var e=Shoot(f,18,22,.22f,0,false,"nisemono-blade",direction:(Enemy(f).Pos-f.Pos).Normal);
                e.MaxRange=45;e.Style=f.BladeSerial++%2;
            }
        }
        void ArenaBeam(Fighter f,float damage,float knock,int direction)
        {
            int facing=direction<0?-1:1;
            float length=Math.Max(0,facing>0?Arena.Right-f.Pos.x:f.Pos.x-Arena.Left);
            var h=MakeHit(f,damage,knock,true);h.Physical=false;
            h.Direction=new V2(facing,.2f);
            Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Beam,Pos=f.Pos,
                Vel=new V2(facing,0),Width=length,Height=Rules.UltimateBeamHeight,Hit=h,
                Expires=Time+.14f,ActiveAt=Time,NextTick=Time,Ultimate=true,Tag="arena-beam"});
        }
        void UpdateArsenalPassives(Fighter f)
        {
            if(!HasPower(f,Job.Nisemono))return;
            if(!SuddenDeath&&!f.AvalonActive&&f.HP<f.Def.HP*.3f&&f.AvalonReadyAt<=Time)
            {f.AvalonActive=true;f.AvalonReadyAt=Time+20;Cue(f.Pos,"SANCTUARY","ring",f.Id,1.5f,.6f);}
            if(f.AvalonActive)
            {
                if(SuddenDeath||f.HP>=f.Def.HP*.5f)f.AvalonActive=false;
                else {Heal(f,Math.Min(20*Rules.Dt,f.Def.HP*.5f-f.HP));if(f.HP>=f.Def.HP*.5f)f.AvalonActive=false;}
            }
            if(f.RealmUntil<=Time||Time<f.NextRealmVolley)return;
            f.NextRealmVolley+=.5f;
            for(int i=0;i<2;i++)
            {
                int edge=f.RealmVolleyIndex++%4;float t=.15f+.7f*Roll();V2 p;
                if(edge<2)p=new V2(edge==0?Arena.Left+.2f:Arena.Right-.2f,Arena.Bottom+(Arena.Top-Arena.Bottom)*t);
                else p=new V2(Arena.Left+(Arena.Right-Arena.Left)*t,edge==2?Arena.Top-.2f:Arena.Bottom+.2f);
                var e=Shoot(f,20,22,.2f,0,true,"ubw-sword",direction:(Enemy(f).Pos-p).Normal);
                e.Pos=p;e.Pierce=true;e.MaxRange=90;e.Expires=Time+4;e.Hit.Knock=2;
            }
        }
    }
}
