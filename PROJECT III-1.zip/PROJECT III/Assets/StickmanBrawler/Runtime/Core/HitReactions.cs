using System;
using System.Collections.Generic;
namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        sealed class PendingReaction
        {
            public Fighter Target; public int Tick,CastId,ThawOwner=-1;
            public float Duration; public bool Contact,Freeze,Stack;
        }
        readonly List<PendingReaction> pendingReactions=new List<PendingReaction>();
        // Fixed combat ticks, not rendering FPS. No global timeScale changes.
        public bool ContactStopEnabled=true;
        public bool InHitstop(Fighter f){return f.HitstopEndTick>0&&CombatTick<=f.HitstopEndTick;}
        public bool InHitstun(Fighter f){return !InHitstop(f)&&f.HitstunUntil>Time;}
        void StartHitstop(Fighter f)
        {
            if(!ContactStopEnabled||InHitstop(f)||IsFixedDummy(f)||ImmuneControl(f)||f.ArmorUntil>Time||f.UltimateCastingUntil>Time)return;
            f.HitstopStartTick=CombatTick;f.HitstopEndTick=CombatTick+6;f.HitstopPoseTime=Time;
            if(f.HitstunUntil>Time)f.HitstunUntil+=6*Rules.Dt;
        }
        void QueueReaction(Fighter f,float duration,int castId,bool contact,bool freeze=false,int thawOwner=-1,bool stack=false)
        {
            StartHitstop(f);
            var p=new PendingReaction{Target=f,Tick=InHitstop(f)?f.HitstopEndTick:CombatTick,Duration=duration,CastId=castId,Contact=contact,Freeze=freeze,ThawOwner=thawOwner,Stack=stack};
            if(p.Tick==CombatTick)BeginReaction(p);else pendingReactions.Add(p);
        }
        void ProcessReflectorCounter(Fighter f,Controls input)
        {
            if(input.Guard||f.NativeJob!=Job.Reflector||f.Dead||f.HP<=0||(!InHitstop(f)&&!InHitstun(f)))return;
            if(f.StunUntil>Time||f.SilenceUntil>Time||f.SkillLockUntil>Time||f.SlotLockedUntil[1]>Time||f.QAt>Time||!input.Skill1)return;
            f.QAt=Time+f.Def.QCooldown;Skill1(f);
        }
        void BeginReaction(PendingReaction p)
        {
            var f=p.Target;
            if(f.Dead||f.HP<=0||!object.ReferenceEquals(f,Players[f.Id])||CastCanceled(p.CastId))return;
            // Defense acquired during the grace period is respected at onset.
            if(ImmuneControl(f)||f.ArmorUntil>Time||f.UltimateCastingUntil>Time||f.InvulnUntil>Time||f.StealthUntil>Time)return;
            if(p.Contact)f.HitstunUntil=Math.Max(f.HitstunUntil,Time+p.Duration);
            else f.StunUntil=p.Stack?Math.Max(Time,f.StunUntil)+p.Duration:Math.Max(f.StunUntil,Time+p.Duration);
            if(p.Freeze){f.FreezeUntil=f.StunUntil;if(p.ThawOwner>=0){f.FrostThawAt=f.StunUntil;f.FrostThawOwner=p.ThawOwner;}}
            f.InterruptVersion++;f.CastUntil=Time;
        }
        void UpdateReactions()
        {
            var due=pendingReactions.FindAll(p=>p.Tick<=CombatTick);
            pendingReactions.RemoveAll(p=>p.Tick<=CombatTick);
            foreach(var f in Players)if(f.HitstopEndTick>0&&CombatTick>=f.HitstopEndTick)
            {
                f.HitstopEndTick=0;

            }
            foreach(var p in due)BeginReaction(p);
        }
    }
}
