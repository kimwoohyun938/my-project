using System;
namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        bool HasPower(Fighter f,Job job) { return f.Job==job||f.CopiedPowers[(int)job]>Time; }
        public float ChronoRate(Fighter f)
        {
            if(f.ChronoUntil<=Time||ImmuneControl(f))return 1;
            float span=Math.Max(.01f,f.ChronoUntil-f.ChronoStart-.25f);
            return Math.Max(0,.9f*(1-(Time-f.ChronoStart)/span));
        }
        public float MagicianRiftDamage(Fighter f,Fighter target)
        {
            float own=Rules.Clamp(f.HP/f.MaxHP,0,1),other=Rules.Clamp(target.HP/target.MaxHP,0,1);
            return target.HP*(.08f+Math.Max(0,other-own)+(1-own))*.82f;
        }
        float DealtGauge(Fighter source,Hit h,float actual)
        {
            if(h.NoGauge)return 0;
            if(h.FixedGauge>=0)return h.FixedGauge;
            if(h.Ultimate)return 0;
            if(h.Tag.StartsWith("code:"))return 11f;
            switch(h.Tag)
            {
                case "time-rapid":return 0;
                case "time-basic":case "mirror-basic":case "phantom-basic":case "mimic-basic":case "puppet-basic":
                case "frost-basic":case "blood-basic":case "shadow-basic":case "void-basic":return 5.5f;
                case "twin-basic":case "twin-clone-basic":return 4f;
                case "undying-basic":case "iron-basic":case "alchemist-basic":case "ronin-basic":case "ronin-draw":case "maestro-basic":case "pendulum-basic":case "tether-basic":case "prism-basic":case "reactor-basic":case "poltergeist-basic":case "rider-basic":case "luminary-bolt":return 6.5f;
                case "gambler-basic":case "gambler-extra":return 28f;
                case "dino-basic":case "yi-basic":return 8.5f;
                case "qin-basic":return 38f;
                case "timing-basic":case "institutor-basic":return 7.5f;
            }
            return actual*Rules.DealtGaugePerHP+(source.PowerJob==Job.Dystopia&&h.Critical?3:0);
        }
        float ReceivedGauge(Fighter f,float actual)
        {
            switch(f.NativeJob)
            {
                case Job.LTiming:return 5.5f;case Job.Cybercrud:return 6.5f;
                case Job.Undying:return 10f;
                case Job.IronWall:return 8.5f;
                case Job.BloodApostle:return 7.5f;
                case Job.TimeMurder:case Job.MirrorAssassin:case Job.PhantomLegion:case Job.Mimic:case Job.Puppeteer:
                case Job.FrostReaper:case Job.ShadowClone:case Job.VoidWalker:case Job.YiSunGod:case Job.Alchemist:case Job.Ronin:case Job.Maestro:case Job.Pendulum:case Job.Tether:case Job.Prism:case Job.Reactor:case Job.Poltergeist:case Job.Rider:case Job.Luminary:return 6.5f;
                case Job.TwinFang:case Job.Gambler:case Job.Institutor:return 5.5f;
                case Job.DinoMan:return 4.5f;
                case Job.QinShi:return 22f;
                default:return Math.Min(actual,200)*Rules.ReceivedGaugePerHP;
            }
        }
        void RecordSkill(Fighter f,int slot)
        {if(f.Job==Job.Mimic&&slot==2)return;f.LastSkillJob=(int)f.Job;f.LastSkillSlot=slot;f.LastSkillTime=Time;}
        void WithKit(Fighter f,Job job,float scale,Action action)
        {
            Job previous=f.Job;float old=f.CopyScale;
            try{f.Job=job;f.CopyScale=scale;action();}
            finally{f.Job=previous;f.CopyScale=old;}
        }
        float PowerDuration(Job job)
        {
            switch(job)
            {
                case Job.LTiming:return 15;
                case Job.Nisemono:return 18.1f;
                case Job.Vertebrate:case Job.YiSunGod:return 12;
                case Job.Cross:case Job.Director:return 10;
                case Job.PhantomLegion:return 8;
                case Job.TwinFang:return 3;
                case Job.Gambler:return 8.5f;
                case Job.Assassin:case Job.MirrorAssassin:case Job.VoidWalker:case Job.Alchemist:case Job.Reactor:return 6;
                default:return 5;
            }
        }
        bool CanCopy(Fighter f,bool ultimate)
        {
            Fighter foe=Enemy(f);int id=ultimate?foe.LastUltimateJob:foe.LastSkillJob;
            if(id<0||(Job)id==Job.Mimic||(!ultimate&&Time-foe.LastSkillTime>3))return false;
            bool valid=false;
            WithKit(f,(Job)id,ultimate?1:.7f,()=>valid=ultimate?CanUltimate(f):CanSkill(f,foe.LastSkillSlot));
            return valid;
        }
        void CopyEnemy(Fighter f,bool ultimate)
        {
            Fighter foe=Enemy(f);int id=ultimate?foe.LastUltimateJob:foe.LastSkillJob;int slot=foe.LastSkillSlot;
            if(id<0||(Job)id==Job.Mimic)return;
            f.CopiedPowers[id]=Time+(ultimate?PowerDuration((Job)id):20);
            if(ultimate){f.CopiedPowerJob=id;f.CopiedPowerUntil=Time+PowerDuration((Job)id);}
            float ownQ=f.QAt,ownE=f.EAt;
            WithKit(f,(Job)id,ultimate?1:.7f,()=>{if(ultimate)Ultimate(f);else if(slot==1)Skill1(f);else Skill2(f);});
            if(!ultimate){
                var twin=FindSummon(f,"twin");
                if(f.TwinUltUntil>Time&&twin!=null){V2 original=f.Pos;try{f.Pos=twin.Pos;WithKit(f,(Job)id,.7f,()=>{if(slot==1)Skill1(f);else Skill2(f);});}finally{f.Pos=original;}}
                f.QAt=ownQ;f.EAt=ownE;
            }
            if(!ultimate){f.LastSkillJob=id;f.LastSkillSlot=slot;f.LastSkillTime=Time;}
            Cue(f.Pos,"COPIED "+Roster.Get((Job)id).Name,"text",f.Id);
        }
        void BlinkVolley(Fighter f)
        {
            Fighter target=Enemy(f);
            if(!Teleport(f,target.Pos-new V2(target.Facing*1.4f,0),8))return;
            f.Facing=target.Pos.x>f.Pos.x?1:-1;
            for(int i=-1;i<=1;i++)
            {
                var e=Shoot(f,0,14,.16f,8,false,"mage-seeker",direction:new V2(f.Facing,i*.6f));
                e.Pos=f.Pos+new V2(0,i*.35f);
                e.Hit.CurrentPercent=.03f*f.CopyScale;e.Hit.Critical=false;e.Hit.Knock=1.5f;e.Hit.Stun=0;e.MaxRange=50;
            }
        }
        void Inferno(Fighter f)
        {
            var h=MakeHit(f,0,0,true);h.Critical=false;h.MaximumPercent=.0115f*f.CopyScale;h.Stun=0;h.Physical=false;h.Tag="inferno";
            var e=Zone(f,Enemy(f).Pos,3,h,5,0,50,.1f);e.Tag="inferno";
        }
        void TimeZero(Fighter f)
        {
            Fighter target=Enemy(f);
            if(ApplyHit(target,StatusHit(f,CC.Slow,7,true,1))&&target.SlowUntil>Time&&!ImmuneControl(target))
            {target.ChronoStart=Time;target.ChronoUntil=Math.Min(Time+7,target.SlowUntil);Cue(target.Pos,"TIME ZERO","aura",f.Id,2,1);}
        }
        void RapidStrike(Fighter f)
        {
            float reach=1.8f;V2 center=f.Pos+new V2(f.Facing*reach*.55f,0);
            if(V2.Distance(center,Enemy(f).Pos)<=reach*.6f+Enemy(f).Radius(Time))
            {var h=MakeHit(f,2*f.RapidScale,0);h.Tag="time-rapid";h.Stun=0;ApplyHit(Enemy(f),h);}
            if(Time>=f.NextRapidVisual){f.NextRapidVisual=Time+.08f;f.AttackVisualUntil=Time+.09f;Cue(f.Pos,"","slash",f.Id,1.8f,.09f,center);}
        }
        void LancerCast(Fighter f)
        {
            if(!f.HasSpear){RecoverSpear(f,false);return;}
            f.HasSpear=false;f.SpearRecallAt=f.QAt=Time+3;f.GuardUntil=Math.Max(f.GuardUntil,Time+1.2f);
            var e=Shoot(f,115,32,.26f,0,false,"spear",CC.Stun,.35f);e.MaxRange=28;
        }
        void RecoverSpear(Fighter f,bool pickup)
        {
            f.HasSpear=true;f.QAt=pickup?Time:Time+4;f.Buff2Until=Math.Max(f.Buff2Until,Time+2f);
            foreach(var e in Effects)if(e.Owner==f.Id&&(e.Tag=="spear"||e.Shape==Shape.Spear))e.Dead=true;
            Cue(f.Pos,pickup?"PICKUP / Q READY":"RECALLED / THROW 4s","text",f.Id);
        }
        void AssassinVeil(Fighter f)
        {
            var e=Shoot(f,30,22,.22f,0,false,"assassin-chain",CC.Root,1,direction:(Enemy(f).Pos-f.Pos).Normal);
            e.Hit.Critical=false;e.MaxRange=12;
            f.StealthUntil=Time+1.5f;f.NextCrit=true;
        }
        void HassanArm(Fighter f)
        {
            Charge(f,.35f,18);
            Later(f,.35f,()=>{var e=Shoot(f,1/Rules.UltimateDamageScale,24,.3f,10,true,"hassan-arm",direction:(Enemy(f).Pos-f.Pos).Normal);
                e.MaxRange=Rules.HassanUltimateReach-V2.Distance(e.Pos,f.Pos);e.Pierce=true;e.Hit.Stun=0;e.Hit.Knock=0;e.Origin=f.Pos;});
        }
        void WolfHunt(Fighter f)
        {
            Charge(f,.55f,9);Cue(Enemy(f).Pos,"HUNT","warning",f.Id,2,.55f);
            Later(f,.55f,()=>{Fighter target=Enemy(f);Teleport(f,target.Pos-new V2(target.Facing*1.2f,0),100);
                var h=MakeHit(f,200,12,true,CC.Stun,.8f);h.BypassInvulnerability=true;
                ApplyHit(target,h);Cue(target.Pos,"","burst",f.Id,2,.4f);});
        }
        void TrackedStone(Fighter f)
        {
            Cue(Enemy(f).Pos,"STONE RISE","warning",f.Id,1.2f,.35f);
            Later(f,.35f,()=>{Fighter target=Enemy(f);var h=MakeHit(f,90,12);h.Direction=new V2(.1f,1);ApplyHit(target,h);Cue(target.Pos,"","burst",f.Id,1.5f,.4f);});
        }
        void ClampArena(Fighter f)
        {
            if(!Arena.Closed)return;
            float x=f.Pos.x,y=f.Pos.y;
            f.Pos.x=Rules.Clamp(x,Arena.Left+f.Radius(Time),Arena.Right-f.Radius(Time));
            f.Pos.y=Rules.Clamp(y,Arena.Bottom+f.HalfHeight(Time),Arena.Top-f.HalfHeight(Time));
            if(x!=f.Pos.x)f.Vel.x=0;
            if(y!=f.Pos.y)f.Vel.y=0;
            if(f.Pos.y<=Arena.Bottom+f.HalfHeight(Time)+.001f){f.Grounded=true;f.Jumps=0;f.LastGrounded=Time;}
            if(f.RootUntil>Time)f.RootPos=f.Pos;
        }
        void UpdateV2(Fighter f)
        {
            if(f.CopiedPowerUntil<=Time)f.CopiedPowerJob=-1;
            if(f.UndyingUntil>0&&f.UndyingUntil<=Time)
            {
                float debt=f.UndyingDebt*.3f;f.UndyingUntil=0;f.UndyingDebt=0;
                if(debt>0)ApplyHit(f,new Hit{Owner=f.Id,Damage=debt,TrueDamage=true,BypassInvulnerability=true,BypassOneHitShield=true,
                    Unavoidable=true,Reflected=true,NoGauge=true,NoLeech=true,Knock=0,Stun=0,Tag="undying-debt"});
                Cue(f.Pos,"DEFERRED "+Math.Round(debt),"text",f.Id);
            }
            UpdateSummoner(f);
        }
        void V2OnHit(Fighter source,Fighter victim,Hit h,float actual)
        {
            if(h.Tag=="time-rapid")Heal(source,.1f*source.RapidScale);
            if(h.Tag=="hassan-arm"){victim.DoomOwner=source.Id;victim.DoomAt=Time+2;Cue(victim.Pos,"DOOM 2.0","text",source.Id,1,2);}
            if(h.Tag=="assassin-chain"&&source.RootUntil<=Time)
            {Teleport(source,victim.Pos+new V2(victim.Facing*1.3f,0),100);source.Facing=victim.Pos.x>source.Pos.x?1:-1;}
            if(h.SummonCredit!=null&&!h.SummonCredit.Dead)h.SummonCredit.AccumulatedDamage+=actual;
        }
    }
}
