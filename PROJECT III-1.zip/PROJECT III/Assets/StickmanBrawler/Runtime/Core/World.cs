using System;
using System.Collections.Generic;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public bool RemoteView;
        public readonly bool[] RemoteReturn=new bool[2],RemoteIntercept=new bool[2];
        public readonly Fighter[] Players;
        public readonly List<Effect> Effects=new List<Effect>();
        public readonly List<Cue> Cues=new List<Cue>();
        readonly List<Scheduled> scheduled=new List<Scheduled>();
        readonly Random rng;
        public float DuelUntil;
        public int DuelOwner=-1,DuelTarget=-1;
        public V2 DuelCenter;
        readonly Queue<int>[] gods={new Queue<int>(),new Queue<int>(),new Queue<int>(),new Queue<int>()};
        readonly float[] reflectedTotal=new float[4];
        readonly Dictionary<int,int> shurikenHits=new Dictionary<int,int>();
        int groupSerial;
        public Arena Arena;
        public Phase Phase=Phase.Countdown;
        public float Time,PhaseUntil=2,Remaining=240;
        public bool Training,SuddenDeath;
        public int Winner=-1,Round=1,HitSerial;
        public string Announcement="GET READY";
        public float LastDamage,ComboDamage;
        public int ComboHits;
        float labComboAt;
        public World(Job p1,Job p2,int stage=0,int seed=173,bool training=false)
        {
            rng=new Random(seed);Arena=Arena.Create(stage);Training=training;
            Players=new[]{new Fighter(0,p1),new Fighter(1,p2)};
            InitializeModes(new MatchOptions{Mode=training?BattleMode.TrainingRespawn:BattleMode.Classic});
            ResetRound();PhaseUntil=2;
        }
        public Fighter Enemy(Fighter f) { return SelectEnemy(f); }
        public float Roll() { return (float)rng.NextDouble(); }
        void RefillGods(int player)
        {
            var list=new List<int>{0,1,2,3,4};
            for(int i=4;i>0;i--){int j=rng.Next(i+1);int tmp=list[i];list[i]=list[j];list[j]=tmp;}
            foreach(int x in list)gods[player].Enqueue(x);
        }
        public int NextGod(int player) { return gods[player].Peek(); }
        int DrawGod(int player) { return rng.Next(5); }
        public void Cue(V2 pos,string text,string kind,int owner=0,float size=1,float duration=.5f,V2? end=null)
        { Cues.Add(new Cue{Pos=pos,End=end??pos,Text=text,Kind=kind,Owner=owner,Size=size,Start=Time,Expires=Time+duration}); }
        void Later(Fighter f,float delay,Action action,bool interruptible=false)
        { Job kit=f.Job;float scale=f.CopyScale;int id=activeCast;scheduled.Add(new Scheduled{CastId=id,At=Time+delay,Owner=f.Id,Run=()=>WithKit(f,kit,scale,action),Interruptible=interruptible,Version=f.InterruptVersion}); }
        public void ResetRound()
        {
            pendingReactions.Clear();ResetTiming();Effects.Clear();scheduled.Clear();Cues.Clear();shurikenHits.Clear();DuelUntil=0;DuelOwner=DuelTarget=-1;
            foreach(Fighter f in Players){f.Reset(Time,SuddenDeath?300:-1);f.Pos=SpawnPosition(f.Id);f.Facing=Mode==BattleMode.DpsEvent?(f.Id<2?1:-1):(f.Pos.x<0?1:-1);}
            foreach(Fighter f in Players)UpdateSummoner(f);
            ResetSpecialMode();
            Array.Clear(reflectedTotal,0,reflectedTotal.Length);ComboHits=0;ComboDamage=0;
        }
        public void RefillTraining()
        { if(!Training)return; foreach(Fighter f in Players){f.HP=f.MaxHP;f.Gauge=100;f.QAt=f.EAt=f.UltAt=0;} }
        public void ResetTraining()
        { if(!Training)return;ResetRound();Phase=Phase.Countdown;PhaseUntil=Time+1; }
        public void Tick(Controls a,Controls b) { Tick(new[]{a,b}); }
        public void Tick(Controls[] inputs)
        {
            if(RemoteView)throw new InvalidOperationException("A network display world cannot simulate combat.");
            if(Phase==Phase.Finished||NeedsSelection)return;
            CombatTick++;Time+=Rules.Dt;UpdateTimingTimers();Cues.RemoveAll(c=>c.Expires<=Time);
            if(Phase==Phase.Countdown)
            { if(Time>=PhaseUntil){Phase=Phase.Fight;foreach(var f in Players){f.InvulnUntil=Time+.9f;if(f.Job==Job.Institutor)f.NextYangAt=Time+3;}Announcement="FIGHT";Cue(new V2(0,5),"FIGHT","text",0,2,1);}return; }
            if(Phase==Phase.RoundOver)
            { if(Time>=PhaseUntil){ResetRound();Phase=Phase.Countdown;PhaseUntil=Time+1.2f;Round++;}return; }
            if(!Training && !SuddenDeath && Mode==BattleMode.Classic)
            {
                Remaining-=Rules.Dt;
                if(Remaining<=0)
                {
                    Remaining=0;
                    if(Players[0].Score!=Players[1].Score){Finish(Players[0].Score>Players[1].Score?0:1);return;}
                    SuddenDeath=true;ResetRound();Phase=Phase.Countdown;PhaseUntil=Time+2;Announcement="SUDDEN DEATH";return;
                }
            }
            UpdateRespawns();UpdateBossPattern();
            var prepared=new Controls[Players.Length];
            for(int i=0;i<Players.Length;i++)prepared[i]=PrepareControls(Players[i],InputAt(inputs,i));
            inputs=prepared;
            bool[] allowed=new bool[Players.Length];
            for(int i=0;i<Players.Length;i++){allowed[i]=CanAct(Players[i]);SetPuppetInput(Players[i],InputAt(inputs,i));}
            for(int i=0;i<Players.Length;i++)if(!Players[i].Dead)Move(Players[i],Players[i].IsBoss?BossMovement(Players[i]):InputAt(inputs,i));
            for(int i=0;i<Players.Length;i++)Act(Players[i],Players[i].IsBoss?BossMovement(Players[i]):InputAt(inputs,i),allowed[i]);
            // Execute a snapshot: callbacks may enqueue subsequent events safely.
            var due=scheduled.FindAll(s=>s.At<=Time);scheduled.RemoveAll(s=>s.At<=Time);
            foreach(var s in due)
            {
                Fighter f=Players[s.Owner];
                if(f.Dead || f.HP<=0 || (s.Interruptible && s.Version!=f.InterruptVersion))continue;
                if(!CastCanceled(s.CastId))using(CastScope(s.CastId))s.Run();
            }
            UpdateEffects();
            foreach(var f in Players)UpdatePassives(f);
            for(int i=0;i<Players.Length;i++){ProcessTimingInput(Players[i],InputAt(inputs,i));ProcessReflectorCounter(Players[i],InputAt(inputs,i));}
            UpdateReactions();
            // Resolve both fatalities together so simultaneous trades can draw.
            foreach(var f in Players){ClampArena(f);TryBloodRevive(f);}
            if(Mode==BattleMode.Classic)
            {bool deadA=IsKO(Players[0])&&!TimingGrace(Players[0]),deadB=IsKO(Players[1])&&!TimingGrace(Players[1]);if(deadA||deadB)ResolveKO(deadA,deadB);}
            else ResolveContinuousKO();
            RestoreFixedDummy();UpdateEvent();
            if(Time-labComboAt>2){ComboHits=0;ComboDamage=0;}
        }
        bool CanAct(Fighter f) { return !InHitstop(f) && !f.Dead && !f.AwaitingPick && f.HP>0 && f.StunUntil<=Time && f.HitstunUntil<=Time && f.CastUntil<=Time && f.UltimateCastingUntil<=Time && !(HasPower(f,Job.TimeMurder) && f.InvulnUntil>Time && f.BuffUntil>Time); }
        void Act(Fighter f,Controls c,bool allowed)
        {
            if(!c.Attack)f.RapidBudget=0;
            if(f.NativeJob==Job.LTiming&&(c.Skill1||c.Skill2)&&!c.Ultimate)return;
            if(c.Guard||!allowed||IsDummy(f))return;
            if(c.Ultimate && f.SlotLockedUntil[3]<=Time && f.SilenceUntil<=Time && f.Gauge>=100)
            { f.BufferedUntil[3]=0;if(CanUltimate(f)){f.InvulnUntil=0;f.Gauge=0;f.UltAt=0;Ultimate(f);}return; }
            if(c.Skill1 && f.SlotLockedUntil[1]<=Time && f.SilenceUntil<=Time && f.SkillLockUntil<=Time && (f.QAt<=Time || (f.Job==Job.VoidWalker&&f.VoidRecastAvailable&&f.VoidRecastUntil>Time)))
            { f.BufferedUntil[1]=0;if(CanSkill(f,1)){f.InvulnUntil=0;if(f.Job!=Job.VoidWalker&&f.Job!=Job.Lancer)f.QAt=Time+(IsShip(f)?3:f.Def.QCooldown);if(f.NativeJob==Job.Mimic&&IsShip(f))WithKit(f,Job.YiSunGod,1,()=>Skill1(f));else Skill1(f);}return; }
            if(c.Skill2 && f.SlotLockedUntil[2]<=Time && f.SilenceUntil<=Time && f.SkillLockUntil<=Time && f.EAt<=Time)
            { f.BufferedUntil[2]=0;if(CanSkill(f,2)){f.InvulnUntil=0;f.EAt=Time+(IsShip(f)?5:f.Def.ECooldown);if(f.NativeJob==Job.Mimic&&IsShip(f))WithKit(f,Job.YiSunGod,1,()=>Skill2(f));else Skill2(f);}return; }
            if(c.Attack && f.AttackAt<=Time&&f.ShadowAssaultUntil<=Time&&(f.Job!=Job.ShadowClone||f.StealthUntil<=Time))
            {
                f.InvulnUntil=0;float rate=1;
                
                if(HasPower(f,Job.CardMan)&&f.Buff2Until>Time)rate*=1.4f;
                if(f.ArcherHasteUntil>Time)rate*=1.3f;
                if(f.LancerFuryUntil>Time)rate*=1.25f;
                if(Fortune(f)>0)rate*=Fortune(f)==1?1.57f:1.77f;
                rate*=ColdAttackRate(f)*ChronoRate(f)*(f.CyberSlowUntil>Time?.7f:1);
                if(rate<=.00001f){f.RapidBudget=0;return;}
                if(f.Overclock)
                {
                    f.RapidBudget+=Rules.Dt*rate/.01f;
                    while(f.RapidBudget>=1){f.RapidBudget-=1;RapidStrike(f);}
                    f.AttackAt=Time;return;
                }
                float interval=CyberAttackInterval(f,f.Job==Job.Luminary?LuminaryConfig.AttackInterval:f.Def.AttackInterval);
                if(IsShip(f))interval=.85f;
                if(HasPower(f,Job.Assassin)&&f.FormUntil>Time)interval=.14f;
                if(f.Job==Job.CardMan&&f.Card!=0)interval=f.Card==1?.8f:.65f;
                f.BufferedUntil[4]=0;f.AttackAt=Time+interval/rate;Basic(f);
            }
        }
        void Move(Fighter f,Controls c)
        {
            if(InHitstop(f))return;
            if(IsFixedDummy(f)){f.Pos=SpawnPosition(f.Id);f.Vel=new V2();return;}
            if(f.FreezeUntil>Time){f.Vel=new V2();ClampDuel(f);return;}
            float scale=f.Scale(Time);
            if(f.Grounded&&Math.Abs(scale-f.BodyScale)>.001f){float rise=.9f*(scale-f.BodyScale);f.Pos.y+=rise;f.RootPos.y+=rise;}
            f.BodyScale=scale;
            if(HasPower(f,Job.TimeMurder)&&f.BuffUntil>Time&&f.InvulnUntil>Time){f.Vel=new V2();return;}
            bool locked=c.Guard || f.StunUntil>Time || f.HitstunUntil>Time || f.CastUntil>Time || (HasPower(f,Job.TimeMurder) && f.BuffUntil>Time && f.InvulnUntil>Time);
            if(f.RootUntil>Time){f.Pos=f.RootPos;f.Vel=new V2();return;}
            if(f.PuppetCommand){c.Move=0;c.Jump=false;}
            if(c.Guard&&f.RecoilUntil<=Time)f.Vel.x=0;
            float speed=f.Def.Speed*ChronoRate(f);
            if(f.UndyingGuardUntil>Time)speed*=.6f;
            if(f.MirrorFadeUntil>Time)speed*=1.2f;
            if(IsShip(f))speed*=1.1f;
            if(Array.Exists(Players,p=>Opponents(f.Id,p.Id)&&Alive(p)&&DuelAllows(f.Id,p.Id)&&IsShip(p))&&!ImmuneControl(f))speed*=.9f;
            if(Fortune(f)>0)speed*=Fortune(f)==1?1.67f:1.77f;
            if(f.YangSprintUntil>Time)speed*=1.3f;
            if(f.YangUltimateUntil>Time)speed*=1.2f;
            if(HasPower(f,Job.Berserker))speed*=1+.5f*(1-f.HP/f.Def.HP);
            if(f.Overclock)speed*=1.2f;
            if(f.StealthUntil>Time || (HasPower(f,Job.Hassan)&&f.Buff2Until>Time))speed*=1.2f;
            if(HasPower(f,Job.Assassin)&&f.FormUntil>Time)speed*=1.2f;
            if(f.SlowUntil>Time)speed*=f.SlowFactor;
            if(f.BloodGuardUntil>Time)speed*=1.25f;
            if(f.AlchemistHasteUntil>Time)speed*=1.25f;
            if(f.RoninWindUntil>Time)speed*=1.25f;
            if(HasPower(f,Job.Maestro)&&f.MaestroTempo>0&&f.MaestroTempoUntil>Time)speed*=1+.08f*f.MaestroTempo;
            if(f.PendulumSwingUntil>Time)speed*=1.35f;
            if(f.PendulumOrbitUntil>Time)speed*=1.45f;
            if(f.PrismBuffUntil>Time)speed*=1.25f;
            if(f.RiderPegasusUntil>Time)speed*=1.25f;
            if(f.LancerFuryUntil>Time||(HasPower(f,Job.Lancer)&&f.Buff2Until>Time))speed*=1.25f;
            if(f.ArcherHasteUntil>Time)speed*=1.3f;
            if(HasPower(f,Job.Thunder)&&f.BuffUntil>Time)speed*=1.2f;
            if(f.GorgonSlowUntil>Time)speed*=.6f;
            if(HasPower(f,Job.ShadowClone)&&f.StealthUntil>Time)speed*=1.3f/1.2f;
            if(!locked && f.RecoilUntil<=Time)
            { f.Vel.x=Rules.Approach(f.Vel.x,c.Move*speed,Rules.Dt*(f.Grounded?80:35));if(c.Move!=0)f.Facing=c.Move>0?1:-1; }
            else if(f.Grounded && f.RecoilUntil<=Time)f.Vel.x=Rules.Approach(f.Vel.x,0,Rules.Dt*20);
            if(!locked && c.Jump && (f.Jumps<2 || Time-f.LastGrounded<.1f))
            { f.BufferedUntil[0]=0;f.Vel.y=Rules.Jump*(Fortune(f)==1?1.17f:1);f.Jumps++;f.Grounded=false;f.LastGrounded=-10;Cue(f.Pos-new V2(0,.8f),"","ring",f.Id,.6f,.3f); }
            if(f.AirUntil>Time)
            { f.Vel.y=Rules.Approach(f.Vel.y,!locked&&c.Jump?7:1,Rules.Dt*50); }
            else f.Vel.y=Math.Max(f.Vel.y-Rules.Gravity*Rules.Dt,-28);
            if(f.VoidPhaseUntil>Time)
            {
                f.Vel.y=locked?0:c.Jump?8:0;f.Pos+=f.Vel*Rules.Dt;ClampDuel(f);return;
            }
            V2 old=f.Pos,next=f.Pos+f.Vel*Rules.Dt;float half=f.HalfHeight(Time),radius=f.Radius(Time);
            f.Grounded=false;
            // One-way platforms: only descending feet crossing a top can land.
            foreach(var p in Arena.Platforms)
            {
                if(f.Vel.y<=0 && old.y-half>=p.Y-.07f && next.y-half<=p.Y && next.x+radius>p.X-p.Width/2 && next.x-radius<p.X+p.Width/2)
                { next.y=p.Y+half;f.Vel.y=0;f.Grounded=true;f.Jumps=0;f.LastGrounded=Time; }
            }
            foreach(var wall in Effects)
            {
                if(wall.Dead||wall.Shape!=Shape.Wall||wall.Expires<=Time)continue;
                float left=wall.Pos.x-wall.Width/2-radius,right=wall.Pos.x+wall.Width/2+radius;
                if(next.y-half<wall.Pos.y+wall.Height/2 && next.y+half>wall.Pos.y-wall.Height/2)
                {
                    if(old.x<=left && next.x>left){next.x=left;f.Vel.x=0;}
                    else if(old.x>=right && next.x<right){next.x=right;f.Vel.x=0;}
                }
            }
            f.Pos=next;ClampDuel(f);
        }
        bool IsKO(Fighter f)
        { return f.HP<=0 || (!Arena.Closed&&(f.Pos.x<Arena.Left || f.Pos.x>Arena.Right || f.Pos.y<Arena.Bottom || f.Pos.y>Arena.Top)); }
        void ResolveKO(bool a,bool b)
        {
            if(a){Players[0].Dead=true;Players[1].Score++;Cue(Players[0].Pos,"KO","burst",1,3,1.5f);}
            if(b){Players[1].Dead=true;Players[0].Score++;Cue(Players[1].Pos,"KO","burst",0,3,1.5f);}
            Effects.Clear();scheduled.Clear();
            if(!Training)
            {
                if(SuddenDeath && a!=b){Finish(a?1:0);return;}
                bool winA=Players[0].Score>=Rules.TargetScore,winB=Players[1].Score>=Rules.TargetScore;
                if(winA&&winB){SuddenDeath=true;Announcement="DOUBLE KO / SUDDEN DEATH";}
                else if(winA||winB){Finish(winA?0:1);return;}
                else Announcement=a&&b?"DOUBLE KO":a?"PLAYER 2 SCORES":"PLAYER 1 SCORES";
            }
            else Announcement="TRAINING RESET";
            Phase=Phase.RoundOver;PhaseUntil=Time+1.6f;
        }
        void Finish(int winner) { Winner=winner;Phase=Phase.Finished;Announcement=Mode==BattleMode.Teams?"팀 "+(Players[winner].TeamId+1)+" 승리":"자리 "+(winner+1)+" 승리";Effects.Clear();scheduled.Clear(); }
        public void Heal(Fighter f,float amount)
        { if(SuddenDeath||f.HP<=0||f.Dead)return;f.HP=Math.Min(f.MaxHP,f.HP+amount*f.CopyScale); }
        void UpdatePassives(Fighter f)
        {
            if(f.HP<=0||f.Dead)return;
            f.Gauge=Math.Min(100,f.Gauge+Rules.Dt*Rules.PassiveGaugePerSecond);
            if(HasPower(f,Job.Cross))Heal(f,Rules.Dt*10);
            if(f.Overclock)
            { if(f.SilenceUntil>Time){f.Overclock=false;}else{f.HP=Math.Max(0,f.HP-Rules.Dt*9);if(f.HP<=0)f.Overclock=false;} }
            if(!f.HasSpear)
            { foreach(var e in Effects)if(e.Owner==f.Id&&e.Shape==Shape.Spear&&!e.Dead&&V2.Distance(f.Pos,e.Pos)<1.4f){RecoverSpear(f,true);} }
            using(CastScope(PassiveCast(f)))UpdateArsenalPassives(f);
            using(CastScope(PassiveCast(f)))UpdateNavalPassives(f);
            if(Fortune(f)==2)Heal(f,777*Rules.Dt);
            UpdateExpansion(f);
            UpdateV2(f);
            if(f.DoomAt>0)
            {
                Fighter caster=f.DoomOwner>=0?Players[f.DoomOwner]:Enemy(f);
                if(caster.HP<=0 || IsKO(caster))
                { f.DoomAt=0;Cue(f.Pos,"SIGIL BROKEN","text",f.Id); }
                else if(Time>=f.DoomAt)
                {
                    f.DoomAt=0;Hit h=MakeHit(caster,9999,8,true);h.Tag="doom";h.BypassOneHitShield=true;ApplyHit(f,h);
                }
            }
        }
        public bool ClearPath(V2 from,V2 to)
        {
            foreach(var e in Effects)
                if(!e.Dead&&e.Shape==Shape.Wall&&e.Expires>Time&&SegmentBox(from,to,e.Pos,e.Width/2,e.Height/2))return false;
            return true;
        }
        static bool SegmentBox(V2 a,V2 b,V2 c,float hw,float hh)
        {
            float lo=0,hi=1;V2 d=b-a;
            float[] starts={a.x-c.x,a.y-c.y},deltas={d.x,d.y},extents={hw,hh};
            for(int i=0;i<2;i++)
            { if(Math.Abs(deltas[i])<.00001f){if(Math.Abs(starts[i])>extents[i])return false;continue;}
              float t1=(-extents[i]-starts[i])/deltas[i],t2=(extents[i]-starts[i])/deltas[i];if(t1>t2){float t=t1;t1=t2;t2=t;}
              lo=Math.Max(lo,t1);hi=Math.Min(hi,t2);if(lo>hi)return false; }
            return true;
        }
        bool Teleport(Fighter f,V2 pos,float range=9)
        {
            if(f.RootUntil>Time || V2.Distance(f.Pos,pos)>range+1.5f)return false;
            pos.x=Rules.Clamp(pos.x,Arena.Left+1,Arena.Right-1);pos.y=Rules.Clamp(pos.y,Arena.Bottom+1,Arena.Top-1);
            // Keep arrival points outside temporary solid barriers.
            foreach(var e in Effects)if(!e.Dead&&e.Shape==Shape.Wall&&Math.Abs(pos.y-e.Pos.y)<e.Height/2+f.HalfHeight(Time)&&Math.Abs(pos.x-e.Pos.x)<e.Width/2+f.Radius(Time))pos.x=e.Pos.x+(pos.x<e.Pos.x?-1:1)*(e.Width/2+f.Radius(Time)+.05f);
            Cue(f.Pos,"","ring",f.Id,1,.4f);f.Pos=pos;ClampDuel(f);ClampArena(f);f.Vel=new V2();Cue(pos,"","ring",f.Id,1,.4f);return true;
        }
    }
}
