using System;

namespace StickmanBrawler.Core
{
    public static class LuminaryConfig
    {
        public static float AttackInterval = 0.48f;
        public static float DashSpeed = 28f;
        public static float DashDuration = 0.16f;
        public static float DashAcquireRange = 8.5f;
        public static float MaxDashDistance = 4.2f;
        public static float DashStopDistance = 1.35f;
        public static float ShardSpeed = 22f;
        public static float ShardTurnRate = 7.5f;
        public static float ShardLifetime = 2.6f;
        public const int MaxShards = 9;
        public const int ShardsPerCharge = 3;
        public const int OverwhelmTriggerStacks = 6;
    }

    public sealed partial class World
    {
        // 1. Independent Target Acquisition System
        public Fighter AcquireLuminaryTarget(Fighter f)
        {
            if (f.TargetId >= 0 && f.TargetId < Players.Length)
            {
                Fighter manual = Players[f.TargetId];
                if (Opponents(f.Id, manual.Id) && Alive(manual) && DuelAllows(f.Id, manual.Id))
                    return manual;
            }
            Fighter best = null;
            float bestScore = float.MaxValue;
            foreach (var candidate in Players)
            {
                if (!Opponents(f.Id, candidate.Id) || !Alive(candidate) || !DuelAllows(f.Id, candidate.Id))
                    continue;
                float dist = V2.Distance(f.Pos, candidate.Pos);
                bool inFront = (candidate.Pos.x - f.Pos.x) * f.Facing >= -0.5f;
                float score = dist - (inFront ? 1.25f : 0f);
                if (score < bestScore)
                {
                    bestScore = score;
                    best = candidate;
                }
            }
            return best ?? Enemy(f);
        }

        // 2. Independent Dash & Anti-Overshoot Movement System
        void StartLuminaryDash(Fighter f, Fighter target)
        {
            if (f.RootUntil > Time || f.LuminaryDashUntil > Time)
                return;
            V2 toTarget = target != null && Alive(target) ? target.Pos - f.Pos : new V2(f.Facing * 3f, 0);
            float dist = toTarget.Length;
            if (Math.Abs(toTarget.x) > 0.05f)
                f.Facing = toTarget.x >= 0 ? 1 : -1;

            f.LuminaryTargetId = target != null ? target.Id : -1;
            f.LuminaryDashOrigin = f.Pos;

            if (dist <= LuminaryConfig.DashStopDistance)
            {
                // Already at ideal strike distance: micro-step without crossing over target
                f.Vel.x = f.Facing * 4f;
                f.LuminaryDashUntil = Time + 0.05f;
                Cue(f.Pos, "", "luminary-afterimage", f.Id, 1.1f, 0.2f, f.Pos);
                return;
            }

            float desiredTravel = dist <= LuminaryConfig.DashAcquireRange
                ? Math.Min(LuminaryConfig.MaxDashDistance, Math.Max(0.4f, dist - LuminaryConfig.DashStopDistance))
                : LuminaryConfig.MaxDashDistance * 0.65f;

            V2 dir = dist > 0.001f ? toTarget.Normal : new V2(f.Facing, 0);
            dir.y = Rules.Clamp(dir.y, -0.35f, 0.45f);
            dir = dir.Normal;

            float duration = Rules.Clamp(desiredTravel / Math.Max(8f, LuminaryConfig.DashSpeed), 0.06f, LuminaryConfig.DashDuration);
            f.LuminaryDashUntil = Time + duration;
            f.RecoilUntil = Time + duration;
            f.Vel = dir * LuminaryConfig.DashSpeed;
            Cue(f.Pos, "", "luminary-afterimage", f.Id, 1.3f, 0.25f, f.Pos + dir * desiredTravel);
        }

        void UpdateLuminaryDash(Fighter f)
        {
            if (f.LuminaryDashUntil <= Time)
                return;
            if (f.RootUntil > Time || f.StunUntil > Time || InHitstop(f))
            {
                f.LuminaryDashUntil = 0;
                return;
            }

            // Re-acquire if target died mid-dash
            Fighter target = (f.LuminaryTargetId >= 0 && f.LuminaryTargetId < Players.Length && Alive(Players[f.LuminaryTargetId]))
                ? Players[f.LuminaryTargetId]
                : AcquireLuminaryTarget(f);

            if (target != null && Alive(target))
            {
                V2 delta = target.Pos - f.Pos;
                float dist = delta.Length;
                if (Math.Abs(delta.x) > 0.05f)
                    f.Facing = delta.x >= 0 ? 1 : -1;

                // Prevent overshooting through the enemy or flying off-screen
                if (dist <= LuminaryConfig.DashStopDistance || V2.Distance(f.LuminaryDashOrigin, f.Pos) >= LuminaryConfig.MaxDashDistance)
                {
                    f.LuminaryDashUntil = 0;
                    f.RecoilUntil = Time;
                    f.Vel = new V2(f.Vel.x * 0.2f, Math.Min(f.Vel.y, 2f));
                    Cue(f.Pos, "", "ring", f.Id, 1.1f, 0.18f);
                }
                else
                {
                    V2 desired = delta.Normal * LuminaryConfig.DashSpeed;
                    desired.y = Rules.Clamp(desired.y, -8f, 10f);
                    f.Vel = V2.Lerp(f.Vel, desired, Math.Min(1f, 18f * Rules.Dt));
                }
            }

            // Strict stage safety clamp during dash so character never disappears off-screen
            float safeLeft = Arena.Left + 1.4f, safeRight = Arena.Right - 1.4f;
            if (f.Pos.x <= safeLeft && f.Vel.x < 0) { f.Pos.x = safeLeft; f.Vel.x = 0; f.LuminaryDashUntil = 0; }
            if (f.Pos.x >= safeRight && f.Vel.x > 0) { f.Pos.x = safeRight; f.Vel.x = 0; f.LuminaryDashUntil = 0; }
        }

        // 3. Dash Basic Attack + Mel-Style Homing Radiance Shards Combo
        void ExecuteLuminaryBasic(Fighter f)
        {
            Fighter target = AcquireLuminaryTarget(f);
            StartLuminaryDash(f, target);

            V2 aim = target != null && Alive(target) ? (target.Pos - f.Pos).Normal : new V2(f.Facing, 0);
            if (Math.Abs(aim.x) > 0.05f)
                f.Facing = aim.x >= 0 ? 1 : -1;

            // Primary light spear-bolt
            var mainBolt = Shoot(f, f.Def.Damage, 25f, 0.26f, LuminaryConfig.ShardTurnRate * 0.6f, false, "luminary-bolt", direction: aim);
            mainBolt.TargetId = target != null ? target.Id : -1;
            mainBolt.Hit.Physical = false;
            mainBolt.Expires = Time + LuminaryConfig.ShardLifetime;
            mainBolt.MaxRange = 28f;
            Cue(f.Pos, "", "slash", f.Id, 2.0f, 0.18f, f.Pos + aim * 1.9f);

            // Consume stored Radiance Shards (up to 9) and fire homing shard volley
            int shards = f.LuminaryShards;
            if (shards > 0)
            {
                f.LuminaryShards = 0;
                int targetId = target != null ? target.Id : -1;
                Cue(f.Pos, "광휘 연사 x" + shards, "ring", f.Id, 1.5f, 0.35f);
                for (int i = 0; i < shards; i++)
                {
                    int idx = i;
                    int total = shards;
                    Later(f, 0.03f * (idx + 1), () => SpawnRadianceShard(f, idx, total, targetId), false);
                }
            }
        }

        void SpawnRadianceShard(Fighter f, int index, int total, int preferredTargetId)
        {
            Fighter target = (preferredTargetId >= 0 && preferredTargetId < Players.Length && Alive(Players[preferredTargetId]) && Opponents(f.Id, preferredTargetId))
                ? Players[preferredTargetId]
                : AcquireLuminaryTarget(f);

            V2 baseDir = target != null && Alive(target) ? (target.Pos - f.Pos).Normal : new V2(f.Facing, 0);
            float spread = (index - (total - 1) * 0.5f) * 0.16f;
            V2 launchDir = new V2(baseDir.x, baseDir.y + spread).Normal;
            V2 spawnOffset = new V2(-f.Facing * 0.35f, 0.55f + (index % 3) * 0.28f);

            var shard = Shoot(f, 15f, LuminaryConfig.ShardSpeed, 0.2f, LuminaryConfig.ShardTurnRate, false, "luminary-shard", direction: launchDir);
            shard.Pos = f.Pos + spawnOffset;
            shard.TargetId = target != null ? target.Id : -1;
            shard.Expires = Time + LuminaryConfig.ShardLifetime;
            shard.MaxRange = 32f;
            shard.Hit.Physical = false;
            shard.Hit.Knock = 2.5f;
            shard.Hit.FixedGauge = 1.5f;
            shard.Style = index;
        }

        // 4. Q Skill: Radiance Pulse (+3 Shards, Max 9)
        void CastLuminaryPulse(Fighter f)
        {
            int before = f.LuminaryShards;
            f.LuminaryShards = Math.Min(LuminaryConfig.MaxShards, f.LuminaryShards + LuminaryConfig.ShardsPerCharge);
            int gained = f.LuminaryShards - before;
            var pulseHit = MakeHit(f, 40f, 5f);
            pulseHit.Physical = false;
            pulseHit.Tag = "luminary-pulse";
            Zone(f, f.Pos, 2.6f, pulseHit, 0.2f);
            Cue(f.Pos, "광휘 충전 +" + gained + " (" + f.LuminaryShards + "/9)", "luminary-sigil", f.Id, 2.6f, 0.45f);
        }

        // 5. Overwhelm Stack System (6-Stack Auto Burst & Spacebar Manual Detonation)
        void ApplyLuminaryOverwhelm(Fighter source, Fighter victim)
        {
            if (victim.Dead || victim.HP <= 0)
                return;
            int stacks = Math.Min(LuminaryConfig.OverwhelmTriggerStacks, victim.OverwhelmStacks[source.Id] + 1);
            victim.OverwhelmStacks[source.Id] = stacks;

            if (stacks >= LuminaryConfig.OverwhelmTriggerStacks)
            {
                // Clear immediately before applying burst so explosion and manual consume never double-trigger
                victim.OverwhelmStacks[source.Id] = 0;
                var burst = new Hit
                {
                    Owner = source.Id,
                    Damage = 95f * source.CopyScale,
                    TrueDamage = true,
                    Physical = false,
                    Knock = 8f,
                    Control = CC.Stun,
                    Duration = 0.45f,
                    NoLeech = true,
                    NoGauge = true,
                    Tag = "luminary-overwhelm-burst"
                };
                ApplyHit(victim, burst);
                Cue(victim.Pos, "압도 6중첩 폭발!", "luminary-sigil", source.Id, 2.4f, 0.5f);
            }
            else
            {
                Cue(victim.Pos + new V2(0, 0.8f), "압도 " + stacks + "/6", "ring", source.Id, 0.85f, 0.22f);
            }
        }

        void CastLuminaryOverwhelmDetonate(Fighter f)
        {
            int totalConsumed = 0;
            foreach (var foe in Players)
            {
                if (!Opponents(f.Id, foe.Id) || !Alive(foe) || !DuelAllows(f.Id, foe.Id))
                    continue;
                int stacks = foe.OverwhelmStacks[f.Id];
                if (stacks <= 0)
                    continue;
                // Consume stacks first to prevent any duplicate damage with 6-stack auto burst
                foe.OverwhelmStacks[f.Id] = 0;
                totalConsumed += stacks;

                var detonateHit = MakeHit(f, 28f * stacks, 4f + stacks, false, stacks >= 4 ? CC.Stun : CC.Slow, stacks >= 4 ? 0.4f : 1.4f);
                detonateHit.Slow = 0.65f;
                detonateHit.Physical = false;
                detonateHit.Tag = "luminary-detonate";
                ApplyHit(foe, detonateHit);
                Cue(foe.Pos, "압도 해방 x" + stacks, "luminary-sigil", f.Id, 2.0f, 0.45f);
            }

            if (totalConsumed > 0)
            {
                Heal(f, totalConsumed * 12f);
            }
            else
            {
                // Fallback wave when no enemy has stacks yet: applies 2 Overwhelm stacks in front
                Fighter target = AcquireLuminaryTarget(f);
                var waveHit = MakeHit(f, 48f, 6f);
                waveHit.Physical = false;
                waveHit.Tag = "luminary-wave";
                Zone(f, f.Pos + new V2(f.Facing * 2.2f, 0), 2.3f, waveHit, 0.22f);
                if (target != null && Alive(target) && V2.Distance(f.Pos, target.Pos) <= 4.8f)
                {
                    ApplyLuminaryOverwhelm(f, target);
                    ApplyLuminaryOverwhelm(f, target);
                }
                Cue(f.Pos + new V2(f.Facing * 2.2f, 0), "광휘 파장 (+2중첩)", "luminary-sigil", f.Id, 2.2f, 0.38f);
            }
        }

        // 6. Ultimate: Solar Sanctuary (Refills all 9 Shards + Solar Judgment Barrage)
        void CastLuminaryUltimate(Fighter f)
        {
            f.UltimateCastingUntil = Time + 0.5f;
            f.LuminaryShards = LuminaryConfig.MaxShards;
            Fighter target = AcquireLuminaryTarget(f);
            V2 center = target != null ? target.Pos : f.Pos + new V2(f.Facing * 4f, 0);
            Cue(center, "SOLAR SANCTUARY · SHARDS 9/9", "luminary-sigil", f.Id, 4.0f, 0.75f);

            var fieldHit = MakeHit(f, 64f / Rules.UltimateDamageScale, 4f, true);
            fieldHit.Physical = false;
            fieldHit.Stun = 0;
            fieldHit.Tag = "luminary-bolt";
            Zone(f, center, 3.8f, fieldHit, 2.0f, 0.2f, 5, 0.4f);
        }
    }
}
