using System;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public float UltimateCooldown(Fighter f) { return 0; }
        public bool ImmuneControl(Fighter f) { return Fortune(f)==2||f.IronGuardUntil>Time; }
        bool PhysicalJob(Job job)
        {
            return job!=Job.GravityMage&&job!=Job.Thunder&&job!=Job.Magician&&job!=Job.TimeMurder&&
                job!=Job.Cross&&job!=Job.FrostReaper&&job!=Job.VoidWalker&&job!=Job.Alchemist&&job!=Job.Maestro&&job!=Job.Prism&&job!=Job.Poltergeist&&job!=Job.Luminary;
        }
        public float ColdAttackRate(Fighter f)
        {
            if(ImmuneControl(f))return f.PrismBuffUntil>Time?1.25f:1;
            float mult=(f.PrismBuffUntil>Time?1.25f:1)*(f.GorgonSlowUntil>Time?.6f:1);
            foreach(var e in Effects)
                if(!e.Dead&&e.Expires>Time&&e.Tag=="cold-veil"&&Opponents(e.Owner,f.Id)&&DuelAllows(e.Owner,f.Id)&&V2.Distance(f.Pos,e.Pos)<=4)return .7f*mult;
            return mult;
        }
        public float TotalShield(Fighter f) { return f.IronPassiveShield+(f.IronShieldUntil>Time?f.IronActiveShield:0); }
        float AbsorbShields(Fighter f,float damage)
        {
            float remaining=damage;
            if(f.IronShieldUntil>Time){float take=Math.Min(f.IronActiveShield,remaining);f.IronActiveShield-=take;remaining-=take;}
            float passive=Math.Min(f.IronPassiveShield,remaining);f.IronPassiveShield-=passive;remaining-=passive;
            if(damage>remaining)Cue(f.Pos,"ABSORB "+Math.Round(damage-remaining),"shield",f.Id,1,.4f);
            return remaining;
        }
        void AdvanceMaestroBeat(Fighter f,int slot)
        {
            bool inWindow=f.MaestroBeatEnd>0&&Time>=f.MaestroBeatStart&&Time<=f.MaestroBeatEnd;
            bool alternated=slot==0||slot!=f.MaestroLastSlot;
            if(f.MaestroFinaleUntil>Time)
            {
                f.MaestroTempo=4;f.MaestroTempoUntil=f.MaestroFinaleUntil;
            }
            else if(inWindow&&alternated)
            {
                f.MaestroTempo=Math.Min(4,f.MaestroTempo+1);f.MaestroTempoUntil=Time+3.2f;
                f.QAt=Math.Max(Time,f.QAt-1.2f);f.EAt=Math.Max(Time,f.EAt-1.2f);
                Cue(f.Pos,"정박 · TEMPO x"+f.MaestroTempo,"ring",f.Id,1.3f,.35f);
            }
            else if(f.MaestroBeatEnd>0&&Time<f.MaestroBeatStart)
            {
                f.MaestroTempo=Math.Max(0,f.MaestroTempo-1);
                Cue(f.Pos,"엇박 (조기 입력)","text",f.Id,1,.35f);
            }
            else if(!alternated)
            {
                f.MaestroTempo=Math.Max(0,f.MaestroTempo-1);
                Cue(f.Pos,"불협화음","text",f.Id,1,.35f);
            }
            else if(f.MaestroTempo==0)
            {
                f.MaestroTempo=1;f.MaestroTempoUntil=Time+2.2f;
            }
            if(slot>0)f.MaestroLastSlot=slot;
            f.MaestroBeatStart=Time+.52f;f.MaestroBeatEnd=Time+.76f;
        }
        void AddReactorHeat(Fighter f,float amount)
        {
            if(f.ReactorUltUntil>Time){f.ReactorHeat=80;return;}
            f.ReactorHeat=Rules.Clamp(f.ReactorHeat+amount,0,100);
            if(f.ReactorHeat>=100)
            {
                f.ReactorHeat=35;f.SilenceUntil=Math.Max(f.SilenceUntil,Time+1f);
                var h=MakeHit(f,65,8);h.Physical=false;h.Tag="reactor-overheat";
                Zone(f,f.Pos,2.5f,h,.25f);Cue(f.Pos,"과열 방출!","burst",f.Id,2.5f,.5f);
            }
        }
        void DeepFreeze(Fighter f)
        {
            Cue(f.Pos,"DEEP FREEZE","ice-field",f.Id,6,.8f);
            foreach(var target in Players)
            {
                if(!Opponents(f.Id,target.Id)||!Alive(target)||V2.Distance(f.Pos,target.Pos)>6)continue;
                var hit=StatusHit(f,CC.Stun,3,true);hit.Tag="frost-ultimate";ApplyHit(target,hit);
            }
        }
        void SpawnShadow(Fighter f)
        {
            Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Zone,Pos=f.Pos-new V2(f.Facing,0),
                Radius=.5f,Expires=Time+3,NextTick=Time+.2f,Tag="shadow-clone"});
            Cue(f.Pos,"SHADOW DOUBLE","smoke",f.Id,1.5f,.5f);
        }
        void StartShadowAssault(Fighter f)
        {
            Fighter target=Enemy(f);target.ShadowMarks[f.Id]=0;target.ShadowCycles[f.Id]=0;
            V2 locked=target.Pos;float delay=.3f+Roll()*.3f;
            f.CastUntil=f.UltimateCastingUntil=Time+delay+1.25f;
            f.ShadowAssaultUntil=Time+delay+1.2f;
            foreach(var e in Effects)if(e.Owner==f.Id&&e.Tag=="shadow-clone")e.Dead=true;
            Cue(locked,"SHADOW ASSAULT","warning",f.Id,2,delay);
            Later(f,delay,()=>Teleport(f,locked-new V2(f.Facing*1.2f,0),100));
            for(int i=0;i<5;i++)Later(f,delay+i*.25f,()=>{
                var h=MakeHit(f,76/Rules.UltimateDamageScale,1,true);h.Stun=0;h.Critical=false;h.Tag="shadow-ultimate";
                Zone(f,locked,2,h,.1f);Cue(locked-new V2(1.8f,0),"","slash",f.Id,2,.18f,locked+new V2(1.8f,0));});
        }
        void VoidStep(Fighter f)
        {
            bool second=f.VoidRecastAvailable&&f.VoidRecastUntil>Time;
            if(!Teleport(f,f.Pos+new V2(f.Facing*5,0),6))return;
            if(second){f.VoidRecastAvailable=false;f.VoidRecastUntil=0;}
            else{f.QAt=Time+8;f.VoidRecastAvailable=true;f.VoidRecastUntil=Time+3;}
            Cue(f.Pos,"RIFT STEP","portal",f.Id,1,.5f);
        }
        void StartVoidDuel(Fighter f)
        {
            DuelOwner=f.Id;DuelTarget=Enemy(f).Id;DuelUntil=Time+6;DuelCenter=(f.Pos+Enemy(f).Pos)*.5f;
            DuelCenter.x=Rules.Clamp(DuelCenter.x,Arena.Left+6,Arena.Right-6);
            DuelCenter.y=Rules.Clamp(DuelCenter.y,Arena.Bottom+6,Arena.Top-6);
            foreach(var p in Players)ClampDuel(p);
            // Existing summons/fields are external intervention; new ones cannot act inside either.
            foreach(var e in Effects)if((e.Owner==DuelOwner||e.Owner==DuelTarget)&&(e.Tag=="shadow-clone"||e.Tag=="cold-veil"||e.Shape==Shape.Turret))e.Dead=true;
            Cue(DuelCenter,"SEALED DUEL","portal",f.Id,6,.8f);
        }
        void ClampDuel(Fighter f)
        {
            if(DuelUntil<=Time||(f.Id!=DuelOwner&&f.Id!=DuelTarget))return;
            V2 delta=f.Pos-DuelCenter;
            if(delta.Length>6){f.Pos=DuelCenter+delta.Normal*6;f.Vel=new V2();}
        }
        bool ExpansionEffect(Effect e,Fighter owner,Fighter target)
        {
            if(e.Tag=="cold-veil")
            {foreach(var ally in Players)if(Alive(ally)&&ally.TeamId==owner.TeamId&&DuelAllows(owner.Id,ally.Id)&&V2.Distance(ally.Pos,e.Pos)<=4)Heal(ally,ally.MaxHP*.04f*Rules.Dt);return true;}
            if(e.Tag!="shadow-clone")return false;
            if(DuelUntil>Time&&(owner.Id==DuelOwner||owner.Id==DuelTarget))return true;
            V2 goal=target.Pos+new V2(owner.Facing*1.3f,0);
            e.Pos=V2.Lerp(e.Pos,goal,Math.Min(1,10*Rules.Dt));
            if(Time>=e.NextTick&&V2.Distance(e.Pos,target.Pos)<=2)
            {
                e.NextTick=Time+.8f;Hit h=MakeHit(owner,38*.7f,2);h.Tag="shadow-clone-hit";h.Summoned=true;h.NoGauge=true;
                ApplyHit(target,h);Cue(e.Pos,"","slash",owner.Id,1.4f,.2f,target.Pos);
            }
            return true;
        }
        void UpdateExpansion(Fighter f)
        {
            if(f.FrostThawAt>0&&Time>=f.FrostThawAt)
            {
                int owner=f.FrostThawOwner;f.FrostThawAt=0;f.FrostThawOwner=-1;f.FreezeUntil=0;
                if(owner>=0)ApplyHit(f,new Hit{Owner=owner,Damage=f.HP*.25f,TrueDamage=true,Ultimate=true,Knock=0,Stun=0,NoLeech=true,Tag="frost-thaw"});
                Cue(f.Pos,"THAW","ice-break",owner<0?f.Id:owner,2,.6f);
            }
            if(f.BloodGuardUntil>0&&Time>=f.BloodGuardUntil)
            {f.BloodGuardUntil=0;Heal(f,f.BloodStoredDamage*.5f);f.BloodStoredDamage=0;}
            if(f.MaxHPBonus>0&&f.BloodUltUntil<=Time){f.MaxHPBonus=0;f.HP=Math.Min(f.HP,f.MaxHP);}
            if(f.IronShieldUntil<=Time)f.IronActiveShield=0;
            if(f.VoidPhaseUntil>0&&f.VoidPhaseUntil<=Time)
            {
                f.VoidPhaseUntil=0;
                foreach(var wall in Effects)
                    if(!wall.Dead&&wall.Shape==Shape.Wall&&wall.Expires>Time&&Math.Abs(f.Pos.y-wall.Pos.y)<wall.Height/2+f.HalfHeight(Time)&&Math.Abs(f.Pos.x-wall.Pos.x)<wall.Width/2+f.Radius(Time))
                        f.Pos.x=wall.Pos.x+(f.Pos.x<wall.Pos.x?-1:1)*(wall.Width/2+f.Radius(Time)+.05f);
                ClampDuel(f);
            }
            if(f.VoidRecastUntil<=Time)f.VoidRecastAvailable=false;
            if(f.MaestroFinaleUntil>Time){f.MaestroTempo=4;f.MaestroTempoUntil=f.MaestroFinaleUntil;}
            else if(f.MaestroTempo>0&&(Time>f.MaestroTempoUntil||(f.MaestroBeatEnd>0&&Time>f.MaestroBeatEnd+.65f))){f.MaestroTempo=0;f.MaestroBeatStart=f.MaestroBeatEnd=0;}
            if(f.PendulumOrbitUntil>Time)
            {
                f.ArmorUntil=Math.Max(f.ArmorUntil,Time+.1f);
                if(Time>=f.NextPendulumTick){f.NextPendulumTick=Time+.25f;var h=MakeHit(f,22,5,true);h.Stun=0;Zone(f,f.Pos,2.1f,h,.15f);Cue(f.Pos,"","ring",f.Id,2f,.2f);}
            }
            if(f.TetherUntil>Time&&f.TetherTarget>=0&&f.TetherTarget<Players.Length)
            {
                Fighter foe=Players[f.TetherTarget];
                if(!Alive(foe)||!DuelAllows(f.Id,foe.Id)){f.TetherUntil=0;f.TetherTarget=-1;}
                else if(V2.Distance(f.Pos,foe.Pos)>5.5f&&!IsFixedDummy(foe)&&!ImmuneControl(foe)&&foe.UltimateCastingUntil<=Time)
                {foe.Vel+=(f.Pos-foe.Pos).Normal*(34*Rules.Dt);foe.RecoilUntil=Time+.05f;}
            }
            else if(f.TetherUntil<=Time)f.TetherTarget=-1;
            UpdateLuminaryDash(f);
            if(f.ReactorUltUntil>Time)f.ReactorHeat=80;
            else if(f.ReactorHeat>0&&f.AttackVisualUntil<=Time)f.ReactorHeat=Math.Max(0,f.ReactorHeat-4*Rules.Dt);
        }
        void TryBloodRevive(Fighter f)
        {
            if(HasPower(f,Job.Lancer)&&!f.LancerGutsUsed&&f.HP<=0&&!f.Dead)
            {
                f.LancerGutsUsed=true;f.HP=350;f.InvulnUntil=Math.Max(f.InvulnUntil,Time+1.2f);
                f.LancerFuryUntil=Time+4f;f.QAt=f.EAt=Time;f.HasSpear=true;
                f.StunUntil=f.RootUntil=f.SlowUntil=f.SilenceUntil=f.SkillLockUntil=0;
                Cue(f.Pos,"전투속행 (BATTLE CONTINUATION)","rebirth",f.Id,2.8f,.9f);return;
            }
            if(!f.BloodReviveArmed||f.BloodReviveUsed||!IsKO(f))return;
            f.BloodReviveUsed=true;f.BloodReviveArmed=false;
            f.HP=f.MaxHP*.4f;f.Dead=false;f.Vel=new V2();f.Pos=SpawnPosition(f.Id);ClampDuel(f);
            f.StunUntil=f.RootUntil=f.SlowUntil=f.SilenceUntil=f.SkillLockUntil=f.DoomAt=f.FrostThawAt=f.FreezeUntil=0;
            f.BurnTicks=0;f.InvulnUntil=Time+.7f;f.CastUntil=f.UltimateCastingUntil=0;f.InterruptVersion++;
            scheduled.RemoveAll(s=>s.Owner==f.Id);Effects.RemoveAll(e=>e.Owner==f.Id);
            Cue(f.Pos,"REBIRTH 50%","rebirth",f.Id,3,1);
        }
        void ExpansionOnHit(Fighter source,Fighter victim,Hit h,float actual)
        {
            if(h.Tag=="frost-basic")
            {if(++victim.FrostHits[source.Id]%3==0)Control(victim,CC.Slow,2,.8f);}
            if(h.Tag=="alchemist-basic")
            {
                if(++victim.AlchemyStacks[source.Id]>=3)
                {
                    victim.AlchemyStacks[source.Id]=0;
                    Control(victim,CC.Slow,1.5f,.75f);
                    ApplyHit(victim,new Hit{Owner=source.Id,Damage=45*source.CopyScale,TrueDamage=true,Knock=4,Stun=0,NoLeech=true,NoGauge=true,Tag="alchemy-burst"});
                    Cue(victim.Pos,"연금 폭발","burst",source.Id,1.6f,.4f);
                }
            }
            if(h.Tag=="ronin-draw")Heal(source,35);
            if(h.Tag=="tether-hook"&&!ImmuneControl(victim)){source.TetherTarget=victim.Id;source.TetherUntil=Time+5;Control(victim,CC.Slow,2.5f,.75f);}
            if(h.Tag=="poltergeist-basic")
            {
                source.PoltergeistDebris=Math.Min(3,source.PoltergeistDebris+1);
                if(!victim.Grounded||victim.Vel.y>1)ApplyHit(victim,new Hit{Owner=source.Id,Damage=16*source.CopyScale,TrueDamage=true,Knock=2,Stun=0,NoLeech=true,NoGauge=true,Tag="poltergeist-air"});
            }
            if(h.Tag=="rider-basic"&&victim.FreezeUntil>Time)
                ApplyHit(victim,new Hit{Owner=source.Id,Damage=22*source.CopyScale,TrueDamage=true,Knock=3,Stun=0,NoLeech=true,NoGauge=true,Tag="rider-shatter"});
            if(h.Tag=="rider-chain"&&!IsFixedDummy(victim)&&!ImmuneControl(victim)&&victim.RootUntil<=Time)
            {victim.Vel=new V2(-source.Facing*14,6);victim.RecoilUntil=Time+.2f;}
            if(h.Tag=="lancer-basic"||h.Tag=="lancer-rune"||h.Tag=="spear")
            {
                victim.LancerCurseUntil=Time+2.5f;
                if(h.Tag=="lancer-basic"&&!source.HasSpear)
                    ApplyHit(victim,new Hit{Owner=source.Id,Damage=18*source.CopyScale,TrueDamage=true,Knock=3,Stun=0,NoLeech=true,NoGauge=true,Tag="lancer-rune-burst"});
            }
            if(h.Tag=="archer-basic"&&++source.ArcherShots%3==0)
            {
                ApplyHit(victim,new Hit{Owner=source.Id,Damage=30*source.CopyScale,TrueDamage=true,Knock=6,Stun=0,NoLeech=true,NoGauge=true,Tag="archer-headshot"});
                Cue(victim.Pos,"HEADSHOT +30","burst",source.Id,1.4f,.35f);
            }
            if(h.Tag=="emp-mine")Control(victim,CC.SkillLock,1.5f);
            if(h.Tag=="luminary-bolt"||h.Tag=="luminary-shard"||h.Tag=="luminary-pulse")
                ApplyLuminaryOverwhelm(source,victim);

            if(h.Tag=="blood-basic"||(h.Tag=="mimic-basic"&&(source.BloodBoostUntil>Time||source.BloodUltUntil>Time)))Heal(source,actual*(source.BloodBoostUntil>Time?1:.35f)*(source.BloodUltUntil>Time?2:1));
            if(h.Tag=="iron-basic")source.IronPassiveShield=Math.Min(500,source.IronPassiveShield+5);
            if(h.Tag=="shadow-basic"||h.Tag=="shadow-clone-hit")
            {
                victim.ShadowMarks[source.Id]=Math.Min(3,victim.ShadowMarks[source.Id]+1);
                if(++victim.ShadowCycles[source.Id]%3==0)
                    ApplyHit(victim,new Hit{Owner=source.Id,Damage=victim.MaxHP*.05f,TrueDamage=true,Knock=0,Stun=0,NoLeech=true,NoGauge=true,Tag="shadow-mark-burst"});
            }
        }
    }
}
