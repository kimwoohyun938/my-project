using System;
namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public readonly double[] EventDamage=new double[2];
        public int EventTicks,BossLivesRemaining;
        public float EventElapsed {get{return EventTicks*Rules.Dt;}}
        public float EventRemaining {get{return Math.Max(0,Options.EventDuration-EventElapsed);}}
        public double EventDps(int player){return EventElapsed>0?EventDamage[player]/EventElapsed:0;}
        float nextBossPattern;int bossPattern;
        void ResetSpecialMode()
        {
            EventTicks=0;Array.Clear(EventDamage,0,2);BossLivesRemaining=Options.BossLives;nextBossPattern=Time+2.7f;bossPattern=0;
            if(Mode==BattleMode.BossRaid)
            {
                var boss=Players[2];boss.IsBoss=true;boss.BossHealthBonus=12000-boss.Def.HP;boss.HP=boss.MaxHP;
                boss.Pos=SpawnPosition(2);boss.BodyScale=1.8f;
            }
        }
        Controls BossMovement(Fighter boss)
        {
            if(!Alive(boss))return new Controls();var target=Enemy(boss);float dx=target.Pos.x-boss.Pos.x;
            int desired=dx>=0?1:-1;
            if(!InHitstop(boss)&&boss.CastUntil<=Time&&boss.StunUntil<=Time&&Math.Abs(dx)>.05f)boss.Facing=desired;
            return new Controls(Math.Abs(dx)>2.7f?Math.Sign(dx):0,target.Pos.y>boss.Pos.y+2&&boss.Grounded,Math.Abs(dx)<3);
        }
        void UpdateBossPattern()
        {
            if(Mode!=BattleMode.BossRaid||Phase!=Phase.Fight)return;var boss=Players[2];
            if(!Alive(boss)||boss.CastUntil>Time||boss.StunUntil>Time||Time<nextBossPattern)return;
            int pattern=bossPattern++%3;bool rage=boss.HP<boss.MaxHP*.5f;nextBossPattern=Time+(rage?2.4f:3.3f);
            int slot=pattern==0?1:pattern==1?2:3;
            RunAction(boss,slot,()=>
            {
                boss.CastUntil=Time+.7f;
                Cue(boss.Pos,pattern==0?"보스: 돌진 준비":pattern==1?"보스: 지진파 준비":"보스: 잡기 준비","warning",boss.Id,pattern==1?2.6f:3,.7f);
                Cue(boss.Pos+new V2(0,3),pattern==0?"돌진 예고":pattern==1?"지진파 예고":"잡기 예고","text",boss.Id,1.5f,.7f);
                Later(boss,.7f,()=>{if(pattern==0)Skill1(boss);else if(pattern==1)Skill2(boss);else Ultimate(boss);},true);
            });
        }
        void ResolveBossKO()
        {
            if(Players[2].HP<=0){Finish(0);Announcement="보스 격파 · 협동팀 승리";return;}
            for(int id=0;id<2;id++)
            {
                var f=Players[id];if(f.Dead||!IsKO(f)||TimingGrace(f))continue;
                BossLivesRemaining--;f.Dead=true;ClearLife(id);f.RespawnAt=Time+.65f;Cue(f.Pos,"KO","burst",2,2,.7f);
            }
            if(BossLivesRemaining<=0){Finish(2);Announcement="도전 종료 · 팀 목숨 소진";}
        }
        void UpdateEvent()
        {
            if(Mode!=BattleMode.DpsEvent||Phase!=Phase.Fight)return;
            foreach(var f in Players)
            {
                f.HP=f.MaxHP;f.Dead=false;
                if(f.Id<2){f.Pos.x=Rules.Clamp(f.Pos.x,f.Id==0?Arena.Left+1:1,f.Id==0?-1:Arena.Right-1);ClampArena(f);}
            }
            EventTicks++;
            int limit=(int)Math.Ceiling(Options.EventDuration/Rules.Dt-.0001f);
            if(EventTicks>=limit)
            {
                Winner=Math.Abs(EventDamage[0]-EventDamage[1])<.0001?-1:EventDamage[0]>EventDamage[1]?0:1;
                Phase=Phase.Finished;Announcement=Winner<0?"이벤트 대전 · 무승부":"자리 "+(Winner+1)+" · 피해량 승리";
                Effects.Clear();scheduled.Clear();
            }
        }
    }
}
