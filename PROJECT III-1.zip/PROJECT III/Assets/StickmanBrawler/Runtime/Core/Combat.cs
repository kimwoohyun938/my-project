using System;
using System.Collections.Generic;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        Hit StatusHit(Fighter f,CC cc,float duration,bool ultimate=false,float slow=.65f)
        { return new Hit{CastId=activeCast,Slot=ActiveSlot,Owner=f.Id,Damage=0,Knock=0,Stun=0,Control=cc,Duration=duration,Ultimate=ultimate,Slow=slow}; }
        Hit MakeHit(Fighter f,float damage,float knock=5,bool ult=false,CC cc=CC.None,float duration=0)
        {
            float multiplier=f.IsBoss?(f.HP<f.MaxHP*.5f?1.8f:1.5f):1,critChance=0;
            float criticalMultiplier=1.6f;
            if(HasPower(f,Job.Gambler))
            {
                int rank=Fortune(f);critChance=.2223f+(f.CoinCritUntil>Time?.2777f:0)+(rank==1?.7777f:rank==2?7.77f:0);
                multiplier*=rank==1?1.47f:rank==2?8.77f:1;
                criticalMultiplier+=(rank==1?.27f:rank==2?7.77f:0)+Math.Max(0,critChance-1)*.1f;
            }
            if(ult&&damage<9999)multiplier*=Rules.UltimateDamageScale;
            multiplier*=f.CopyScale;
            if(f.MirrorUltUntil>Time)multiplier*=1.4f;
            if(f.LancerFuryUntil>Time)multiplier*=1.3f;
            if(f.AlchemistUltUntil>Time)multiplier*=1.35f;
            if(HasPower(f,Job.Maestro)&&f.MaestroTempo>0&&f.MaestroTempoUntil>Time)multiplier*=1+.18f*f.MaestroTempo;
            if(HasPower(f,Job.Pendulum))multiplier*=1+Rules.Clamp(f.Vel.Length/20f,0,.8f);
            if(HasPower(f,Job.Reactor)&&((f.ReactorHeat>=50&&f.ReactorHeat<=85)||f.ReactorUltUntil>Time))multiplier*=1.35f;
            if(DuelUntil>Time&&DuelOwner==f.Id)multiplier*=1.5f;
            if(HasPower(f,Job.Berserker))multiplier*=1+.5f*(1-f.HP/f.Def.HP);
            if(HasPower(f,Job.BladeMaster))critChance=.3f;
            if(HasPower(f,Job.Thunder)&&f.BuffUntil>Time)critChance+=.2f;
            if(HasPower(f,Job.Dystopia))critChance=.5f*(1-f.HP/f.Def.HP);
            if(f.CritUntil>Time)critChance=.7f;
            if(f.FormUntil>Time)
            {
                if(HasPower(f,Job.Vertebrate))multiplier*=1.5f;
                if(HasPower(f,Job.Director))multiplier*=1.5f;
                if(HasPower(f,Job.Assassin))critChance=1;
            }
            bool crit=!ult && ((!HasPower(f,Job.ShadowClone)&&f.NextCrit) || Roll()<critChance);
            if(!ult&&!HasPower(f,Job.ShadowClone)){f.NextCrit=false;f.StealthUntil=0;}
            return new Hit{CastId=activeCast,Slot=ActiveSlot,Owner=f.Id,Physical=PhysicalJob(f.PowerJob),Damage=damage*multiplier,Knock=knock,Ultimate=ult,Critical=crit,CriticalMultiplier=criticalMultiplier,Control=cc,Duration=duration,Direction=new V2(f.Facing,.35f)};
        }
        public bool ApplyHit(Fighter victim,Hit h)
        {
            if(Mode==BattleMode.DpsEvent&&victim.Id<2)return false;
            if(victim.Dead || victim.HP<=0||CastCanceled(h.CastId)||!object.ReferenceEquals(victim,Players[victim.Id])||(h.Tag!="undying-debt"&&!Opponents(h.Owner,victim.Id))||!DuelAllows(h.Owner,victim.Id))return false;
            if(!h.Ultimate&&InsideCyberZone(victim)){Cue(victim.Pos,"접근 차단","text",victim.Id);return false;}
            V2 timingBefore=victim.Pos;float timingStun=victim.StunUntil,timingRoot=victim.RootUntil,timingSilence=victim.SilenceUntil;
            // Cast protection has priority over even guaranteed-hit skills.
            if(h.CurrentPercent>0||h.MaximumPercent>0)
            {h=h.Copy();h.Damage=victim.HP*h.CurrentPercent+victim.MaxHP*h.MaximumPercent;h.CurrentPercent=h.MaximumPercent=0;h.Critical=false;}
            if(victim.UltimateCastingUntil>Time&&!h.BypassInvulnerability)return false;
            if(ImmuneControl(victim)&&h.Damage<=0&&h.Control!=CC.None)return false;
            if(DuelUntil>Time&&h.Summoned&&(victim.Id==DuelOwner||victim.Id==DuelTarget))return false;
            if(victim.VoidPhaseUntil>Time&&h.Physical&&!h.TrueDamage&&!h.Unavoidable&&!h.BypassInvulnerability)return false;
            if(victim.StealthUntil>Time&&!h.Unavoidable&&!h.BypassInvulnerability)return false;
            if(!h.Unavoidable&&!h.BypassInvulnerability&&(victim.InvulnUntil>Time || (HasPower(victim,Job.Guardian)&&victim.FormUntil>Time)))return false;
            Fighter source=Players[h.Owner];
            if(!h.Unavoidable&&!h.BypassInvulnerability&&victim.DodgeUntil>Time&&!h.Ultimate){Cue(victim.Pos,"EVADE","text",victim.Id);return false;}
            if(!h.Unavoidable&&!h.BypassOneHitShield&&victim.ShieldUntil>Time){victim.ShieldUntil=0;Cue(victim.Pos,"BLOCK","ring",victim.Id,1.4f);return false;}
            if(!h.Unavoidable&&!h.Reflected && (victim.ParryUntil>Time || (HasPower(victim,Job.Reflector)&&victim.ReflectUntil>Time)))
            {
                float returned=h.Damage*(h.Critical?h.CriticalMultiplier:1);
                if(victim.ParryUntil>Time){victim.QAt=Time;}
                if(victim.NativeJob==Job.Reflector)victim.Gauge=Math.Min(100,victim.Gauge+5+DealtGauge(source,h,returned));
                if(returned>0||h.Control!=CC.None){var reflected=h.Copy();reflected.Owner=victim.Id;reflected.Damage=returned;reflected.Critical=false;reflected.Reflected=reflected.NoGauge=reflected.NoLeech=true;reflected.Direction=new V2(-h.Direction.x,h.Direction.y);ApplyHit(source,reflected);}
                Cue(victim.Pos,"REFLECT","ring",victim.Id,1.5f);return false;
            }
            if(h.Slot==0&&Players[h.Owner].TimingCritReady&&Players[h.Owner].TimingCritTick<CombatTick)
            {h=h.Copy();h.Critical=Roll()<.7f;Players[h.Owner].TimingCritReady=false;}
            bool guarded=IsGuarding(victim)&&!h.TrueDamage&&h.Tag!="doom"&&h.Tag!="burn"&&h.Tag!="yi-burn"&&h.Tag!="undying-debt"&&h.Tag!="iron-share";
            float reduction=Fortune(victim)==1?.93f:Fortune(victim)==2?.23f:1;
            if(HasPower(victim,Job.Knight) && victim.BuffUntil>Time)reduction*=.5f;
            if(HasPower(victim,Job.Master) && Roll()<.1f)reduction*=.5f;
            bool markedStrike=HasPower(source,Job.QinShi)&&victim.QinMarkOwner==source.Id&&!h.Reflected;
            float markMultiplier=markedStrike?1.4f:1;
            float damage=h.Damage*(h.Critical?h.CriticalMultiplier:1)*reduction*markMultiplier;
            if(HasPower(victim,Job.IronWall))damage/=1+(victim.IronGuardUntil>Time?.4f:0)+(victim.IronUltUntil>Time?1:0);
            if(victim.CounterBonusUntil>Time&&h.Critical)damage*=1.8f;
            if(HasPower(victim,Job.King))damage*=1.35f;
            if(victim.LancerCurseUntil>Time)damage*=1.2f;
            if(victim.UndyingGuardUntil>Time)damage*=.4f;
            if(victim.UndyingHealGuardUntil>Time)damage*=.5f;
            if(victim.MirrorUltUntil>Time)damage*=.7f;
            if(victim.DisguiseUntil>Time)damage*=.8f;
            if(victim.ReactorGuardUntil>Time)damage*=.7f;
            if(h.TrueDamage)damage=h.Damage;
            if(guarded)damage*=.5f;
            if(victim.IsBoss)damage=Math.Min(damage,600);
            if(victim.IronUltUntil>Time&&h.Tag!="iron-share"&&damage>0)
            {
                var allies=new List<Fighter>();foreach(var ally in Players)if(ally.Id!=victim.Id&&ally.TeamId==victim.TeamId&&Alive(ally)&&DuelAllows(victim.Id,ally.Id)&&V2.Distance(ally.Pos,victim.Pos)<=5)allies.Add(ally);
                if(allies.Count>0){float shared=damage*.5f/allies.Count;damage*=.5f;foreach(var ally in allies){var transfer=h.Copy();transfer.Damage=shared;transfer.TrueDamage=true;transfer.Critical=false;transfer.Knock=transfer.Stun=0;transfer.Control=CC.None;transfer.Reflected=transfer.NoGauge=transfer.NoLeech=true;transfer.Tag="iron-share";ApplyHit(ally,transfer);}}
            }
            if(!h.TrueDamage&&victim.BloodGuardUntil>Time){victim.BloodStoredDamage+=damage*.5f;damage*=.5f;}
            if(damage<=0&&h.Control!=CC.None){Control(victim,h.Control,h.Duration,h.Slow,h.Ultimate,h.CastId,h.Tag=="frost-spear"||h.Tag=="frost-ultimate",h.Tag=="frost-ultimate"?h.Owner:-1);if(h.Tag=="cyber-throttle"){if(!ImmuneControl(victim))victim.CyberSlowUntil=Time+(HasPower(victim,Job.Knight)&&victim.BuffUntil>Time?2:4);source.CyberHasteUntil=Time+4;}return true;}
            float beforeShield=Math.Max(0,damage);damage=h.Tag=="undying-debt"?beforeShield:AbsorbShields(victim,beforeShield);float absorbed=beforeShield-damage;
            if(victim.UndyingUntil>Time)victim.UndyingDebt+=Math.Max(0,damage);
            float floor=victim.UndyingUntil>Time?1:0;
            float actual=IsFixedDummy(victim)?Math.Max(0,damage):Math.Min(Math.Max(0,victim.HP-floor),Math.Max(0,damage));victim.HP=IsFixedDummy(victim)?victim.MaxHP:Math.Max(floor,victim.HP-actual);
            if(Mode==BattleMode.DpsEvent&&h.Owner<2&&victim.Id==h.Owner+2)EventDamage[h.Owner]+=actual;
            if(actual>0&&h.Owner!=victim.Id){victim.LastAttacker=h.Owner;victim.LastAttackedAt=Time;}
            if(actual<=0&&absorbed<=0&&!(victim.UndyingUntil>Time&&damage>0))return false;
            if(actual>0&&h.Tag!="burn"&&h.Tag!="yi-burn"&&h.Tag!="undying-debt"&&h.Tag!="time-rapid")StartHitstop(victim);
            victim.KnockbackBonus+=h.KnockbackGain*markMultiplier*(guarded?.4f:1);
            if(markedStrike&&!h.PreserveQinMark)victim.QinMarkOwner=-1;
            if(Enemy(victim).DoomAt>Time)victim.SigilDamageTaken+=actual;
            victim.LastHitAt=Time;victim.HitFlashUntil=Time+.1f;victim.StealthUntil=0;
            LastDamage=actual;HitSerial++;
            if(Time-labComboAt>2){ComboHits=0;ComboDamage=0;}ComboHits++;ComboDamage+=actual;labComboAt=Time;
            if(h.Tag!="time-rapid"||Time>=source.NextRapidVisual){
            Cue(victim.Pos+new V2(0,1.3f),(h.Critical?"CRIT ":"")+Math.Round(actual),"damage",h.Owner,h.Critical?1.2f:1,.65f);
            Cue(victim.Pos,"","burst",h.Owner,.8f,.18f);
            }
            if(!h.NoGauge)
            {
                source.Gauge=Math.Min(100,source.Gauge+DealtGauge(source,h,actual));
                victim.Gauge=Math.Min(100,victim.Gauge+ReceivedGauge(victim,actual));
            }
            float knock=h.Knock*victim.KnockbackScale*reduction*(h.Projectile?.65f:1);
            if(guarded){knock*=.4f;Cue(victim.Pos,"가드","ring",victim.Id,1.1f,.2f);}
            if(HasPower(victim,Job.Guardian))knock*=.65f;
            if(knock>0 && !ImmuneControl(victim) && Fortune(victim)==0 && victim.ArmorUntil<=Time && victim.RootUntil<=Time)
            {
                V2 dir=h.Direction.Length<.01f?new V2(victim.Pos.x>=source.Pos.x?1:-1,.4f):h.Direction;
                victim.Vel=dir.Normal*knock;victim.RecoilUntil=Time+(h.Projectile?.08f:.22f)+(InHitstop(victim)?Math.Max(0,victim.HitstopEndTick-CombatTick)*Rules.Dt:0);
            }
            if(h.Hitstun>0&&!ImmuneControl(victim)&&victim.ArmorUntil<=Time&&victim.UltimateCastingUntil<=Time)
                QueueReaction(victim,h.Hitstun*reduction,h.CastId,true);
            if(h.Control!=CC.None)Control(victim,h.Control,h.Duration,h.Slow,h.Ultimate,h.CastId,h.Tag=="frost-spear"||h.Tag=="frost-ultimate",h.Tag=="frost-ultimate"?h.Owner:-1);
            if(HasPower(victim,Job.Guardian)&&victim.ReflectUntil>Time&&!h.Reflected)
            { Hit reflected=h.Copy();reflected.Owner=victim.Id;reflected.Damage=actual*.4f;reflected.Critical=false;reflected.Knock=0;reflected.Stun=0;reflected.Control=CC.None;reflected.Reflected=reflected.NoGauge=reflected.NoLeech=true;ApplyHit(source,reflected); }
            if(!h.NoLeech)
            {
                TimingCyberOnHit(source,victim,h,actual,timingBefore,timingStun,timingRoot,timingSilence);
                ExpansionOnHit(source,victim,h,actual);V2OnHit(source,victim,h,actual);
                if(HasPower(source,Job.Gambler)&&h.Critical)Heal(source,110);
                if(h.Tag=="fortune-coin"){Heal(source,60);source.CoinCritUntil=Time+4;}
                if(h.Tag=="dino-mark"){victim.DinoMarkOwner=source.Id;victim.DinoMarkUntil=Time+8;}
                if(h.Tag=="gambler-basic"&&Fortune(source)>0&&Roll()<(Fortune(source)==1?.37f:.77f))
                    Later(source,.07f,()=>Melee(source,65,1.8f,6,false,CC.None,0,"gambler-extra"));
                if(h.Tag=="yi-fire"){victim.BurnOwner=source.Id;victim.BurnTicks=5;victim.NextBurnAt=Time+1;}
                if(h.Tag=="yang-sword")
                {
                    Control(victim,CC.Stun,.2f,castId:h.CastId,stack:true);
                }
                if(h.Tag=="nisemono-blade")victim.EmbeddedBlades[source.Id]++;
                if(h.Tag=="caladbolg")victim.EmbeddedCaladbolgs[source.Id]++;
                if(h.Tag=="depth-basic")Heal(source,24);
                if(h.Tag=="combo"){source.Combo=Time<source.ComboUntil?source.Combo+1:1;source.ComboUntil=Time+2;}
                if(h.Tag=="mark"||h.Tag=="depth-mark")victim.MarkUntil=Time+5;
                if(h.Tag=="hook" && source.RootUntil<=Time){source.Vel=(victim.Pos-source.Pos).Normal*22;source.RecoilUntil=Time+.28f;}
                if(h.Tag=="swap" && !ImmuneControl(victim)&&victim.RootUntil<=Time&&source.RootUntil<=Time){V2 old=source.Pos;if(Teleport(source,victim.Pos,30))Teleport(victim,old,30);}
                if(h.Tag=="grab" && victim.RootUntil<=Time){Control(victim,CC.Root,.45f);victim.RootPos=source.Pos+new V2(source.Facing*.8f,0);}
            }
            return true;
        }
        public void Control(Fighter f,CC type,float duration,float slow=.65f,bool ultimate=false,int castId=-1,bool freeze=false,int thawOwner=-1,bool stack=false)
        {
            if(Mode==BattleMode.DpsEvent&&f.Id<2)return;
            if(f.IsBoss)duration*=.35f;
            if(IsFixedDummy(f)){if(type!=CC.Silence&&type!=CC.SkillLock)return;}
            if((!ultimate&&InsideCyberZone(f))||f.HP<=0||ImmuneControl(f)||f.StealthUntil>Time||f.UltimateCastingUntil>Time||f.InvulnUntil>Time||(f.DodgeUntil>Time&&!ultimate)||(HasPower(f,Job.Guardian)&&f.FormUntil>Time))return;
            if(HasPower(f,Job.Knight)&&f.BuffUntil>Time){duration*=.5f;slow=1-(1-slow)*.5f;}
            if(type==CC.Stun||type==CC.Root)
            {
                if(f.ArmorUntil>Time && type==CC.Stun)return;
                // Original abilities retain their full explicit control durations.
            }
            if(duration<=0)return;
            switch(type)
            {
                case CC.Stun:QueueReaction(f,duration,castId<0?activeCast:castId,false,freeze,thawOwner,stack);break;
                case CC.Root:if(f.RootUntil<=Time)f.RootPos=f.Pos;f.RootUntil=Math.Max(f.RootUntil,Time+duration);f.Vel=new V2();break;
                case CC.Silence:f.SilenceUntil=Math.Max(f.SilenceUntil,Time+duration);break;
                case CC.SkillLock:f.SkillLockUntil=Math.Max(f.SkillLockUntil,Time+duration);break;
                case CC.Slow:f.SlowFactor=f.SlowUntil>Time?Math.Min(f.SlowFactor,slow):slow;f.SlowUntil=Math.Max(f.SlowUntil,Time+duration);break;
            }
        }
        void Melee(Fighter f,float damage,float reach=1.8f,float knock=6,bool ult=false,CC cc=CC.None,float duration=0,string tag="")
        {
            f.AttackVisualUntil=Time+.2f;
            float scale=f.Scale(Time);if(HasPower(f,Job.Assassin)&&f.FormUntil>Time)scale*=1.4f;
            if(HasPower(f,Job.Director)&&f.FormUntil>Time)scale*=2;
            if(HasPower(f,Job.Cross)&&f.Buff2Until>Time)scale*=2;
            V2 center=f.Pos+new V2(f.Facing*reach*scale*.55f,0);
            var h=MakeHit(f,damage,knock,ult,cc,duration);h.Tag=tag;
            if(tag=="qin-basic")h.KnockbackGain=.11f;
            if(tag=="shadow-basic"&&f.NextCrit){h.Critical=true;h.CriticalMultiplier=1.5f;f.NextCrit=false;}
            if(tag=="shadow-basic")f.StealthUntil=0;
            Zone(f,center,reach*scale*.6f,h,.16f);
            Cue(f.Pos,"","slash",f.Id,reach*scale,.2f,center+new V2(f.Facing*.5f,.4f));
        }
        Effect Zone(Fighter f,V2 pos,float radius,Hit hit,float duration=.2f,float delay=0,int maxHits=1,float interval=.2f)
        {
            var e=new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Zone,Pos=pos,Radius=radius,Hit=hit,Expires=Time+delay+duration,ActiveAt=Time+delay,NextTick=Time+delay,MaxHits=maxHits,Interval=interval,Ultimate=hit.Ultimate};Effects.Add(e);return e;
        }
        Effect Shoot(Fighter f,float damage,float speed=18,float radius=.23f,float home=0,bool ult=false,string tag="",CC cc=CC.None,float duration=0,V2? direction=null)
        {
            V2 dir=direction??new V2(f.Facing,0);var h=MakeHit(f,damage,6,ult,cc,duration);h.Projectile=true;h.Tag=tag;h.Direction=dir;
            var e=new Effect{CastId=activeCast,TargetId=Enemy(f).Id,Owner=f.Id,Shape=Shape.Shot,Pos=f.Pos+new V2(f.Facing*.7f,.1f),Vel=dir.Normal*speed,Radius=radius,Home=home,Hit=h,Expires=Time+3,ActiveAt=Time,NextTick=Time,Ultimate=ult,Tag=tag};Effects.Add(e);return e;
        }
        void Beam(Fighter f,float damage,float length=22,bool ult=true,float knock=6)
        {
            var h=MakeHit(f,damage,knock,ult);h.Physical=false;h.Direction=new V2(f.Facing,.2f);
            var e=new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Beam,Pos=f.Pos,Width=length,Height=1.5f,Vel=new V2(f.Facing,0),Hit=h,Expires=Time+.14f,ActiveAt=Time,NextTick=Time,Ultimate=ult};Effects.Add(e);
        }
        void UpdateEffects()
        {
            // Snapshot allows detonations and turrets to create effects without list invalidation.
            // Process every distinct impact. Hit flash/stun never grants implicit i-frames.
            // Per-effect Hits prevents duplicate contact; KO is resolved after this whole pass.
            var snapshot=Effects.ToArray();
            foreach(var e in snapshot)
            {
                if(e.Dead||CastCanceled(e.CastId)){e.Dead=true;continue;}
                using(CastScope(e.CastId))
                {
                Fighter owner=Players[e.Owner],target=EffectTarget(e);
                if(e.Tag=="ubw-sword"&&owner.RealmUntil<=Time){e.Dead=true;continue;}
                if(e.Tag=="gae-bolg"||e.Tag=="yi-soldier")
                {
                    if(!Alive(target)){e.Dead=true;continue;}
                    // A launched Gae Bolg resolves once within 0.65 seconds,
                    // even if the target teleports or activates a defensive skill.
                    V2 old=e.Pos;e.Vel=(target.Pos-e.Pos).Normal*(e.Tag=="gae-bolg"?55:16);e.Pos=e.Pos+e.Vel*Rules.Dt;
                    if(Time>=e.GuaranteedAt||SegmentBox(old,e.Pos,target.Pos,target.Radius(Time)+e.Radius,target.HalfHeight(Time)+e.Radius))
                    {
                        e.Pos=target.Pos;ApplyHit(target,e.Hit);
                        if(e.Tag=="gae-bolg")
                        {
                            target.LancerCurseUntil=Time+4f;
                            var thorn=MakeHit(owner,120/Rules.UltimateDamageScale,12,true,CC.Stun,.9f);thorn.Unavoidable=true;
                            Zone(owner,target.Pos,3.5f,thorn,.25f);
                        }
                        Cue(target.Pos,e.Tag=="gae-bolg"?"CRIMSON THORN":"SOLDIER","burst",e.Owner,e.Tag=="gae-bolg"?3.5f:2,.55f);e.Dead=true;
                    }
                    continue;
                }
                if(e.Expires<=Time)
                {
                    if(e.Tag=="grenade"||e.Tag=="gravity-orb"||e.Tag=="acid-flask")Explode(e);
                    if(e.Shape==Shape.Spear)RecoverSpear(owner,false);
                    e.Dead=true;continue;
                }
                if(e.Shape==Shape.Wall||e.Shape==Shape.Spear)continue;
                if(e.Tag=="cyber-zone")continue;
                if(SummonerEffect(e,owner,target))continue;
                if(ExpansionEffect(e,owner,target))continue;
                if(e.FollowOwner)e.Pos=owner.Pos;
                if(e.Tag=="tempest"&&Time>=e.ActiveAt)e.Radius=Math.Min(4,1.5f+Time-e.ActiveAt);
                if(e.Tag=="rain"&&Alive(target))e.Pos=V2.Lerp(e.Pos,target.Pos,Math.Min(1,4.5f*Rules.Dt));
                if(e.Tag=="drag" && e.Hits>0 && target.RootUntil>Time){target.RootPos=owner.Pos+new V2(owner.Facing*.8f,0);target.Pos=target.RootPos;}
                if(e.Shape==Shape.Turret)
                {
                    bool boosted=e.BoostUntil>Time;
                    if(Time>=e.NextTick && V2.Distance(e.Pos,target.Pos)<=12 && ClearPath(e.Pos,target.Pos))
                    { e.NextTick=Time+(boosted?.38f:.65f);Effect shot=Shoot(owner,boosted?42:32,20,.22f,0,e.Ultimate,"sentry",CC.Slow,.8f,direction:(target.Pos-e.Pos).Normal);shot.Pos=e.Pos;shot.Hit.Slow=.8f;shot.Hit.Summoned=true; }
                    continue;
                }
                if(e.Shape==Shape.Wind)
                {
                    foreach(var p in Players)if(Alive(p)&&DuelAllows(e.Owner,p.Id)&&!IsFixedDummy(p)&&V2.Distance(p.Pos,e.Pos)<e.Radius&&p.RootUntil<=Time&&!ImmuneControl(p)&&Fortune(p)==0&&p.UltimateCastingUntil<=Time){p.Vel.y=Math.Max(p.Vel.y,9);p.RecoilUntil=Time+.05f;}
                }
                if(Time<e.ActiveAt)continue;
                if(e.Pull>0)foreach(var pulled in Players)
                    if(Opponents(e.Owner,pulled.Id)&&Alive(pulled)&&DuelAllows(e.Owner,pulled.Id)&&!IsFixedDummy(pulled)&&!ImmuneControl(pulled)&&V2.Distance(pulled.Pos,e.Pos)<=e.Radius&&pulled.RootUntil<=Time&&Fortune(pulled)==0&&pulled.InvulnUntil<=Time&&pulled.UltimateCastingUntil<=Time)
                    {pulled.Vel+=(e.Pos-pulled.Pos).Normal*(e.Pull*Rules.Dt);pulled.RecoilUntil=Time+.05f;}
                V2 previousPosition=e.Pos;
                if(e.Shape==Shape.Shot)
                {
                    V2 old=e.Pos;
                    if(target.MirrorFadeUntil>Time&&e.Home>0)e.Home=0;
                    if(e.Home>0)e.Vel=V2.Lerp(e.Vel,(target.Pos-e.Pos).Normal*e.Vel.Length,e.Home*Rules.Dt);
                    e.Vel.y-=e.Gravity*Rules.Dt;e.Pos=e.Pos+e.Vel*Rules.Dt;e.Travel+=V2.Distance(old,e.Pos);
                    if(e.Travel>=e.MaxRange){if(e.Tag=="gravity-orb"||e.Tag=="grenade"||e.Tag=="acid-flask")Explode(e);e.Dead=true;continue;}
                    bool blocked=false;
                    foreach(var wall in snapshot)
                        if(e.Tag!="pterosaur"&&!wall.Dead&&wall.Shape==Shape.Wall&&SegmentBox(old,e.Pos,wall.Pos,wall.Width/2+e.Radius,wall.Height/2+e.Radius))blocked=true;
                    if(!e.Pierce)foreach(var p in Arena.Platforms)if(SegmentBox(old,e.Pos,new V2(p.X,p.Y-.12f),p.Width/2,.12f+e.Radius))blocked=true;
                    if(blocked)
                    { if(e.Tag=="spear"){e.Shape=Shape.Spear;e.Expires=Time+7;e.Vel=new V2();}else{if(e.Tag=="grenade"||e.Tag=="gravity-orb"||e.Tag=="acid-flask")Explode(e);e.Dead=true;}continue; }
                }
                // Attack effects can destroy an enemy sentry; owner attacks do not.
                if(e.Hit!=null && e.Shape!=Shape.Trap)
                {
                    foreach(var turret in snapshot)
                    {
                        if(turret.Dead||(turret.Shape!=Shape.Turret&&turret.Shape!=Shape.Summon)||!Opponents(turret.Owner,e.Owner)||!DuelAllows(turret.Owner,e.Owner))continue;
                        bool turretHit=e.Shape==Shape.Beam?SegmentBox(e.Pos,e.Pos+e.Vel*e.Width,turret.Pos,.6f,.6f):V2.Distance(e.Pos,turret.Pos)<e.Radius+.6f;
                        if(e.Tag=="arena-beam"&&(turret.Pos.x-e.Pos.x)*e.Vel.x<0)turretHit=false;
                        if(turretHit&&Time>=e.NextTick&&(!e.SummonNextHit.ContainsKey(turret)||Time>=e.SummonNextHit[turret])){e.SummonNextHit[turret]=e.MaxHits>1?Time+e.Interval:float.MaxValue;if(turret.Shape==Shape.Summon)HurtSummon(turret,e.Hit);else{turret.Health-=e.Hit.Damage;if(turret.Health<=0){turret.Dead=true;Cue(turret.Pos,"SENTRY DOWN","burst",e.Owner,1);}}if(e.Shape==Shape.Shot){e.Dead=true;break;}}
                    }
                }
                // Move each projectile once, then resolve contacts against every enemy.
                // Zones/beams track per-victim hit limits; one target cannot consume another's hit.
                foreach(var hitTarget in Players)
                {
                    if(e.Dead||e.Hit==null)break;
                    if(!Opponents(e.Owner,hitTarget.Id)||!Alive(hitTarget)||!DuelAllows(e.Owner,hitTarget.Id))continue;
                    if(e.PlayerHits[hitTarget.Id]>=e.MaxHits||Time<e.PlayerNextHit[hitTarget.Id])continue;
                    bool contact;
                    if(e.Shape==Shape.Shot)
                    {
                        if(hitTarget.GuardUntil>Time&&(e.Pos.x-hitTarget.Pos.x)*hitTarget.Facing>=0&&Rules.SegmentCircle(previousPosition,e.Pos,hitTarget.Pos,1.7f))
                        {e.Dead=true;if(e.Tag=="spear")RecoverSpear(owner,false);Cue(e.Pos,"INTERCEPT","burst",hitTarget.Id,1);break;}
                        contact=SegmentBox(previousPosition,e.Pos,hitTarget.Pos,hitTarget.Radius(Time)+e.Radius,hitTarget.HalfHeight(Time)+e.Radius);
                    }
                    else if(e.Shape==Shape.Beam)
                    {contact=SegmentBox(e.Pos,e.Pos+e.Vel*e.Width,hitTarget.Pos,hitTarget.Radius(Time),hitTarget.HalfHeight(Time)+e.Height/2);if(e.Tag=="arena-beam")contact=contact&&(hitTarget.Pos.x-e.Pos.x)*e.Vel.x>=0;}
                    else contact=V2.Distance(e.Pos,hitTarget.Pos)<=e.Radius+hitTarget.Radius(Time);
                    if(!contact)continue;
                    if(e.Tag=="thunder-orb")Cue(hitTarget.Pos+new V2(0,5),"","bolt",e.Owner,1.1f,.18f,hitTarget.Pos);
                    if(e.Tag=="grenade"||e.Tag=="gravity-orb"||e.Tag=="acid-flask"){Explode(e);e.Dead=true;break;}
                    Hit hit=e.Hit.Copy();
                    if(e.Shape==Shape.Zone||e.Shape==Shape.Wind||e.Shape==Shape.Trap)hit.Direction=new V2(hitTarget.Pos.x>=e.Pos.x?1:-1,.5f);
                    bool landed=ApplyHit(hitTarget,hit);e.Hits++;e.PlayerHits[hitTarget.Id]++;e.PlayerNextHit[hitTarget.Id]=(e.PlayerHits[hitTarget.Id]==1?Time:e.PlayerNextHit[hitTarget.Id])+e.Interval;
                    if(landed&&e.Tag=="shuriken")
                    {int key=e.Group*4+hitTarget.Id,n;shurikenHits.TryGetValue(key,out n);shurikenHits[key]=++n;if(n==3){Teleport(owner,hitTarget.Pos-new V2(hitTarget.Facing*1.2f,0),9);owner.Gauge=Math.Min(100,owner.Gauge+20);}}
                    if(e.Tag=="spear"){e.Shape=Shape.Spear;e.Pos=hitTarget.Pos;e.Vel=new V2();e.Expires=Time+7;break;}
                    else if(e.Shape==Shape.Shot||e.Shape==Shape.Trap){e.Dead=true;break;}
                }
                }
            }
            Effects.RemoveAll(e=>e.Dead);
        }
        void Explode(Effect e)
        {
            if(e.Tag=="acid-flask")
            {
                var acid=MakeHit(Players[e.Owner],14,1,false,CC.Slow,1);acid.Slow=.75f;acid.Stun=0;acid.Physical=false;acid.Tag="acid-pool";
                var pool=Zone(Players[e.Owner],new V2(e.Pos.x,FloorAt(e.Pos.x,e.Pos.y)+.2f),2.2f,acid,3.5f,0,7,.5f);pool.Tag="acid-pool";
                Cue(pool.Pos,"산성 지대","burst",e.Owner,2.2f,.45f);return;
            }
            var h=e.Hit.Copy();h.Knock=e.Tag=="grenade"?12:5;
            Zone(Players[e.Owner],e.Pos,e.Tag=="grenade"?2.4f:1.2f,h);
            if(e.Tag=="grenade")
            {
                var burn=MakeHit(Players[e.Owner],10,1,false,CC.Slow,.8f);burn.Slow=.7f;burn.Stun=0;burn.Physical=false;
                Zone(Players[e.Owner],new V2(e.Pos.x,FloorAt(e.Pos.x,e.Pos.y)+.2f),2.2f,burn,3f,0,6,.5f).Tag="acid-pool";
            }
            Cue(e.Pos,"","burst",e.Owner,2.4f,.35f);
        }
    }
}
