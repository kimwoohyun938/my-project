using System;

namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        float UltimateCastDuration(Job job)
        {
            // Includes the final hit of a sequence, but not a persistent realm/buff.
            switch(job)
            {
                case Job.Knight:return 1.72f;
                case Job.Thunder:return 1.65f;
                case Job.King:return 1.8f;
                case Job.Berserker:return 1.4f;
                case Job.Samurai:return 1.3f;
                case Job.BladeMaster:return 1.4f;
                case Job.Lancer:return .3f;
                case Job.Hassan:return .45f;
                case Job.Nisemono:return 3+Rules.Dt*2;
                case Job.Gambler:return .65f;
                case Job.Grappler:return 1;
                case Job.Werewolf:return .8f;
                case Job.Depth:return .55f;
                case Job.Archer:return .5f;
                case Job.GravityMage:return .5f;
                case Job.Engineer:return .6f;
                case Job.Zephyr:return .45f;
                default:return 0;
            }
        }
        void Charge(Fighter f,float time,float length=12)
        { f.CastUntil=Time+time;Cue(f.Pos,"","warning-line",f.Id,length,time,f.Pos+new V2(f.Facing*length,0)); }
        void Flurry(Fighter f,int count,float each,float finisher,float delay,float interval,float reach,bool armored)
        {
            Charge(f,delay,reach);f.CastUntil=Time+delay+count*interval+.15f;
            if(armored)f.ArmorUntil=Time+delay+count*interval+.2f;
            for(int i=0;i<count;i++)Later(f,delay+i*interval,()=>Melee(f,each,reach,1,true),false);
            Later(f,delay+count*interval,()=>Melee(f,finisher,reach+.3f,13,true),false);
        }
        void Ultimate(Fighter f)
        { RunAction(f,3,()=>UltimateBody(f)); }
        void UltimateBody(Fighter f)
        {
            Fighter enemy=Enemy(f);int beamFacing=f.Facing;if(f.Job!=Job.Mimic){f.LastUltimateJob=(int)f.Job;f.LastUltimateTime=Time;}Announce(f,Roster.Get(f.Job).RName,true);
            f.UltimateCastingUntil=Time+UltimateCastDuration(f.Job);
            switch(f.Job)
            {
                case Job.LTiming:TimingUltimate(f);break;
                case Job.Cybercrud:CyberUltimate(f);break;
                case Job.Alchemist:
                {
                    f.UltimateCastingUntil=Time+.45f;Charge(f,.4f,8);
                    Later(f,.4f,()=>{Heal(f,180);f.QAt=f.EAt=Time;f.AlchemistUltUntil=Time+6;
                        var h=MakeHit(f,200,12,true);h.Physical=false;h.Tag="philosopher-stone";
                        Zone(f,Enemy(f).Pos,3.5f,h,.3f);Cue(Enemy(f).Pos,"현자의 돌","burst",f.Id,3.5f,.6f);},false);break;
                }
                case Job.Ronin:
                {
                    f.UltimateCastingUntil=Time+1.15f;f.RoninDrawReady=true;
                    Teleport(f,enemy.Pos-new V2(enemy.Facing*1.2f,0),10);f.Facing=enemy.Pos.x>=f.Pos.x?1:-1;
                    Flurry(f,6,25,150,.35f,.09f,2.8f,true);
                    Later(f,.35f+6*.09f,()=>{var stunHit=StatusHit(f,CC.Stun,.6f,true);Zone(f,f.Pos,3f,stunHit,.2f);Cue(f.Pos,"만월","ring",f.Id,3f,.5f);},false);break;
                }
                case Job.Maestro:
                {
                    int chords=Math.Max(0,f.MaestroTempo);
                    f.UltimateCastingUntil=Time+.45f+chords*.1f;
                    f.MaestroFinaleUntil=Time+5;f.MaestroTempo=4;f.MaestroTempoUntil=Time+5;
                    var baseHit=MakeHit(f,150/Rules.UltimateDamageScale,10,true,chords>0?CC.Stun:CC.None,chords*.25f);baseHit.Physical=false;
                    Zone(f,enemy.Pos,3.6f,baseHit,.3f);Cue(enemy.Pos,"FINALE x"+chords,"burst",f.Id,3.6f,.6f);
                    for(int i=0;i<chords;i++){int n=i;Later(f,.12f*(n+1),()=>{var note=MakeHit(f,45/Rules.UltimateDamageScale,3,true);note.Physical=false;note.Stun=0;Zone(f,Enemy(f).Pos,3.2f,note,.18f);},false);}
                    break;
                }
                case Job.Pendulum:
                {
                    f.UltimateCastingUntil=Time+.4f;f.PendulumOrbitUntil=Time+5;f.NextPendulumTick=Time+.2f;
                    Dash(f,26,4,.35f);
                    Later(f,1.2f,()=>{var fin=MakeHit(f,150,14,true);Zone(f,f.Pos,2.8f,fin,.25f);Cue(f.Pos,"궤도 파쇄","burst",f.Id,2.8f,.5f);},false);
                    break;
                }
                case Job.Tether:
                {
                    f.UltimateCastingUntil=Time+.4f;f.TetherTarget=enemy.Id;f.TetherUntil=Time+5;
                    ApplyHit(enemy,StatusHit(f,CC.Root,1.2f,true));
                    var h=MakeHit(f,40/Rules.UltimateDamageScale,3,true);h.Stun=0;
                    Zone(f,enemy.Pos,4f,h,3.2f,0,8,.4f);Cue(enemy.Pos,"처형의 감옥","portal",f.Id,4f,.7f);
                    break;
                }
                case Job.Prism:
                {
                    f.UltimateCastingUntil=Time+.65f;f.PrismBuffUntil=Time+4;
                    if(FindSummon(f,"prism-lens")==null)Summon(f,"prism-lens",f.Pos+new V2(f.Facing*2.8f,1.8f),8,120);
                    for(int i=0;i<4;i++)
                    {
                        int n=i;
                        Later(f,.12f*n,()=>{
                            Beam(f,70/Rules.UltimateDamageScale,18,true,5);
                            var lens=FindSummon(f,"prism-lens");
                            if(lens!=null){V2 dir=(Enemy(f).Pos-lens.Pos).Normal;var lh=MakeHit(f,40/Rules.UltimateDamageScale,4,true);lh.Physical=false;lh.Direction=dir;Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Beam,Pos=lens.Pos,Vel=dir,Width=18,Height=1.2f,Hit=lh,Expires=Time+.14f,ActiveAt=Time,NextTick=Time,Ultimate=true});}
                        },false);
                    }
                    break;
                }
                case Job.Reactor:
                {
                    f.UltimateCastingUntil=Time+.45f;f.ReactorUltUntil=Time+6;f.ReactorHeat=80;
                    Charge(f,.35f,6);
                    Later(f,.35f,()=>{var h=MakeHit(f,280/Rules.UltimateDamageScale,14,true);h.Physical=false;Zone(f,f.Pos+new V2(f.Facing*2.2f,0),3.4f,h,.3f);Cue(f.Pos+new V2(f.Facing*2.2f,0),"MELTDOWN","burst",f.Id,3.4f,.6f);},false);
                    break;
                }
                case Job.Poltergeist:
                {
                    f.UltimateCastingUntil=Time+.4f;f.PoltergeistDebris=3;f.PoltergeistStormUntil=Time+3.5f;
                    var h=MakeHit(f,28,4,true);h.Physical=false;h.Stun=0;
                    var storm=Zone(f,enemy.Pos,4f,h,3.5f,0,10,.35f);storm.Shape=Shape.Wind;storm.Tag="tempest";
                    Cue(enemy.Pos,"염동 폭풍","portal",f.Id,4f,.7f);break;
                }
                case Job.Rider:
                {
                    f.UltimateCastingUntil=Time+.55f;f.RiderPegasusUntil=Time+4;
                    Charge(f,.45f,14);Cue(f.Pos,"PEGASUS CHARGE","ring",f.Id,2.5f,.45f);
                    Later(f,.45f,()=>{
                        Dash(f,34,6,.35f);
                        V2 impact=Enemy(f).Pos;
                        var h=MakeHit(f,350,15,true,CC.Stun,.7f);
                        Zone(f,impact,3.4f,h,.3f);Cue(impact,"천마 강림","burst",f.Id,3.4f,.65f);
                    },false);
                    break;
                }
                case Job.Luminary:CastLuminaryUltimate(f);break;
                case Job.Undying:f.UndyingUntil=Time+5;f.UndyingDebt=0;break;
                case Job.MirrorAssassin:MirrorDance(f);break;
                case Job.TwinFang:f.TwinUltUntil=Time+3;break;
                case Job.PhantomLegion:LegionRise(f);break;
                case Job.Mimic:CopyEnemy(f,true);break;
                case Job.Puppeteer:PuppetFinale(f);break;
                case Job.Knight:
                    Charge(f,1.25f,40);for(int i=0;i<3;i++){int n=i;Later(f,1.25f+i*.14f,()=>ArenaBeam(f,n==2?150:125,n==2?14:2,beamFacing),false);}break;
                case Job.Berserker:Flurry(f,8,20,200,.3f,.09f,2.4f,true);break;
                case Job.Samurai:Flurry(f,4,30,150,.5f,.15f,3.5f,false);break;
                case Job.BladeMaster:Flurry(f,12,12,160,.35f,.065f,2.6f,true);break;
                case Job.Lancer:
                {
                    // Once activated this throw cannot be interrupted by an ordinary hit.
                    Charge(f,.22f,16);f.ArmorUntil=Time+.4f;f.LancerFuryUntil=Time+5f;
                    Later(f,.22f,()=>{f.HasSpear=true;foreach(var old in Effects)if(old.Owner==f.Id&&old.Tag=="spear")old.Dead=true;
                        var e=Shoot(f,520/Rules.UltimateDamageScale,60,.28f,0,true,"gae-bolg",CC.Stun,.9f);
                        e.Hit.Unavoidable=true;e.Hit.BypassInvulnerability=true;e.Hit.BypassOneHitShield=true;e.Hit.Knock=16;
                        e.GuaranteedAt=Time+.55f;});break;
                }
                case Job.Archer:
                {
                    V2 target=enemy.Pos;Cue(target,"","warning",f.Id,3.4f,.25f);
                    var rainHit=MakeHit(f,38,3,true,CC.Slow,.6f);rainHit.Slow=.6f;
                    Zone(f,target,3.4f,rainHit,3.2f,.25f,10,.32f).Tag="rain";break;
                }
                case Job.GravityMage:
                {
                    V2 target=enemy.Pos;var e=Zone(f,target,4.5f,MakeHit(f,10,0,true),2,.5f,4,.5f);e.Pull=26;e.Tag="blackhole";
                    Cue(target,"","warning",f.Id,4.5f,.5f);Later(f,2.5f,()=>{Zone(f,target,3,MakeHit(f,150,13,true));Cue(target,"","burst",f.Id,4,.5f);});break;
                }
                case Job.Thunder:
                    f.BuffUntil=Math.Max(f.BuffUntil,Time+4f);Charge(f,1,40);for(int i=0;i<5;i++){int n=i;Later(f,1+i*.12f,()=>ArenaBeam(f,n==4?150:50,n==4?13:1,beamFacing),false);}break;
                case Job.FrostReaper:DeepFreeze(f);break;
                case Job.BloodApostle:
                    f.MaxHPBonus=f.Def.HP*.4f;f.HP=Math.Min(f.MaxHP,f.HP*1.4f);f.BloodUltUntil=Time+5;
                    if(!f.BloodReviveUsed)f.BloodReviveArmed=true;break;
                case Job.ShadowClone:StartShadowAssault(f);break;
                case Job.IronWall:f.IronUltUntil=Time+5;break;
                case Job.VoidWalker:StartVoidDuel(f);break;
                case Job.Gambler:
                    Charge(f,.6f,2);Later(f,.6f,()=>ActivateFortune(f));break;
                case Job.DinoMan:
                {
                    enemy.DinoMarkOwner=-1;enemy.DinoMarkUntil=0;
                    var e=Shoot(f,330/Rules.UltimateDamageScale,22,.6f,8,true,"pterosaur",direction:(enemy.Pos-f.Pos).Normal);
                    e.Pierce=true;e.MaxRange=200;e.Expires=Time+6;e.Hit.Knock=14;break;
                }
                case Job.QinShi:enemy.QinMarkOwner=f.Id;Cue(enemy.Pos,"IMPERIAL SEAL","ring",f.Id,1.5f,.6f);break;
                case Job.YiSunGod:f.FormUntil=Time+12;f.QAt=f.EAt=Time;Cue(f.Pos,"TURTLE SHIP","ring",f.Id,2,.6f);break;
                case Job.Institutor:
                    f.YangSwords+=7;f.YangUltimateUntil=Time+5;
                    if(f.EAt>Time)f.EAt=Time+(f.EAt-Time)*.5f;
                    Cue(f.Pos,"YANG ASCENSION","ring",f.Id,2,.6f);break;
                case Job.Nisemono:
                    Charge(f,3,40);
                    Later(f,3,()=>{f.RealmUntil=Time+15;f.NextRealmVolley=Time;f.RealmVolleyIndex=0;Announce(f,"INFINITE SWORD DOMAIN",true);},false);break;
                case Job.Magician:Inferno(f);break;
                case Job.Assassin:f.FormUntil=Time+4.8f;break;
                case Job.Hassan:HassanArm(f);break;
                case Job.Dystopia:if(ApplyHit(enemy,StatusHit(f,CC.Root,3,true)))enemy.CounterBonusUntil=Time+3;break;
                case Job.TimeMurder:TimeZero(f);break;
                case Job.CardMan:{var e=Shoot(f,170,15,.5f,2.8f,true,"deck");e.Hit.Knock=15;e.Expires=Time+4;e.MaxRange=45;break;}
                case Job.Guardian:
                    f.FormUntil=Time+4.2f;f.ArmorUntil=Time+4.2f;Zone(f,f.Pos,1.8f,MakeHit(f,40,12,true),4.2f,0,7,.6f).FollowOwner=true;break;
                case Job.Reflector:f.ReflectUntil=Time+3;reflectedTotal[f.Id]=0;break;
                case Job.Grappler:
                {
                    if(!InRange(f,2.2f) || enemy.InvulnUntil>Time){f.Gauge=50;Cue(f.Pos,"WHIFF / 50 REFUND","text",f.Id);break;}
                    // Grab is a hit first: shields and reflection can deny it.
                    Hit grab=MakeHit(f,1,0,true,CC.Root,.9f);grab.Stun=0;
                    if(!ApplyHit(enemy,grab)){f.Gauge=50;break;}
                    f.ArmorUntil=Time+1;f.Vel.y=18;f.RecoilUntil=Time+.3f;V2 anchor=enemy.Pos;
                    Later(f,.7f,()=>{if(f.RootUntil<=Time)Teleport(f,anchor+new V2(0,1),15);var h=MakeHit(f,249,15,true);Zone(f,anchor,2,h);Cue(anchor,"","burst",f.Id,3,.5f);});break;
                }
                case Job.King:
                    Charge(f,1.2f,40);
                    for(int i=0;i<3;i++){int n=i;Later(f,1.2f+i*.18f,()=>ArenaBeam(f,n==2?150:125,n==2?15:2,beamFacing),false);}break;
                case Job.Werewolf:WolfHunt(f);break;
                case Job.Vertebrate:f.FormUntil=Time+12;Cue(f.Pos+new V2(0,9),"","bolt",f.Id,2,.4f,f.Pos);break;
                case Job.Director:f.FormUntil=Time+10;break;
                case Job.Depth:
                {
                    V2 target=enemy.Pos;enemy.MarkUntil=0;Charge(f,.3f,5);
                    Later(f,.3f,()=>{if(Teleport(f,target-new V2(enemy.Facing,0),9)){f.Facing=target.x>f.Pos.x?1:-1;Melee(f,260,2.8f,16,true);}},false);break;
                }
                case Job.Cross:
                {
                    int god=DrawGod(f.Id);f.Deity=god;
                    string[] names={"POSEIDON","HADES","GAIA","MICHAEL","IFRIT"};Announce(f,names[god],true);
                    if(god==0){var e=Shoot(f,180,16,1,0,true,"wave");e.Hit.Knock=20;}
                    if(god==1)Melee(f,200,4,12,true);
                    if(god==2){Heal(f,f.Def.HP);Zone(f,enemy.Pos,1.2f,MakeHit(f,350,4,true));}
                    if(god==3)f.FormUntil=Time+10;
                    if(god==4)
                    { V2 pos=new V2((Arena.Left+Arena.Right)/2,(Arena.Bottom+Arena.Top)/2);Hit fire=MakeHit(f,100,0,true);fire.Stun=0;Zone(f,pos,50,fire,10,0,10,1).Tag="fire"; }
                    break;
                }
                case Job.Master:Zone(f,f.Pos,6,MakeHit(f,210,22,true));break;
                case Job.Engineer:
                {
                    f.IronActiveShield=Math.Max(f.IronActiveShield,160);f.IronShieldUntil=Math.Max(f.IronShieldUntil,Time+5);f.ArmorUntil=Math.Max(f.ArmorUntil,Time+3);
                    bool found=false;
                    foreach(var t in Effects)if(!t.Dead&&t.Owner==f.Id&&t.Shape==Shape.Turret){t.Health=280;t.Expires=Math.Max(t.Expires,Time+8);t.BoostUntil=Time+5;found=true;}
                    if(!found)Effects.Add(new Effect{CastId=activeCast,Owner=f.Id,Shape=Shape.Turret,Pos=new V2(f.Pos.x,FloorAt(f.Pos.x,f.Pos.y)+.5f),Radius=.65f,Health=280,Expires=Time+8,BoostUntil=Time+5,NextTick=Time+.2f});
                    var e=Zone(f,f.Pos,4.2f,MakeHit(f,45,6,true),4,.25f,8,.5f);e.FollowOwner=true;e.Tag="array";Cue(f.Pos,"ORBITAL OVERDRIVE","warning",f.Id,4.2f,.35f);break;
                }
                case Job.Zephyr:
                { var e=Zone(f,f.Pos,4,MakeHit(f,48,11,true),3,.45f,5,.55f);e.FollowOwner=true;e.Tag="tempest";Cue(f.Pos,"","warning",f.Id,4,.45f);break; }
            }
        }
    }
}
