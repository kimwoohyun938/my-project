using System;
namespace StickmanBrawler.Core
{
    public sealed partial class World
    {
        public const int InputBufferTicks=6;
        public bool IsGuarding(Fighter f)
        {
            return f.Guarding&&!f.Dead&&f.HP>0&&f.StunUntil<=Time&&f.HitstunUntil<=Time&&f.FreezeUntil<=Time&&f.CastUntil<=Time&&f.UltimateCastingUntil<=Time&&!(HasPower(f,Job.TimeMurder)&&f.BuffUntil>Time&&f.InvulnUntil>Time);
        }
        Controls PrepareControls(Fighter f,Controls c)
        {
            bool previous=IsGuarding(f);
            f.Guarding=c.Guard&&!IsDummy(f)&&!f.IsBoss&&(previous||CanAct(f));
            if(c.Guard)
            {
                Array.Clear(f.BufferedUntil,0,f.BufferedUntil.Length);
                return new Controls{Guard=true};
            }
            if(f.Dead||f.AwaitingPick||f.HP<=0){Array.Clear(f.BufferedUntil,0,f.BufferedUntil.Length);return new Controls();}
            bool[] edges={c.Jump,c.Skill1,c.Skill2,c.Ultimate,c.Attack};
            for(int i=0;i<5;i++)
            {
                // Precision counters use the original input tick, never a buffered press.
                bool counter=(f.NativeJob==Job.LTiming&&(i==1||i==2))||(f.NativeJob==Job.Reflector&&i==1);
                if(i==4&&f.Overclock){f.BufferedUntil[i]=0;continue;}
                if(counter){f.BufferedUntil[i]=0;continue;}
                if(edges[i])f.BufferedUntil[i]=CombatTick+InputBufferTicks-1;
                edges[i]=f.BufferedUntil[i]>0&&f.BufferedUntil[i]>=CombatTick;
            }
            c.Jump=edges[0];c.Skill1=edges[1];c.Skill2=edges[2];c.Ultimate=edges[3];c.Attack=edges[4];return c;
        }
    }
}
