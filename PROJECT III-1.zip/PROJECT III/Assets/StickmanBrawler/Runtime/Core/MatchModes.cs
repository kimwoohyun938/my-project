using System;
using System.Collections.Generic;
namespace StickmanBrawler.Core
{
    public enum BattleMode { Classic,Continuous,TrainingFixed,TrainingRespawn,Teams,FreeForAll,Draft,ThreeWay,BossRaid,DpsEvent }
    public sealed class MatchOptions
    {
        public BattleMode Mode=BattleMode.Classic;
        public int KillLimit=5,DummyId=1;
        public float EventDuration=60;
        public int BossLives=6;
        public bool TeamCoop;
    }
    public sealed partial class World
    {
        public MatchOptions Options {get;private set;}
        public BattleMode Mode {get{return Options.Mode;}}
        public readonly int[] TeamScores=new int[4];
        readonly bool[,] usedJobs=new bool[4,55];
        public bool NeedsSelection {get{foreach(var f in Players)if(f.AwaitingPick)return true;return false;}}
        public World(Job[] jobs,MatchOptions options,int stage=0,int seed=173)
        {
            if(jobs==null||jobs.Length<2||jobs.Length>4)throw new ArgumentException("Two to four fighters required.");
            if(options==null)throw new ArgumentNullException("options");
            int expected=options.Mode==BattleMode.Teams||options.Mode==BattleMode.FreeForAll||options.Mode==BattleMode.DpsEvent?4:options.Mode==BattleMode.ThreeWay||options.Mode==BattleMode.BossRaid?3:2;
            if(jobs.Length!=expected)throw new ArgumentException("Incorrect fighter count for mode.");
            rng=new Random(seed);Arena=Arena.Create(options.Mode==BattleMode.BossRaid||options.Mode==BattleMode.DpsEvent?Math.Max(3,stage):stage);Players=new Fighter[jobs.Length];
            for(int i=0;i<jobs.Length;i++)Players[i]=new Fighter(i,jobs[i]);
            InitializeModes(options);ResetRound();PhaseUntil=2;
        }
        void InitializeModes(MatchOptions options)
        {
            Options=new MatchOptions{Mode=options.Mode,KillLimit=options.KillLimit,DummyId=options.DummyId,TeamCoop=options.TeamCoop,EventDuration=Math.Max(1,options.EventDuration),BossLives=Math.Max(1,options.BossLives)};
            Training=Mode==BattleMode.TrainingFixed||Mode==BattleMode.TrainingRespawn;
            for(int i=0;i<Players.Length;i++)
            {
                Players[i].TeamId=Mode==BattleMode.Teams?(Options.TeamCoop?(i<2?0:1):i%2):i;
                if(Mode==BattleMode.BossRaid)Players[i].TeamId=i==2?1:0;
                usedJobs[i,(int)Players[i].NativeJob]=true;RefillGods(i);
            }
        }
        public bool Opponents(int a,int b){if(Mode==BattleMode.DpsEvent)return (a==0&&b==2)||(a==2&&b==0)||(a==1&&b==3)||(a==3&&b==1);return a>=0&&b>=0&&a<Players.Length&&b<Players.Length&&a!=b&&Players[a].TeamId!=Players[b].TeamId;}
        public bool Alive(Fighter f){return !f.Dead&&!f.AwaitingPick&&f.HP>0;}
        public bool IsDummy(Fighter f){return (Training&&f.Id==Options.DummyId)||(Mode==BattleMode.DpsEvent&&f.Id>=2);}
        public bool IsFixedDummy(Fighter f){return (Mode==BattleMode.TrainingFixed||Mode==BattleMode.DpsEvent)&&IsDummy(f);}
        public V2 SpawnPosition(int id)
        {
            if(Mode==BattleMode.DpsEvent)return new V2(new[]{-11f,5f,-6f,10f}[id],1);
            if(Mode==BattleMode.BossRaid)return new V2(new[]{-10f,-5f,6f}[id],id==2?1.6f:1);
            if(Mode==BattleMode.ThreeWay)return new V2(new[]{-9f,0f,9f}[id],1);
            if(Mode==BattleMode.FreeForAll)return new V2(new[]{-9f,9f,-3f,3f}[id],1);
            if(Mode==BattleMode.Teams){int team=Players[id].TeamId;int rank=0;for(int i=0;i<id;i++)if(Players[i].TeamId==team)rank++;return new V2((team==0?-1:1)*(5+rank*4),1);}
            return new V2(id==0?-6:6,1);
        }
        Fighter SelectEnemy(Fighter f)
        {
            CastTrace trace;
            if(activeCast!=0&&castTraces.TryGetValue(activeCast,out trace)&&trace.Owner==f.Id&&trace.Target>=0&&trace.Target<Players.Length&&Opponents(f.Id,trace.Target))return Players[trace.Target];
            if(f.TargetId>=0&&f.TargetId<Players.Length&&Opponents(f.Id,f.TargetId)&&Alive(Players[f.TargetId]))return Players[f.TargetId];
            Fighter result=null;float distance=float.MaxValue;
            foreach(var p in Players)if(Opponents(f.Id,p.Id)&&Alive(p)&&DuelAllows(f.Id,p.Id))
            {float d=V2.Distance(f.Pos,p.Pos);if(d<distance){distance=d;result=p;}}
            if(result!=null)return result;
            foreach(var p in Players)if(Opponents(f.Id,p.Id))return p;
            return f;
        }
        public void CycleTarget(int id)
        {
            Fighter f=Players[id];int first=Enemy(f).Id;
            for(int offset=1;offset<=Players.Length;offset++){int next=(first+offset)%Players.Length;if(Opponents(id,next)&&Alive(Players[next])){f.TargetId=next;return;}}
        }
        Fighter EffectTarget(Effect e)
        {if(e.TargetId>=0&&e.TargetId<Players.Length)return Players[e.TargetId];if(e.Shape==Shape.Summon||e.Shape==Shape.Turret){int saved=activeCast;activeCast=0;try{return Enemy(Players[e.Owner]);}finally{activeCast=saved;}}return Enemy(Players[e.Owner]);}
        public bool DuelAllows(int a,int b)
        {if(DuelUntil<=Time)return true;bool insideA=a==DuelOwner||a==DuelTarget,insideB=b==DuelOwner||b==DuelTarget;return insideA==insideB;}
        Controls InputAt(Controls[] inputs,int i){return Players[i].Dead||IsDummy(Players[i])||inputs==null||i>=inputs.Length?new Controls():inputs[i];}
        void RestoreFixedDummy()
        {foreach(var f in Players)if(IsFixedDummy(f)){f.HP=f.MaxHP;f.Pos=SpawnPosition(f.Id);f.Vel=new V2();f.Dead=false;}}
        void UpdateRespawns()
        {foreach(var f in Players)if(f.Dead&&!f.AwaitingPick&&f.RespawnAt>0&&Time>=f.RespawnAt)Respawn(f.Id);RestoreFixedDummy();}
        void ClearLife(int id)
        {
            pendingReactions.RemoveAll(p=>p.Target.Id==id);
            scheduled.RemoveAll(s=>s.Owner==id);Effects.RemoveAll(e=>e.Owner==id);
            foreach(var c in castTraces.Values)if(c.Owner==id){c.Canceled=true;c.Undo.Clear();}
            receipts[id]=null;lastCast[id]=lastUltimateCast[id]=0;
            if(DuelOwner==id||DuelTarget==id){DuelUntil=0;DuelOwner=DuelTarget=-1;}
            foreach(var p in Players)
            {
                p.CyberMarks[id]=p.AlchemyStacks[id]=p.OverwhelmStacks[id]=p.FrostHits[id]=p.ShadowMarks[id]=p.ShadowCycles[id]=p.EmbeddedBlades[id]=p.EmbeddedCaladbolgs[id]=0;
                if(p.QinMarkOwner==id)p.QinMarkOwner=-1;if(p.DinoMarkOwner==id){p.DinoMarkOwner=-1;p.DinoMarkUntil=0;}
                if(p.DoomOwner==id){p.DoomOwner=-1;p.DoomAt=0;}
                if(p.BurnOwner==id){p.BurnOwner=-1;p.BurnTicks=0;}
                if(p.TetherTarget==id){p.TetherTarget=-1;p.TetherUntil=0;}
            }
        }
        void Respawn(int id)
        {
            Fighter f=Players[id];int score=f.Score,team=f.TeamId;bool revived=f.BloodReviveUsed;
            f.Reset(Time);f.Score=score;f.TeamId=team;f.BloodReviveUsed=revived;f.Gauge=0;
            f.Pos=SpawnPosition(id);f.Facing=Mode==BattleMode.DpsEvent?(id<2?1:-1):(f.Pos.x<0?1:-1);f.InvulnUntil=Time+.8f;
            UpdateSummoner(f);Cue(f.Pos,"복귀","ring",id,2,.5f);
        }
        void ResolveContinuousKO()
        {
            if(Mode==BattleMode.DpsEvent)return;
            if(Mode==BattleMode.BossRaid){ResolveBossKO();return;}
            var defeated=new List<Fighter>();
            foreach(var f in Players)if(!f.Dead&&!IsFixedDummy(f)&&IsKO(f)&&!TimingGrace(f))defeated.Add(f);
            if(defeated.Count==0)return;
            foreach(var f in defeated)
            {
                int killer=f.LastAttacker;
                if(!Training)
                {
                    if(killer>=0&&Opponents(killer,f.Id)&&Time-f.LastAttackedAt<=10)
                    {Players[killer].Score++;TeamScores[Players[killer].TeamId]++;}
                    else if(Mode!=BattleMode.FreeForAll&&Mode!=BattleMode.ThreeWay)
                    {foreach(var p in Players)if(Opponents(f.Id,p.Id)){p.Score++;TeamScores[p.TeamId]++;break;}}
                    else {f.Score=Math.Max(0,f.Score-1);TeamScores[f.TeamId]=f.Score;}
                }
                f.Dead=true;f.Vel=new V2();ClearLife(f.Id);
                f.AwaitingPick=Mode==BattleMode.Draft;f.RespawnAt=Time+(Training?.35f:.65f);
                Cue(f.Pos,"KO","burst",killer>=0?killer:f.Id,2,.7f);
            }
            Round++;if(!Training)CheckModeVictory();
            if(Mode==BattleMode.Draft&&Phase!=Phase.Finished)foreach(var survivor in Players){survivor.AwaitingPick=true;ClearLife(survivor.Id);}
            if(Mode==BattleMode.Draft&&Phase!=Phase.Finished)
            {
                var exhausted=new List<int>();foreach(var f in Players)if(f.AwaitingPick){bool any=false;foreach(var d in Roster.All)if(!UsedJob(f.Id,d.Job)){any=true;break;}if(!any)exhausted.Add(f.Id);}
                if(exhausted.Count==Players.Length){Winner=-1;Phase=Phase.Finished;Announcement="무승부 · 사용 가능한 직업 없음";Effects.Clear();scheduled.Clear();}
                else if(exhausted.Count>0)Finish(Enemy(Players[exhausted[0]]).Id);
            }
        }
        void CheckModeVictory()
        {
            if(Options.KillLimit<=0)return;
            int best=-1,winning=-1,ties=0;var seen=new HashSet<int>();
            foreach(var f in Players)if(seen.Add(f.TeamId))
            {int score=TeamScores[f.TeamId];if(score>best){best=score;winning=f.Id;ties=1;}else if(score==best)ties++;}
            if(best>=Options.KillLimit&&ties==1)Finish(winning);
            else if(best>=Options.KillLimit)SuddenDeath=true;
        }
        public bool UsedJob(int player,Job job){return usedJobs[player,(int)job];}
        public bool SelectNextJob(int player,Job job)
        {
            if(Mode!=BattleMode.Draft||Phase==Phase.Finished||player<0||player>=Players.Length||!Players[player].AwaitingPick||usedJobs[player,(int)job])return false;
            Fighter old=Players[player];usedJobs[player,(int)job]=true;
            Players[player]=new Fighter(player,job){Score=old.Score,TeamId=old.TeamId,BloodReviveUsed=old.BloodReviveUsed};
            Respawn(player);return true;
        }
        public void SelectCpuReplacement(int id)
        {
            var remaining=new List<Job>();foreach(var d in Roster.All)if(!UsedJob(id,d.Job))remaining.Add(d.Job);
            if(remaining.Count==0){Finish(Enemy(Players[id]).Id);return;}
            SelectNextJob(id,remaining[rng.Next(remaining.Count)]);
        }
    }
}
