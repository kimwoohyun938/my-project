﻿using System;
using UnityEngine;
using StickmanBrawler.Core;

namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        static readonly Color Ink=new Color(.025f,.04f,.065f),Panel=new Color(.055f,.08f,.12f),Muted=new Color(.48f,.59f,.68f),Gold=new Color(1,.79f,.3f);
        static readonly Color[] Team={new Color(.22f,.92f,.87f),new Color(1,.39f,.38f),new Color(.65f,.57f,1),new Color(1,.78f,.25f)};
        Texture2D circle,glow,ringTex;
        GUIStyle label;
        float uiScale=1;
        void EnsureUI()
        {
            if(label!=null)return;
            Font koreanFont=Resources.Load<Font>("Fonts/DungGeunMo");
            if(koreanFont==null)Debug.LogWarning("Korean font missing: Assets/Resources/Fonts/DungGeunMo.ttf");
            label=new GUIStyle(GUI.skin.label){font=koreanFont!=null?koreanFont:Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"),wordWrap=true};
            circle=new Texture2D(64,64,TextureFormat.RGBA32,false);glow=new Texture2D(64,64,TextureFormat.RGBA32,false);
            for(int y=0;y<64;y++)for(int x=0;x<64;x++)
            { float d=Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(32,32))/32;circle.SetPixel(x,y,new Color(1,1,1,Mathf.Clamp01((1-d)*32)));glow.SetPixel(x,y,new Color(1,1,1,Mathf.Pow(Mathf.Max(0,1-d),2))); }
            circle.Apply();glow.Apply();
            ringTex=new Texture2D(128,128,TextureFormat.RGBA32,false);
            ringTex.wrapMode=TextureWrapMode.Clamp;ringTex.filterMode=FilterMode.Bilinear;
            for(int y=0;y<128;y++)for(int x=0;x<128;x++)
            {
                float d=Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(64,64))/64f;
                float a=Mathf.Clamp01(1-Mathf.Abs(d-.9f)/.065f);
                ringTex.SetPixel(x,y,new Color(1,1,1,a*a));
            }
            ringTex.Apply();
        }
        Color Alpha(Color color,float alpha) { color.a=alpha;return color; }
        void Box(Rect rect,Color color) { GUI.color=color;GUI.DrawTexture(rect,Texture2D.whiteTexture);GUI.color=Color.white; }
        void Disc(Vector2 pos,float r,Color color,bool soft=false)
        { GUI.color=color;GUI.DrawTexture(new Rect(pos.x-r,pos.y-r,r*2,r*2),soft?glow:circle);GUI.color=Color.white; }
        void Line(Vector2 from,Vector2 to,Color color,float thickness=2)
        {
            Vector2 delta=to-from;
            float length=delta.magnitude;
            if(length<.0001f || thickness<=0)return;

            Matrix4x4 previousMatrix=GUI.matrix;
            Color previousColor=GUI.color;
            try
            {
                // Rotate in the same local coordinates as the endpoints, then
                // apply the existing viewport scale and letterbox translation.
                // Draw from the local origin so the start point is not applied twice.
                GUI.matrix=previousMatrix*Matrix4x4.TRS(
                    new Vector3(from.x,from.y,0),
                    Quaternion.Euler(0,0,Mathf.Atan2(delta.y,delta.x)*Mathf.Rad2Deg),
                    Vector3.one);
                GUI.color=color;
                GUI.DrawTexture(new Rect(0,-thickness/2,length,thickness),Texture2D.whiteTexture);
            }
            finally
            {
                GUI.matrix=previousMatrix;
                GUI.color=previousColor;
            }
        }
        void Ring(Vector2 pos,float radius,Color color,float thick=2)
        {
            if(radius<=.5f||thick<=0||Event.current.type!=EventType.Repaint)return;
            float r=radius/.9f;
            GUI.color=color;
            GUI.DrawTexture(new Rect(pos.x-r,pos.y-r,r*2,r*2),ringTex);
            if(thick>3.2f){float r2=(radius-thick*.45f)/.9f;if(r2>1)GUI.DrawTexture(new Rect(pos.x-r2,pos.y-r2,r2*2,r2*2),ringTex);}
            GUI.color=Color.white;
        }
        void Text(Rect rect,string value,int size=16,Color? color=null,TextAnchor align=TextAnchor.UpperLeft,bool bold=false)
        {
            if(Event.current.type!=EventType.Repaint|| string.IsNullOrEmpty(value))return;
            label.fontSize=size;label.normal.textColor=color??Color.white;label.alignment=align;label.fontStyle=bold?FontStyle.Bold:FontStyle.Normal;GUIContent content=new GUIContent(value);
            if(value.Length>16)while(label.fontSize>9&&label.CalcHeight(content,rect.width)>rect.height)label.fontSize--;
            GUI.Label(rect,content,label);
        }
        bool Button(Rect rect,string text,Color? color=null,int size=15)
        {
            Color c=color??Muted;bool hover=rect.Contains(Event.current.mousePosition);
            Box(rect,hover?Alpha(c,.24f):Panel);Box(new Rect(rect.x,rect.y,3,rect.height),c);
            Text(rect,text,size,c,TextAnchor.MiddleCenter,true);
            if(GUI.Button(rect,GUIContent.none,GUIStyle.none)){Sound(selectSound);return true;}return false;
        }
        void OnGUI()
        {
            EnsureUI();EnsureClarity();GUI.color=Color.white;Box(new Rect(0,0,Screen.width,Screen.height),Ink);
            uiScale=Mathf.Min(Screen.width/1280f,Screen.height/720f);
            GUI.matrix=Matrix4x4.TRS(new Vector3((Screen.width-1280*uiScale)/2,(Screen.height-720*uiScale)/2,0),Quaternion.identity,Vector3.one*uiScale);
            if(onlineMenu||OnlineActive)OnlineUI();else if(menu)MenuUI();else GameUI();
            if(settings)SettingsUI();GUI.matrix=Matrix4x4.identity;GUI.color=Color.white;
        }
        void Background()
        {
            Box(new Rect(0,0,1280,720),Ink);
            for(int x=0;x<1280;x+=48)Box(new Rect(x,0,1,720),new Color(.05f,.075f,.1f));
            for(int y=0;y<720;y+=48)Box(new Rect(0,y,1280,1),new Color(.05f,.075f,.1f));
            Disc(new Vector2(210,280),340,Alpha(Team[0],.12f),true);Disc(new Vector2(1080,300),340,Alpha(Team[1],.12f),true);
        }
        void MenuUI()
        {
            Background();Text(new Rect(42,22,950,30),"로컬 대전   /   "+Roster.All.Length+"종   /   최대 4인",13,Muted);
            Text(new Rect(40,53,1030,64),"STICKMAN BRAWLER",48,Color.white,TextAnchor.UpperLeft,true);
            Text(new Rect(44,114,950,28),"Read the tell. Break the combo. Own the edge.",18,Muted);
            if(Button(new Rect(930,45,145,40),"ONLINE",Team[0])){onlineMenu=true;settings=false;}
            if(Button(new Rect(1090,45,145,40),"SETTINGS"))settings=true;
            FighterCard(0,p1,new Rect(40,153,274,385));FighterCard(selectedPlayer==0?1:selectedPlayer,SeatJob(selectedPlayer==0?1:selectedPlayer),new Rect(966,153,274,385));
            Text(new Rect(345,170,590,25),"CHOOSE YOUR FIGHTER",16,Gold,TextAnchor.MiddleCenter,true);
            for(int seat=0;seat<SelectableSeats;seat++)
                if(Button(new Rect(345+seat*(592f/SelectableSeats),202,592f/SelectableSeats-8,28),"자리 "+(seat+1)+" 선택",selectedPlayer==seat?Team[seat]:Muted,12))selectedPlayer=seat;
            for(int i=0;i<=Roster.All.Length;i++)
            {
                int row=i/10,col=i%10;Rect r=new Rect(335+col*61,238+row*45,58,39);
                string name=i==Roster.All.Length?"RANDOM":Roster.All[i].Name;
                bool isA=p1==i,isB=p2==i,isC=SelectableSeats>=3&&p3==i,isD=SelectableSeats>=4&&p4==i;
                if(Button(r,name,SeatJob(selectedPlayer)==i?Team[selectedPlayer]:isA?Team[0]:isB?Team[1]:isC?Team[2]:isD?Team[3]:Muted,name.Length>9?9:11)){SetSeatJob(selectedPlayer,i);}
                if(isA)Box(new Rect(r.x,r.y,20,3),Team[0]);if(isB)Box(new Rect(r.xMax-20,r.y,20,3),Team[1]);
                if(isC)Box(new Rect(r.x,r.yMax-3,20,3),Team[2]);if(isD)Box(new Rect(r.xMax-20,r.yMax-3,20,3),Team[3]);
            }
            Text(new Rect(345,516,585,20),ThreeHumans?"3인 이동 A·D·C / G·Y·J / 방향키 · 가드 S / K / .":"1P A/D · 2P 방향키 | 가드 S / ↓ | 타깃 Tab / 오른쪽 Shift",11,Muted,TextAnchor.MiddleCenter);
            ModeMenuOptions();
        }
        void FighterCard(int player,int index,Rect r)
        {
            Box(r,Panel);Box(new Rect(r.x,r.y,r.width,3),Team[player]);
            Text(new Rect(r.x+18,r.y+17,r.width-36,25),SeatLabel(player),13,Team[player],TextAnchor.UpperLeft,true);
            if(index==Roster.All.Length){Text(new Rect(r.x+15,r.y+100,r.width-30,95),"?",76,Team[player],TextAnchor.MiddleCenter,true);Text(new Rect(r.x+15,r.y+240,r.width-30,80),"A new fighter is assigned at match start.",18,Muted);return;}
            Definition d=Roster.All[index];
            Text(new Rect(r.x+16,r.y+45,r.width-32,36),d.Name,25,Color.white,TextAnchor.UpperLeft,true);
            Text(new Rect(r.x+18,r.y+80,r.width-36,24),d.Role,12,Team[player]);
            Text(new Rect(r.x+18,r.y+108,r.width-36,25),d.HP+" HP   /   "+d.Speed+" SPEED",13,Muted);
            Text(new Rect(r.x+18,r.y+141,r.width-36,22),(ControllerFor(player)>=0?GameKey(ControllerFor(player),4).ToString():"스킬 1")+"  "+d.QName,13,Gold,TextAnchor.UpperLeft,true);
            Text(new Rect(r.x+18,r.y+163,r.width-36,56),d.QInfo,12,Muted);
            Text(new Rect(r.x+18,r.y+220,r.width-36,22),(ControllerFor(player)>=0?GameKey(ControllerFor(player),5).ToString():"스킬 2")+"  "+d.EName,13,Gold,TextAnchor.UpperLeft,true);
            Text(new Rect(r.x+18,r.y+242,r.width-36,48),d.EInfo,12,Muted);
            Text(new Rect(r.x+18,r.y+292,r.width-36,22),(ControllerFor(player)>=0?GameKey(ControllerFor(player),6).ToString():"궁극기")+"  "+d.RName,13,Gold,TextAnchor.UpperLeft,true);
            Text(new Rect(r.x+18,r.y+315,r.width-36,64),d.RInfo,11,Muted);
        }
        Vector2 ScreenPoint(V2 pos)
        {
            float scale=1280/camWidth;float offset=reduceMotion?0:Mathf.Sin(Time.unscaledTime*95)*shake*18;
            return new Vector2(640+(pos.x-cam.x)*scale+offset,384-(pos.y-cam.y)*scale);
        }
        void GameUI()
        {
            if(Event.current.type!=EventType.Repaint)
            {
            if(world.Phase==Phase.Finished)ResultsUI();else if(paused)PauseUI();else if(world.NeedsSelection)DraftSelectionUI();
                return;
            }
            Background();DrawRealm();DrawSea();DrawStage();DrawDuel();
            if(Array.Exists(world.Players,p=>!p.Dead&&p.UltimateCastingUntil>world.Time))
                Box(new Rect(0,0,1280,720),new Color(.01f,.015f,.03f,.38f));
            foreach(var e in world.Effects)DrawEffect(e);
            foreach(var f in world.Players)if(!f.Dead)DrawFighter(f);
            foreach(var cue in world.Cues)DrawCue(cue);
            if(world.Players.Length>=3)MultiHUD();else{HUD(0);HUD(1);DrawV2Status();}
            if(world.Players.Length==2){Box(new Rect(561,20,158,75),Panel);Text(new Rect(561,25,158,33),world.Training?"훈련장":world.Mode!=BattleMode.Classic?"연속 전투":world.SuddenDeath?"SUDDEN DEATH":((int)world.Remaining/60)+":"+((int)world.Remaining%60).ToString("00"),world.SuddenDeath?15:24,Gold,TextAnchor.MiddleCenter,true);
            Text(new Rect(561,62,158,23),world.Mode==BattleMode.Classic?"ROUND "+world.Round:ModeLabel,12,Muted,TextAnchor.MiddleCenter);}
            Box(new Rect(0,681,1280,39),Ink);Text(new Rect(30,688,650,24),world.Arena.Name+"   /   "+(world.Mode==BattleMode.DpsEvent?"제한시간 "+eventDuration+"초 · 전용 허수아비 피해량 대결":world.Mode==BattleMode.BossRaid?"보스 격파 · 팀 공용 목숨 "+world.BossLivesRemaining:world.Training?"H: REFILL    BACKSPACE: RESET":world.Mode!=BattleMode.Classic?(killGoal==0?"무제한 · 연속 복귀":killGoal+"점 선취 · 연속 복귀"):world.Arena.Closed?"FIRST TO 5 / HP ONLY / SOLID BOUNDS":"FIRST TO 5 / FIXED BLAST ZONE"),12,Muted);
            Text(new Rect(980,688,265,24),"ESC  PAUSE / MOVE LIST",12,Muted,TextAnchor.MiddleRight);
            if(world.Training)Text(new Rect(510,123,260,68),"LAST "+Mathf.RoundToInt(world.LastDamage)+"    COMBO "+world.ComboHits+"\nTOTAL "+Mathf.RoundToInt(world.ComboDamage),14,Gold,TextAnchor.MiddleCenter);
            if(world.Phase==Phase.Countdown)
            { Text(new Rect(190,240,900,100),world.SuddenDeath?"SUDDEN DEATH":world.PhaseUntil-world.Time>.4f?Mathf.CeilToInt(world.PhaseUntil-world.Time).ToString():"FIGHT",72,Color.white,TextAnchor.MiddleCenter,true); }
            if(world.Phase==Phase.RoundOver)Text(new Rect(90,240,1100,120),world.Announcement,44,Gold,TextAnchor.MiddleCenter,true);
            if(world.Phase==Phase.Finished)ResultsUI();else if(paused)PauseUI();else if(world.NeedsSelection)DraftSelectionUI();
        }
        void DrawStage()
        {
            float k=1280/camWidth;
            // Layered procedural skyline, not downloaded artwork.
            for(int i=0;i<23;i++)
            { float h=45+(i*71%170);Box(new Rect(i*65-40,525-h,48,h+180),new Color(.04f,.065f,.10f));for(int j=0;j<4;j++)Box(new Rect(i*65-32,540-h+j*33,4,6),new Color(.13f,.19f,.22f)); }
            foreach(var p in world.Arena.Platforms)
            {
                Vector2 point=ScreenPoint(new V2(p.X-p.Width/2,p.Y));Rect r=new Rect(point.x,point.y,p.Width*k,.5f*k);
                Box(r,Panel);Box(new Rect(r.x,r.y,r.width,3),Team[0]);Box(new Rect(r.x,r.y+3,r.width,8),Alpha(Team[0],.12f));
                for(float x=r.x+10;x<r.xMax;x+=45)Line(new Vector2(x,r.y+9),new Vector2(Mathf.Min(x+20,r.xMax),r.y+16),Alpha(Muted,.22f),2);
            }
            Vector2 tl=ScreenPoint(new V2(world.Arena.Left,world.Arena.Top)),br=ScreenPoint(new V2(world.Arena.Right,world.Arena.Bottom));
            Color danger=Alpha(world.Arena.Closed?Team[0]:Team[1],.55f);Line(tl,new Vector2(br.x,tl.y),danger);Line(new Vector2(tl.x,br.y),br,danger);Line(tl,new Vector2(tl.x,br.y),danger);Line(new Vector2(br.x,tl.y),br,danger);
        }
        void DrawRealm()
        {
            foreach(var f in world.Players)
            {
                if(f.Dead||f.RealmUntil<=world.Time||world.Phase!=Phase.Fight)continue;
                Color amber=new Color(1,.45f,.16f);
                Box(new Rect(0,120,1280,480),Alpha(amber,.13f));
                Disc(new Vector2(640,370),430,Alpha(amber,.24f),true);
                for(int i=0;i<25;i++)
                {
                    float x=world.Arena.Left+1+(world.Arena.Right-world.Arena.Left-2)*i/24;
                    Vector2 p=ScreenPoint(new V2(x,-1.4f-(i*7%5)*.4f));
                    Sword(p,new Vector2((i%3-1)*.25f,-1),amber,1280/camWidth*.9f);
                }
                Text(new Rect(380,100+f.Id*22,520,25),"INFINITE SWORD DOMAIN  /  "+(f.RealmUntil-world.Time).ToString("0.0")+"s",14,Gold,TextAnchor.MiddleCenter,true);
            }
        }
        void Sword(Vector2 p,Vector2 direction,Color c,float length)
        {
            Vector2 d=direction.normalized,n=new Vector2(-d.y,d.x);
            Line(p-d*length*.4f,p+d*length*.6f,c,3);
            Line(p+d*length*.6f,p+d*length*.4f+n*length*.10f,c,2);
            Line(p+d*length*.6f,p+d*length*.4f-n*length*.10f,c,2);
            Line(p-d*length*.2f-n*length*.15f,p-d*length*.2f+n*length*.15f,c,3);
        }
        void DrawSea()
        {
            if(world.Phase!=Phase.Fight||!Array.Exists(world.Players,x=>world.IsShip(x)))return;
            Color water=new Color(.1f,.52f,.85f);
            Box(new Rect(0,120,1280,480),Alpha(water,.2f));
            for(int row=0;row<7;row++)
            for(int x=0;x<1280;x+=40)
            {
                float y=180+row*64;
                Line(new Vector2(x,y+Mathf.Sin(x*.02f+world.Time*2)*5),new Vector2(x+40,y+Mathf.Sin((x+40)*.02f+world.Time*2)*5),Alpha(water,.35f),2);
            }
            Text(new Rect(440,145,400,24),"OPEN SEA  /  TURTLE SHIP",13,Gold,TextAnchor.MiddleCenter,true);
        }
        void DrawShip(Vector2 p,float k,float face,Color c)
        {
            Disc(p+new Vector2(0,-.1f*k),.65f*k,Alpha(c,.8f));
            Box(new Rect(p.x-.85f*k,p.y+.1f*k,1.7f*k,.4f*k),c);
            Line(p+new Vector2(-.85f*k,.5f*k),p+new Vector2(.85f*k,.5f*k),Gold,.07f*k);
            for(int i=-2;i<=2;i++)
            {Line(p+new Vector2(i*.22f*k,-.42f*k),p+new Vector2(i*.22f*k,-.66f*k),Gold,.04f*k);Disc(p+new Vector2(i*.3f*k,.29f*k),.07f*k,Ink);}
            Line(p+new Vector2(face*.55f*k,0),p+new Vector2(face*1.1f*k,-.12f*k),Gold,.15f*k);
        }
        void DrawFighter(Fighter f)
        {
            Vector2 p=ScreenPoint(f.Pos);float k=1280/camWidth*f.Scale(world.Time),face=f.Facing;
            if(world.IsGuarding(f)){Ring(p,1.15f*k,Alpha(Team[f.Id],.8f),3);Text(new Rect(p.x-50,p.y-1.6f*k,100,22),"가드",13,Team[f.Id],TextAnchor.MiddleCenter,true);}
            Color c=f.HitFlashUntil>world.Time?Color.white:f.IsBoss?new Color(1,.25f,.15f):Team[f.DisguiseUntil>world.Time?world.Enemy(f).Id:f.Id];if(f.StealthUntil>world.Time)c.a=.3f;
            float walk=(world.InHitstop(f)?f.HitstopPoseTime:world.Time)*13f;
            float speedRatio=Mathf.Clamp01(Mathf.Abs(f.Vel.x)/8f);
            float stride=f.Grounded?speedRatio*Mathf.Sin(walk):.65f;
            bool strike=!world.InHitstop(f)&&f.AttackVisualUntil>world.Time;
            bool casting=f.CastUntil>world.Time||f.UltimateCastingUntil>world.Time;
            bool guarding=world.IsGuarding(f);
            float lean=guarding?-face*.06f:strike?face*.18f:Mathf.Clamp(f.Vel.x/10f,-1f,1f)*.15f;
            float crouch=guarding?.12f:0f;
            Vector2 head=p+new Vector2(lean*1.1f*k,(-.64f+crouch)*k);
            Vector2 shoulder=p+new Vector2(lean*.75f*k,(-.30f+crouch)*k);
            Vector2 hip=p+new Vector2(-lean*.2f*k,(.14f+crouch*.5f)*k);
            Vector2 elbow=shoulder+new Vector2(face*(strike?.56f:guarding?.22f:.18f)*k,(strike?.08f:guarding?-.05f:.20f)*k);
            Vector2 hand=shoulder+new Vector2(face*(strike?1.12f:guarding?.38f:.48f)*k,(strike?-.04f:guarding?-.22f:.24f)*k);
            Vector2 offElbow=shoulder+new Vector2(-face*(casting?.20f:guarding?-.18f:.22f)*k,(casting?-.15f:guarding?.05f:.18f)*k);
            Vector2 offHand=shoulder+new Vector2(-face*(casting?.08f:guarding?-.32f:.34f)*k,(casting?-.42f:guarding?-.18f:.38f)*k);
            if(world.IsShip(f))DrawShip(p,k,face,c);
            else
            {
            Disc(p,k*1.32f,Alpha(c,.15f),true);
            DrawCostume(f,p,k,c.a);
            Line(shoulder,offElbow,Alpha(c,c.a*.82f),.075f*k);Line(offElbow,offHand,Alpha(c,c.a*.82f),.07f*k);
            if(casting)Disc(offHand,.12f*k,Gold,true);
            Vector2 footL=p+new Vector2((-.28f-stride*.22f)*k,(.86f-(f.Grounded?Mathf.Max(0,-stride)*.12f:.18f))*k);
            Vector2 footR=p+new Vector2((.28f+stride*.22f)*k,(.86f-(f.Grounded?Mathf.Max(0,stride)*.12f:.12f))*k);
            Vector2 kneeL=(hip+footL)*.5f+new Vector2(face*.09f*k,-.05f*k);
            Vector2 kneeR=(hip+footR)*.5f+new Vector2(face*.09f*k,-.05f*k);
            Line(hip,kneeL,c,.092f*k);Line(kneeL,footL,c,.078f*k);
            Line(hip,kneeR,c,.092f*k);Line(kneeR,footR,c,.078f*k);
            Line(head+new Vector2(0,.18f*k),hip,c,.105f*k);
            Disc(head,.235f*k,c);
            Color eyeColor=f.UltimateCastingUntil>world.Time||f.FormUntil>world.Time||f.LancerFuryUntil>world.Time?Gold:Ink;
            Line(head+new Vector2(face*.04f*k,-.02f*k),head+new Vector2(face*.17f*k,-.04f*k),eyeColor,.045f*k);
            Line(shoulder,elbow,c,.082f*k);Line(elbow,hand,c,.078f*k);
            if(f.Job!=Job.Lancer||f.HasSpear)DrawWeapon(f.DisguiseUntil>world.Time?world.Enemy(f).Job:f.PowerJob,hand,k,face,strike,c.a);
            }
            if(f.Job==Job.Institutor)
                for(int i=0;i<f.YangSwords;i++)
                {Vector2 s=ScreenPoint(world.YangPosition(f,i,f.YangSwords));if(s.y>110&&s.y<681)Sword(s,new Vector2(0,-1),Gold,k*.65f);}
            DrawExpansionStatus(f,p,k);DrawTimingCyberFighter(f,p,k);DrawLuminaryFighterVisuals(f,p,k);
            if(f.AvalonActive)Ring(p,k*1.3f,Gold,2);
            if(world.Fortune(f)>0){Ring(p,k*1.5f,Gold,3);if(world.Fortune(f)==2)Ring(p,k*1.7f,Color.white,2);}
            if(f.Job==Job.DinoMan){Line(hip,hip+new Vector2(-face*.9f*k,.35f*k),c,k*.12f);for(int i=0;i<3;i++)Line(hip+new Vector2(-face*i*.2f*k,0),hip+new Vector2(-face*i*.2f*k,-.15f*k),Gold,3);}
            if(f.UltimateCastingUntil>world.Time){Ring(p,k*1.4f,Gold,3);Disc(p,k*1.7f,Alpha(Gold,.2f),true);}
            if(f.Job==Job.Guardian||f.Job==Job.Reflector)Ring(hand,.35f*k,c,.05f*k);
            if(f.InvulnUntil>world.Time||f.ShieldUntil>world.Time||f.GuardUntil>world.Time||f.DodgeUntil>world.Time)Ring(p,k*1.15f,Gold,2);
            if(f.FormUntil>world.Time||f.BuffUntil>world.Time)Ring(p,k*1.23f,Alpha(c,.5f),2);
            if(f.RootUntil>world.Time){Line(p+new Vector2(-.6f*k,.4f*k),p+new Vector2(.6f*k,.75f*k),Gold,3);Line(p+new Vector2(.6f*k,.4f*k),p+new Vector2(-.6f*k,.75f*k),Gold,3);}
            Text(new Rect(p.x-70,p.y-1.6f*k,140,24),SeatLabel(f.Id)+"  "+Status(f),12,c,TextAnchor.MiddleCenter,true);
            if(f.MarkUntil>world.Time)Text(new Rect(p.x-40,p.y-2.1f*k,80,25),"MARK",12,Gold,TextAnchor.MiddleCenter);
            if(f.DinoMarkOwner>=0&&f.DinoMarkUntil>world.Time)Text(new Rect(p.x-70,p.y-2.35f*k,140,24),"DINO MARK",12,Gold,TextAnchor.MiddleCenter);
            if(f.QinMarkOwner>=0){Ring(head,k*.45f,Gold,2);Text(new Rect(p.x-70,p.y-2.2f*k,140,22),"IMPERIAL SEAL",11,Gold,TextAnchor.MiddleCenter);}
            int swords=0,calad=0;
            foreach(var other in world.Players)if(world.Opponents(f.Id,other.Id)){swords+=f.EmbeddedBlades[other.Id];calad+=f.EmbeddedCaladbolgs[other.Id];}
            int marks=swords+calad;
            if(marks>0)
            {
                Text(new Rect(p.x-85,p.y-2.9f*k,170,22),"SWORDS "+swords+" / CALAD "+calad,11,Gold,TextAnchor.MiddleCenter);
                for(int i=0;i<Math.Min(marks,6);i++){float a=world.Time+i*Mathf.PI/3;Vector2 d=new Vector2(Mathf.Cos(a),Mathf.Sin(a));Sword(p+d*k*1.2f,d,Alpha(Gold,.7f),k*.4f);}
            }
            if(f.DoomAt>0)Text(new Rect(p.x-80,p.y-2.7f*k,160,26),"SIGIL "+Mathf.Max(0,f.DoomAt-world.Time).ToString("0.0"),15,Team[1],TextAnchor.MiddleCenter,true);
        }
        string Status(Fighter f)
        {
            float t=world.Time;
            if(f.UltimateCastingUntil>t)return "ULT INVULNERABLE";
            if(f.Job==Job.TimeMurder&&f.BuffUntil>t&&f.InvulnUntil>t)return "STASIS";
            if(world.InHitstop(f))return "피격 충격 · 카운터만 가능";
            if(world.InHitstun(f))return "피격 경직 · 카운터만 가능";
            if(f.FreezeUntil>t)return "FROZEN "+(f.FreezeUntil-t).ToString("0.0");
            if(f.StealthUntil>t)return "EVASION";
            if(f.VoidPhaseUntil>t)return "PHASE / PHYSICAL IMMUNE";
            if(f.StunUntil>t)return "STUN "+(f.StunUntil-t).ToString("0.0");if(f.RootUntil>t)return "ROOT";
            if(f.SilenceUntil>t)return "SILENCE";if(f.SkillLockUntil>t)return "Q/E LOCK";if(f.SlowUntil>t)return "SLOW";
            if(f.BurnTicks>0)return "BURN "+f.BurnTicks;
            if(f.ArmorUntil>t)return "ARMOR";if(f.RoninDrawReady)return "발도 태세";return "";
        }
        void DrawEffect(Effect e)
        {
            Vector2 p=ScreenPoint(e.Pos);float k=1280/camWidth;Color c=ArtColor(WeaponArt.Colors[(int)world.Players[e.Owner].Job]);
            if(e.Dead)return;
            if(DrawTimingCyberEffect(e,p,k))return;
            if(DrawV2Effect(e,p,k,c))return;
            if(DrawClarityEffect(e,p,k,c))return;
            if(DrawExpansionEffect(e,p,k,c))return;
            bool tell=world.Time<e.ActiveAt;
            if(e.Tag=="pterosaur")
            {float flap=Mathf.Sin(world.Time*18)*.45f*k;Line(p-new Vector2(k,flap),p,c,4);Line(p,p+new Vector2(k,-flap),c,4);Disc(p,k*.22f,Gold);return;}
            if(e.Tag=="fortune-coin"){Disc(p,e.Radius*k,Gold);Ring(p,e.Radius*k*.65f,Ink,2);return;}
            if(e.Tag=="dino-egg"){Disc(p,e.Radius*k,Color.white);Disc(p+new Vector2(3,-2),k*.08f,c);return;}
            if(e.Tag=="yi-soldier")
            {
                float stride=Mathf.Sin(world.Time*18)*.2f*k;
                Disc(p+new Vector2(0,-.42f*k),.16f*k,c);Line(p+new Vector2(0,-.25f*k),p+new Vector2(0,.2f*k),c,.07f*k);
                Line(p+new Vector2(0,.2f*k),p+new Vector2(-.2f*k-stride,.55f*k),c,.06f*k);Line(p+new Vector2(0,.2f*k),p+new Vector2(.2f*k+stride,.55f*k),c,.06f*k);
                Line(p,p+new Vector2(.3f*k,0),c,.06f*k);Sword(p+new Vector2(.4f*k,0),new Vector2(1,-.5f),Gold,.6f*k);return;
            }
            if(e.Shape==Shape.Shot&&(e.Tag=="gae-bolg"||e.Tag=="caladbolg"||e.Tag=="nisemono-blade"||e.Tag=="ubw-sword"||e.Tag=="yang-sword"))
            {
                if(e.Tag=="gae-bolg")c=new Color(1,.08f,.17f);
                Vector2 d=new Vector2(e.Vel.x,-e.Vel.y).normalized;
                Disc(p,k*.8f,Alpha(c,.35f),true);Sword(p,d,c,k*(e.Tag=="gae-bolg"?2.4f:e.Tag=="caladbolg"?1.5f:.9f));return;
            }
            if(e.Shape==Shape.Wall){Box(new Rect(p.x-e.Width*k/2,p.y-e.Height*k/2,e.Width*k,e.Height*k),Alpha(c,.45f));return;}
            if(e.Shape==Shape.Turret){Box(new Rect(p.x-15,p.y-13,30,26),c);Line(p,p+new Vector2((world.Enemy(world.Players[e.Owner]).Pos.x>e.Pos.x?1:-1)*22,-9),c,5);Box(new Rect(p.x-20,p.y-24,40*Mathf.Clamp01(e.Health/280f),3),Gold);return;}
            if(e.Shape==Shape.Spear){Line(p-new Vector2(15,10),p+new Vector2(15,10),Gold,3);return;}
            if(e.Shape==Shape.Beam){Vector2 end=ScreenPoint(e.Pos+e.Vel*e.Width);Line(p,end,Alpha(c,.18f),e.Height*k*1.6f);Line(p,end,c,e.Height*k*.45f);Line(p,end,Color.white,3);return;}
            if(e.Shape==Shape.Shot){Disc(p,e.Radius*k*3,Alpha(c,.45f),true);Disc(p,e.Radius*k,c);Line(p,p-new Vector2(e.Vel.x,-e.Vel.y)*.035f*k,Alpha(c,.5f),3);return;}
            if(e.Shape==Shape.Trap){Ring(p,e.Radius*k,Alpha(c,.6f),2);Line(p-new Vector2(10,0),p+new Vector2(10,0),c,3);return;}
            if(e.Tag=="blackhole"){Disc(p,e.Radius*k,Alpha(c,.45f),true);Disc(p,e.Radius*k*.24f,Ink);Ring(p,e.Radius*k*.45f,c,2);}
            else{Disc(p,e.Radius*k,Alpha(c,tell?.09f:.14f));Ring(p,e.Radius*k,Alpha(c,tell?.55f:.35f),tell?2:1);}
            if(e.Tag=="rain")for(int i=0;i<7;i++){float x=(i-3)*.7f*k;float y=Mathf.Repeat(world.Time*200+i*49,100);Line(p+new Vector2(x,y-80),p+new Vector2(x-5,y-100),c,2);}
            if(e.Shape==Shape.Wind||e.Tag=="tempest")for(int i=0;i<3;i++)Ring(p,e.Radius*k*(.3f+.2f*i),Alpha(c,.5f),2);
        }
        void DrawCue(Cue cue)
        {
            float life=Mathf.Clamp01((world.Time-cue.Start)/(cue.Expires-cue.Start));Vector2 p=ScreenPoint(cue.Pos);float k=1280/camWidth;Color c=Alpha(ArtColor(WeaponArt.Colors[(int)world.Players[cue.Owner].Job]),1-life);
            if(cue.Kind=="damage"){DrawReadableDamage(cue,p,life);return;}
            if(DrawLuminaryCue(cue,p,k,c,life))return;
            if(DrawTimingCyberCue(cue,p,k,c,life))return;
            if(DrawClarityCue(cue,p,k,c,life))return;
            if(DrawExpansionCue(cue,p,k,c,life))return;
            if(cue.Kind=="damage"||cue.Kind=="text")Text(new Rect(p.x-135,p.y-28-life*35,270,55),cue.Text,cue.Kind=="damage"?21:14,cue.Kind=="damage"?Gold:c,TextAnchor.MiddleCenter,true);
            else if(cue.Kind=="warning")Ring(p,cue.Size*k,Alpha(Gold,.75f),2);
            else if(cue.Kind=="fire-arc")
            {Vector2 arrow=ScreenPoint(V2.Lerp(cue.Pos,cue.End,life)+new V2(0,Mathf.Sin(life*Mathf.PI)*6));Disc(arrow,k*.23f,Gold);Line(arrow,arrow+new Vector2(-8,12),Team[1],3);}
            else if(cue.Kind=="warning-line")Line(p,ScreenPoint(cue.End),Alpha(Gold,.45f),3);
            else if(cue.Kind=="gate"){Ring(p,cue.Size*k,Gold,3);Disc(p,cue.Size*k,Alpha(Gold,.15f));}
            else if(cue.Kind=="fortune-rune")
            {Ring(p,cue.Size*k,Gold,3);Line(p+Vector2.up*cue.Size*k,p+Vector2.right*cue.Size*k,Gold,3);Line(p+Vector2.right*cue.Size*k,p-Vector2.up*cue.Size*k,Gold,3);Line(p-Vector2.up*cue.Size*k,p-Vector2.right*cue.Size*k,Gold,3);Line(p-Vector2.right*cue.Size*k,p+Vector2.up*cue.Size*k,Gold,3);}
            else if(cue.Kind=="doors")
            {Box(new Rect(p.x-.75f*k,p.y-k,.2f*k,2*k),Alpha(Gold,.6f));Box(new Rect(p.x+.55f*k,p.y-k,.2f*k,2*k),Alpha(Gold,.6f));}
            else if(cue.Kind=="hassan-reach"){Vector2 end=ScreenPoint(cue.End);Line(p,end,c,k*.12f);Disc(end,k*.18f,c);}
            else if(cue.Kind=="world-beam"){DrawEnergyBeam(p,ScreenPoint(cue.End),cue.Size*k,c,world.Players[cue.Owner].Job);}
            else if(cue.Kind=="slash"||cue.Kind=="bolt")Line(p,ScreenPoint(cue.End),cue.Kind=="bolt"?Gold:c,cue.Kind=="bolt"?6:4);
            else if(cue.Kind=="ring")Ring(p,cue.Size*k*(.5f+life),c,2);
            else if(cue.Kind=="burst")
            { for(int i=0;i<9;i++){float a=i*Mathf.PI*2/9;Vector2 dir=new Vector2(Mathf.Cos(a),Mathf.Sin(a));Line(p+dir*cue.Size*k*life*.4f,p+dir*cue.Size*k*(life+.2f),c,3);} }
        }
        void HUD(int index)
        {
            Fighter f=world.Players[index];float x=index==0?30:750;Color c=Team[index];
            Box(new Rect(x,20,500,99),Alpha(Ink,.94f));Text(new Rect(x+12,24,320,30),SeatLabel(index)+"  "+f.Def.Name,22,c,TextAnchor.MiddleLeft,true);
            Text(new Rect(x+345,25,140,28),Mathf.CeilToInt(f.HP)+" / "+Mathf.CeilToInt(f.MaxHP),14,Color.white,TextAnchor.MiddleRight);
            Box(new Rect(x+12,61,476,12),Panel);Box(new Rect(x+12,61,476*HealthTrail(f),12),new Color(1,.65f,.25f));Box(new Rect(x+12,61,476*Mathf.Clamp01(f.HP/f.MaxHP),12),c);
            Box(new Rect(x+12,80,320,5),Panel);Box(new Rect(x+12,80,320*f.Gauge/100,5),Gold);
            for(int i=0;i<5;i++)Disc(new Vector2(x+365+i*26,86),7,f.Score>i?c:Muted);
            Text(new Rect(x+12,91,470,22),"ULT "+Mathf.FloorToInt(f.Gauge)+"%  /  KNOCKBACK x"+f.KnockbackScale.ToString("0.00")+(f.KnockbackBonus>0?"  / +"+(f.KnockbackBonus*100).ToString("0.#")+"% KB":""),11,Muted);
            DrawExpansionHUD(f,x);
            string[] names={f.Def.QName,f.Def.EName,f.Def.RName};float[] cds={f.QAt,f.EAt,0};
            if(world.IsShip(f)){names[0]="DECK LASER";names[1]="SEA COMMAND";}
            for(int i=0;i<3;i++)
            {
                float sx=x+12+i*157;bool locked=f.SilenceUntil>world.Time||(i<2&&f.SkillLockUntil>world.Time);
                string state=locked?"LOCKED":cds[i]>world.Time?(cds[i]-world.Time).ToString("0.0")+"s":i==2&&f.Gauge<100?"CHARGING":"READY";
                if(i==0&&!locked&&f.Job==Job.VoidWalker&&f.VoidRecastAvailable&&f.VoidRecastUntil>world.Time)state="RECAST "+(f.VoidRecastUntil-world.Time).ToString("0.0");
                if(i==2&&!locked&&f.Job==Job.ShadowClone&&world.Enemy(f).ShadowMarks[f.Id]<3)state="NEED 3 MARKS";
                if(i==2&&!locked&&f.Job==Job.FrostReaper&&V2.Distance(f.Pos,world.Enemy(f).Pos)>6)state="OUT OF RANGE";
                if(i==2&&!locked&&f.Job==Job.VoidWalker&&world.DuelUntil>world.Time)state="DUEL ACTIVE";
                if(i==0&&f.Job==Job.Lancer&&!f.HasSpear&&!locked&&f.QAt<=world.Time)state="RECALL";
                if(i<2&&!locked&&f.Job==Job.QinShi&&world.Enemy(f).QinMarkOwner!=f.Id)state="NEED SEAL";
                if(i==1&&!locked&&f.Job==Job.Nisemono&&world.Enemy(f).EmbeddedBlades[f.Id]+world.Enemy(f).EmbeddedCaladbolgs[f.Id]==0)state="NEED SWORDS";
                if(i==2&&!locked&&f.Job==Job.Nisemono&&f.RealmUntil>world.Time)state="REALM ACTIVE";
                if(i==2&&!locked&&f.Job==Job.Master&&f.HP>f.Def.HP*.4f)state="HP <= 40%";
                if(i<2&&!locked&&f.Job==Job.Institutor&&f.YangSwords==0)state="NEED SWORD";
                if(i==2&&!locked&&world.IsShip(f))state="SHIP ACTIVE";
                if(i==2&&!locked&&f.Job==Job.DinoMan&&(world.Enemy(f).DinoMarkOwner!=f.Id||world.Enemy(f).DinoMarkUntil<=world.Time))state="NEED MARK";
                if(i==2&&!locked&&world.Fortune(f)>0)state="AWAKENED";
                if(i==2&&!locked&&f.Job==Job.Undying&&f.UndyingUntil>world.Time)state="UNDYING ACTIVE";
                if(!locked&&f.Job==Job.Puppeteer&&i>0&&world.FindSummon(f,"puppet")==null)state="NEED PUPPET";
                if(i==1&&!locked&&f.Job==Job.MirrorAssassin&&world.FindSummon(f,"mirror")==null)state="NEED MIRROR";
                if(i==1&&!locked&&f.Job==Job.PhantomLegion&&world.CountSummons(f,"phantom")==0)state="NEED PHANTOM";
                if(i==1&&!locked&&f.Job==Job.Gambler&&f.HP<=60)state="NEED HP >60";
                if(i==0&&!locked&&f.Job==Job.Luminary&&f.LuminaryShards>=9)state="MAX 9 SHARDS";
                Box(new Rect(sx,603,149,59),Panel);Text(new Rect(sx+7,607,135,18),(ControllerFor(index)>=0?GameKey(ControllerFor(index),i+4).ToString():"CPU")+"  "+state,12,state=="READY"||state=="RECALL"?c:Muted,TextAnchor.UpperLeft,true);
                Text(new Rect(sx+7,630,135,30),names[i],10,Muted);
            }
            if(f.Job==Job.Cross)Text(new Rect(x+12,565,475,28),"ORACLE: RANDOM / 5 DEITIES",13,Gold);
            if(f.Job==Job.CardMan)Text(new Rect(x+12,565,475,28),"CARD: "+new[]{"WHITE / SPEED","BLUE / POWER","RED / SLOW"}[f.Card],13,Gold);
            if(f.Overclock)Text(new Rect(x+12,565,475,28),"OVERCLOCK ACTIVE",13,Gold);
            if(f.Job==Job.QinShi)Text(new Rect(x+12,565,475,28),"SEAL: "+(world.Enemy(f).QinMarkOwner==f.Id?"ACTIVE":"NONE")+" / HIT +35% / TAKEN +20% ULT",12,Gold);
            if(f.Job==Job.Nisemono)Text(new Rect(x+12,552,475,44),"SANCTUARY: "+(f.AvalonActive?"HEALING":f.AvalonReadyAt>world.Time?(f.AvalonReadyAt-world.Time).ToString("0.0")+"s":"READY BELOW 30%")+"\nSWORDS: "+world.Enemy(f).EmbeddedBlades[f.Id]+"  SPIRAL BLADE: "+world.Enemy(f).EmbeddedCaladbolgs[f.Id],12,Gold);
            if(f.Job==Job.YiSunGod)Text(new Rect(x+12,552,475,44),world.IsShip(f)?"TURTLE SHIP "+(f.FormUntil-world.Time).ToString("0.0")+"s  / BASIC 80 / 0.85s\nQ: LASER 50    E: SLOW 20%":"SWORD 60 / 0.65s  / HIT +7% / TAKEN +5% ULT",12,Gold);
            if(f.Job==Job.Institutor)Text(new Rect(x+12,552,475,44),"YANG SWORDS: "+f.YangSwords+"  / NEXT "+Mathf.Max(0,f.NextYangAt-world.Time).ToString("0.0")+"s\nQ BOOST "+Mathf.Max(0,f.YangSprintUntil-world.Time).ToString("0.0")+"s  / R BOOST "+Mathf.Max(0,f.YangUltimateUntil-world.Time).ToString("0.0")+"s",12,Gold);
            if(f.Job==Job.Gambler)Text(new Rect(x+12,552,475,44),"FORTUNE: "+FortuneName(world.Fortune(f))+"  "+Mathf.Max(0,f.FortuneUntil-world.Time).ToString("0.0")+"s\nCOIN BUFF "+Mathf.Max(0,f.CoinCritUntil-world.Time).ToString("0.0")+"s / CRIT HEAL 110",12,Gold);
            if(f.Job==Job.DinoMan)Text(new Rect(x+12,565,475,28),"MARK: "+(world.Enemy(f).DinoMarkOwner==f.Id?Mathf.Max(0,world.Enemy(f).DinoMarkUntil-world.Time).ToString("0.0")+"s":"NONE"),12,Gold);
        }
        void PauseUI()
        {
            if(ThreeHumans){TrioPauseUI();return;}
            Box(new Rect(0,0,1280,720),new Color(0,0,0,.85f));Text(new Rect(340,32,600,65),"PAUSED",42,Color.white,TextAnchor.MiddleCenter,true);
            FighterCard(0,(int)world.Players[0].Job,new Rect(140,126,330,385));FighterCard(1,(int)world.Players[1].Job,new Rect(810,126,330,385));
            if(Button(new Rect(500,180,280,50),"RESUME  [ ESC ]",Team[0]))paused=false;
            if(Button(new Rect(500,248,280,50),"REMATCH"))StartMatch();
            if(Button(new Rect(500,316,280,50),"SETTINGS"))settings=true;
            if(Button(new Rect(500,384,280,50),"CHARACTER SELECT")){menu=true;paused=false;}
            Text(new Rect(190,570,900,75),"STUN: no actions   |   ROOT: attacks allowed, position fixed   |   SILENCE: basic attacks allowed\nTwo jumps. Original skill durations and recovery. Attacking ends spawn protection.",16,Muted,TextAnchor.MiddleCenter);
        }
        void ResultsUI()
        {
            if(OnlineActive){OnlineResultsUI();return;}
            Box(new Rect(0,0,1280,720),new Color(0,0,0,.85f));Color c=world.Winner>=0?Team[world.Winner]:Gold;
            Text(new Rect(90,180,1100,85),world.Announcement,64,c,TextAnchor.MiddleCenter,true);
            Text(new Rect(100,288,1080,56),ScoreSummary(),world.Mode==BattleMode.DpsEvent?24:40,Gold,TextAnchor.MiddleCenter,true);
            if(Button(new Rect(370,400,540,60),"REMATCH  [ ENTER ]",c,22))StartMatch();
            if(Button(new Rect(370,480,540,50),"CHARACTER SELECT")){menu=true;paused=false;}
        }
        void SettingsUI()
        {
            Box(new Rect(0,0,1280,720),new Color(.02f,.035f,.055f,.99f));Text(new Rect(40,25,950,60),"CONTROLS & ACCESSIBILITY",36,Color.white,TextAnchor.MiddleLeft,true);
            Text(new Rect(42,90,1150,46),"Click a binding, then press a key. Duplicate keys swap automatically. ESC / Enter / Tab / Right Shift / H / Backspace are reserved.",15,Muted);
            for(int p=0;p<2;p++)
            {
                float x=80+p*610;Text(new Rect(x,150,470,40),"PLAYER "+(p+1),22,Team[p],TextAnchor.MiddleLeft,true);
                for(int k=0;k<8;k++)
                { Text(new Rect(x,206+k*43,240,33),actionNames[k],16,Muted);if(Button(new Rect(x+240,200+k*43,235,35),rebinding==p*8+k?"PRESS A KEY...":keys[p,k].ToString(),Team[p]))rebinding=p*8+k; }
            }
            if(rebinding>=0 && Event.current.type==EventType.KeyDown)
            {
                KeyCode code=Event.current.keyCode;
                if(code==KeyCode.Escape)rebinding=-1;
                else if(code!=KeyCode.None&&code!=KeyCode.Return&&code!=KeyCode.Tab&&code!=KeyCode.RightShift&&code!=KeyCode.H&&code!=KeyCode.Backspace)
                {
                    int p=rebinding/8,k=rebinding%8;KeyCode old=keys[p,k];
                    for(int a=0;a<2;a++)for(int b=0;b<8;b++)if(keys[a,b]==code)keys[a,b]=old;
                    keys[p,k]=code;rebinding=-1;SaveSettings();
                }
                Event.current.Use();
            }
            if(Button(new Rect(80,567,475,44),"REDUCED MOTION: "+(reduceMotion?"ON":"OFF"),Gold)){reduceMotion=!reduceMotion;SaveSettings();}
            if(Button(new Rect(690,567,475,44),"SOUND: "+(muted?"OFF":"ON"),Gold)){muted=!muted;SaveSettings();}
            if(Button(new Rect(400,630,480,50),"DONE",Team[0])){settings=false;rebinding=-1;SaveSettings();}
        }
    }
}
