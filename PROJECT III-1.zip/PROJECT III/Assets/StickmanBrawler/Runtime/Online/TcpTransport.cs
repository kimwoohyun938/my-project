using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace StickmanBrawler.Online
{
    public interface IRoomTransport:IDisposable
    {
        bool Connected{get;} string Error{get;} bool TryReceive(out byte[] bytes);
        void Send(byte[] bytes,bool replaceable=false);
    }
    // One reader and one writer thread. No Unity API is accessed from socket threads.
    public sealed class TcpRoomTransport:IRoomTransport
    {
        readonly ConcurrentQueue<byte[]> incoming=new ConcurrentQueue<byte[]>(),outgoing=new ConcurrentQueue<byte[]>();
        readonly AutoResetEvent wake=new AutoResetEvent(false);readonly object gate=new object();
        TcpClient client;TcpListener listener;byte[] latest;volatile bool disposed,connected;string error="";
        public bool Connected{get{return connected&&!disposed;}}
        public string Error{get{return error;}}
        public int Port{get;private set;}
        public static TcpRoomTransport Host(int port)
        {var t=new TcpRoomTransport();try{t.listener=new TcpListener(IPAddress.Any,port);t.listener.Start(1);t.Port=((IPEndPoint)t.listener.LocalEndpoint).Port;t.Spawn(()=>t.Attach(t.listener.AcceptTcpClient()));}catch(Exception e){t.Fail(e);}return t;}
        public static TcpRoomTransport Join(string address,int port)
        {var t=new TcpRoomTransport();t.Spawn(()=>{var c=new TcpClient();lock(t.gate){if(t.disposed){c.Close();return;}t.client=c;}var ar=c.BeginConnect(address,port,null,null);if(!ar.AsyncWaitHandle.WaitOne(8000))throw new IOException("Connection timed out");c.EndConnect(ar);ar.AsyncWaitHandle.Close();t.Attach(c);});return t;}
        void Spawn(Action run){new Thread(()=>{try{run();}catch(Exception e){if(!disposed)Fail(e);}}){IsBackground=true}.Start();}
        void Attach(TcpClient c)
        {
            lock(gate){if(disposed){c.Close();return;}client=c;c.NoDelay=true;c.ReceiveTimeout=10000;c.SendTimeout=5000;connected=true;}
            if(listener!=null)listener.Stop();Spawn(ReadLoop);Spawn(WriteLoop);
        }
        static void Exact(Stream s,byte[] b)
        {int offset=0;while(offset<b.Length){int n=s.Read(b,offset,b.Length-offset);if(n==0)throw new EndOfStreamException("Peer closed connection");offset+=n;}}
        void ReadLoop()
        {
            var s=client.GetStream();while(!disposed){byte[] header=new byte[4];Exact(s,header);int n=header[0]|header[1]<<8|header[2]<<16|header[3]<<24;if(n<1||n>Wire.MaxFrame)throw new InvalidDataException("Frame limit");byte[] b=new byte[n];Exact(s,b);if(incoming.Count>=128)throw new IOException("Incoming queue limit");incoming.Enqueue(b);}
        }
        void WriteLoop()
        {
            var s=client.GetStream();while(!disposed)
            {
                byte[] b;if(!outgoing.TryDequeue(out b)){lock(gate){b=latest;latest=null;}}
                if(b==null){wake.WaitOne(100);continue;}int n=b.Length;byte[] h={(byte)n,(byte)(n>>8),(byte)(n>>16),(byte)(n>>24)};s.Write(h,0,4);s.Write(b,0,n);
            }
        }
        public bool TryReceive(out byte[] b){return incoming.TryDequeue(out b);}
        public void Send(byte[] b,bool replaceable=false)
        {if(disposed)return;if(b==null||b.Length==0||b.Length>Wire.MaxFrame)throw new InvalidDataException("Outgoing frame");if(replaceable){lock(gate)latest=b;}else{if(outgoing.Count>=256){Fail(new IOException("Outgoing queue limit"));return;}outgoing.Enqueue(b);}wake.Set();}
        void Fail(Exception e){error=e.GetType().Name+": "+e.Message;Dispose();}
        public void Dispose(){lock(gate){if(disposed)return;disposed=true;connected=false;try{if(listener!=null)listener.Stop();}catch{}try{if(client!=null)client.Close();}catch{}wake.Set();}}
    }
}
