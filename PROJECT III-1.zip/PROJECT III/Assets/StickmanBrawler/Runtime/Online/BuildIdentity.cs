namespace StickmanBrawler.Online { public static class BuildIdentity { public const string Value="43b6344c22eb6161b6ddd5213bda2464c3ce90e95ab207416964549003f83b09"; } }
