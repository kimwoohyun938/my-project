using System;
using System.Collections.Generic;
using System.IO;
using StickmanBrawler.Core;
namespace StickmanBrawler.Online
{
    public enum RoomState { Connecting,Lobby,Playing,Results,Closed }
    public interface ICombatInputSource { Controls Consume(int tick); }
    public sealed class InputMailbox:ICombatInputSource
    {
        struct Entry {public int Sequence,Due;public Controls Value;}
        readonly Queue<Entry> queue=new Queue<Entry>();Controls held;int lastArrival=-100000,lastSequence;
        public int Acknowledged{get;private set;}
        public bool Push(int sequence,Controls value,int now,int delay)
        {
            if(sequence<=lastSequence)return false;
            if(sequence>lastSequence+600||queue.Count>=120)throw new InvalidDataException("Input stream limit");
            if(float.IsNaN(value.Move)||float.IsInfinity(value.Move)||Math.Abs(value.Move)>1)throw new InvalidDataException("Move range");
            lastSequence=sequence;lastArrival=now;queue.Enqueue(new Entry{Sequence=sequence,Due=now+delay,Value=value});return true;
        }
        public Controls Consume(int tick)
        {
            // Discard old stalled inputs rather than executing a burst after a network stall.
            while(queue.Count>0&&queue.Peek().Due<tick-15){Acknowledged=queue.Dequeue().Sequence;held=new Controls();}
            if(queue.Count>0&&queue.Peek().Due<=tick){var e=queue.Dequeue();held=e.Value;Acknowledged=e.Sequence;var result=held;held.ClearEdges();return result;}
            if(tick-lastArrival>15)held=new Controls();var c=held;held.ClearEdges();return c;
        }
    }
    public sealed class RoomSession:IDisposable
    {
        public readonly bool IsHost;
        readonly IRoomTransport transport;readonly Random matchRandom=new Random();
        public RoomState State{get;private set;}=RoomState.Connecting;
        public string Status{get;private set;}="연결 대기";
        public readonly int[] Jobs={0,5};public readonly bool[] Ready={false,false},WantsRematch={false,false};
        public int Stage{get;private set;} public int Match{get;private set;} public int Revision{get;private set;}
        public int LocalSeat{get{return IsHost?0:1;}}
        public World Authority{get;private set;} public World View{get;private set;}
        public double PingMs{get;private set;} public double SnapshotAge{get{return now-lastSnapshotAt;}}
        public int SnapshotSequence{get;private set;} public int LastAck{get;private set;}
        public int DelayTicks{get;private set;}=0;
        public const string Protocol="SB-2.4.1-1";
        bool greeted,welcomed;double connectedAt,now,lastReceive,nextPing,accumulator,lastSnapshotAt;int clock,inputSequence,viewSequence,receivedWindow;double windowAt;
        Controls captured;InputMailbox[] input={new InputMailbox(),new InputMailbox()};
        public RoomSession(IRoomTransport transport,bool host){this.transport=transport;IsHost=host;}
        public void ClearLocalInput(){captured=new Controls();}
        public void Capture(Controls value)
        {captured.Move=value.Move;captured.Attack=value.Attack;captured.Command=value.Command;captured.Guard=value.Guard;captured.Jump|=value.Jump;captured.Skill1|=value.Skill1;captured.Skill2|=value.Skill2;captured.Ultimate|=value.Ultimate;}
        public void Pump(float delta)
        {
            if(State==RoomState.Closed)return;
            now+=Math.Max(0,delta);
            try
            {
                if(transport.Error.Length>0){Close("연결 종료: "+transport.Error);return;}
                if(transport.Connected&&!greeted){greeted=true;lastReceive=connectedAt=now;if(!IsHost)transport.Send(Wire.Message(Packet.Hello,w=>{Wire.Text(w,Protocol);Wire.Text(w,BuildIdentity.Value);}));}
                byte[] bytes;int count=0;while(count++<128&&transport.TryReceive(out bytes)){Receive(bytes);lastReceive=now;if(State==RoomState.Closed)return;}
                if(greeted&&!welcomed&&now-connectedAt>8){Close("게임 버전 확인 시간 초과");return;}
                if(greeted&&now-lastReceive>6){Close("응답 없음 · 연결 시간 초과");return;}
                if(!greeted&&now>15&&!IsHost){Close("접속 시간 초과 · 주소와 포트를 확인하세요");return;}
                if(transport.Connected&&now>=nextPing){nextPing=now+1;transport.Send(Wire.Message(Packet.Ping,w=>w.Write(now)));}
                accumulator+=Math.Min(delta,.25f);int steps=0;
                while(accumulator>=Rules.Dt&&steps++<15)
                {
                    accumulator-=Rules.Dt;clock++;
                    if(State!=RoomState.Playing){captured=new Controls();continue;}
                    if(IsHost)
                    {
                        input[0].Push(++inputSequence,captured,clock,DelayTicks);captured.ClearEdges();
                        Authority.Tick(new[]{input[0].Consume(clock),input[1].Consume(clock)});
                        if(clock%2==0||Authority.Phase==Phase.Finished)Publish();
                        if(Authority.Phase==Phase.Finished){State=RoomState.Results;Status="경기 종료";}
                    }
                    else {var c=captured;int seq=++inputSequence;transport.Send(Wire.Message(Packet.Input,w=>{w.Write(Match);w.Write(seq);Wire.Input(w,c);}));captured.ClearEdges();}
                }
            }
            catch(Exception e){Close("세션 오류: "+e.GetType().Name+" · "+e.Message);}
        }
        void Receive(byte[] bytes)
        {
            if(bytes.Length<1||bytes.Length>Wire.MaxFrame)throw new InvalidDataException("Packet size");
            var type=(Packet)bytes[0];
            if(type==Packet.Snapshot)
            {
                if(IsHost||!welcomed)throw new InvalidDataException("Snapshot authority");
                if(State!=RoomState.Playing&&State!=RoomState.Results)return;
                int match,seq,ack;var next=ViewCodec.Decode(bytes,out match,out seq,out ack);if(match!=Match||seq<=SnapshotSequence)return;
                if(next.Players[0].NativeJob!=(Job)Jobs[0]||next.Players[1].NativeJob!=(Job)Jobs[1])throw new InvalidDataException("Roster mismatch");
                View=next;SnapshotSequence=seq;LastAck=ack;lastSnapshotAt=now;
                if(View.Phase==Phase.Finished){State=RoomState.Results;Status="경기 종료";}return;
            }
            using(var r=Wire.Reader(bytes))
            {
                r.ReadByte();
                if(type==Packet.Ping){double stamp=r.ReadDouble();Wire.End(r);transport.Send(Wire.Message(Packet.Pong,w=>w.Write(stamp)));return;}
                if(type==Packet.Pong){double stamp=r.ReadDouble();Wire.End(r);if(double.IsNaN(stamp)||stamp>now||now-stamp>10)throw new InvalidDataException("Ping stamp");PingMs=(now-stamp)*1000;return;}
                if(type==Packet.Leave){Wire.End(r);Close("상대가 방을 나갔습니다");return;}
                if(IsHost)
                {
                    if(type==Packet.Hello)
                    {
                        if(welcomed||Wire.Text(r)!=Protocol||Wire.Text(r)!=BuildIdentity.Value)throw new InvalidDataException("게임 버전이 다릅니다");Wire.End(r);welcomed=true;State=RoomState.Lobby;Status="참가자 연결됨";
                        transport.Send(Wire.Message(Packet.Welcome,w=>{Wire.Text(w,Protocol);Wire.Text(w,BuildIdentity.Value);}));BroadcastLobby();return;
                    }
                    if(!welcomed)throw new InvalidDataException("Handshake required");
                    if(type==Packet.Choose){int job=Wire.JobId(r);Wire.End(r);if(State==RoomState.Lobby){Jobs[1]=job;Changed();}return;}
                    if(type==Packet.Ready){int rev=r.ReadInt32();bool ready=r.ReadBoolean();Wire.End(r);if(State==RoomState.Lobby&&rev==Revision){Ready[1]=ready;BroadcastLobby();TryStart();}return;}
                    if(type==Packet.Rematch){int match=r.ReadInt32();Wire.End(r);if(State==RoomState.Results&&match==Match){WantsRematch[1]=true;BroadcastLobby();TryRematch();}return;}
                    if(type==Packet.Input)
                    {
                        int match=r.ReadInt32(),seq=r.ReadInt32();var c=Wire.Input(r);Wire.End(r);
                        if(State!=RoomState.Playing||match!=Match)return;
                        if(now-windowAt>=1){windowAt=now;receivedWindow=0;}if(++receivedWindow>180)throw new InvalidDataException("Input rate limit");
                        input[1].Push(seq,c,clock,DelayTicks);return;
                    }
                    throw new InvalidDataException("Client cannot submit combat results");
                }
                if(type==Packet.Welcome){if(welcomed||Wire.Text(r)!=Protocol||Wire.Text(r)!=BuildIdentity.Value)throw new InvalidDataException("Protocol mismatch");Wire.End(r);welcomed=true;State=RoomState.Lobby;Status="방 참가 완료";return;}
                if(!welcomed)throw new InvalidDataException("Handshake required");
                if(type==Packet.Lobby)
                {
                    int rev=r.ReadInt32();var state=(RoomState)r.ReadByte();if(state!=RoomState.Lobby&&state!=RoomState.Results)throw new InvalidDataException("Lobby state");
                    Revision=rev;Stage=r.ReadInt32();if(Stage<0||Stage>=Arena.Count)throw new InvalidDataException("Stage");DelayTicks=r.ReadInt32();if(DelayTicks<0||DelayTicks>12)throw new InvalidDataException("Input delay");
                    for(int i=0;i<2;i++){Jobs[i]=Wire.JobId(r);Ready[i]=r.ReadBoolean();WantsRematch[i]=r.ReadBoolean();}Wire.End(r);State=state;return;
                }
                if(type==Packet.Start)
                {
                    int id=r.ReadInt32(),stage=r.ReadInt32(),a=Wire.JobId(r),b=Wire.JobId(r);Wire.End(r);if(id<=Match||stage<0||stage>=Arena.Count)throw new InvalidDataException("Match start");
                    Match=id;Stage=stage;Jobs[0]=a;Jobs[1]=b;State=RoomState.Playing;Status="온라인 1v1";inputSequence=SnapshotSequence=LastAck=0;captured=new Controls();accumulator=0;View=null;return;
                }
                throw new InvalidDataException("Unexpected host message");
            }
        }
        void Changed(){Revision++;Ready[0]=Ready[1]=false;BroadcastLobby();}
        public void Choose(int job){if(State!=RoomState.Lobby||job<0||job>=Roster.All.Length)return;if(IsHost){Jobs[0]=job;Changed();}else transport.Send(Wire.Message(Packet.Choose,w=>w.Write(job)));}
        public void SetStage(int stage){if(!IsHost||State!=RoomState.Lobby||stage<0||stage>=Arena.Count)return;Stage=stage;Changed();}
        public void SetDelay(int ticks){if(!IsHost||State!=RoomState.Lobby)return;DelayTicks=Math.Max(0,Math.Min(12,ticks));Changed();}
        public void SetReady(bool ready){if(State!=RoomState.Lobby)return;if(IsHost){Ready[0]=ready;BroadcastLobby();TryStart();}else transport.Send(Wire.Message(Packet.Ready,w=>{w.Write(Revision);w.Write(ready);}));}
        void BroadcastLobby()
        {transport.Send(Wire.Message(Packet.Lobby,w=>{w.Write(Revision);w.Write((byte)State);w.Write(Stage);w.Write(DelayTicks);for(int i=0;i<2;i++){w.Write(Jobs[i]);w.Write(Ready[i]);w.Write(WantsRematch[i]);}}));}
        void TryStart()
        {
            if(!Ready[0]||!Ready[1])return;
            Match++;inputSequence=viewSequence=SnapshotSequence=0;input=new[]{new InputMailbox(),new InputMailbox()};captured=new Controls();accumulator=0;
            Authority=new World((Job)Jobs[0],(Job)Jobs[1],Stage,matchRandom.Next(1,int.MaxValue));State=RoomState.Playing;Status="온라인 1v1";
            transport.Send(Wire.Message(Packet.Start,w=>{w.Write(Match);w.Write(Stage);w.Write(Jobs[0]);w.Write(Jobs[1]);}));Publish();
        }
        void Publish()
        {
            byte[] bytes=ViewCodec.Encode(Authority,Stage,Match,++viewSequence,input[1].Acknowledged);transport.Send(bytes,true);
            int m,s,a;View=ViewCodec.Decode(bytes,out m,out s,out a);SnapshotSequence=s;LastAck=input[0].Acknowledged;lastSnapshotAt=now;
        }
        public void Rematch()
        {if(State!=RoomState.Results)return;if(IsHost){WantsRematch[0]=true;BroadcastLobby();TryRematch();}else transport.Send(Wire.Message(Packet.Rematch,w=>w.Write(Match)));}
        void TryRematch()
        {if(!WantsRematch[0]||!WantsRematch[1])return;State=RoomState.Lobby;Revision++;Ready[0]=Ready[1]=WantsRematch[0]=WantsRematch[1]=false;Authority=null;View=null;BroadcastLobby();}
        public void Leave(){if(State!=RoomState.Closed)transport.Send(Wire.Message(Packet.Leave));Close("방에서 나왔습니다");}
        void Close(string reason){Status=reason;State=RoomState.Closed;captured=new Controls();transport.Dispose();}
        public void Dispose(){transport.Dispose();State=RoomState.Closed;}
    }
}
