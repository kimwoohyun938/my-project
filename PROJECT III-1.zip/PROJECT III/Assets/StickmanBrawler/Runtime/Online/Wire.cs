using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using StickmanBrawler.Core;
namespace StickmanBrawler.Online
{
    public enum Packet : byte { Hello=1,Welcome,Lobby,Choose,Ready,Start,Input,Snapshot,Rematch,Ping,Pong,Leave }
    public static class Wire
    {
        public const int MaxFrame=262144,MaxInflated=2097152;
        public static byte[] Message(Packet kind,Action<BinaryWriter> body=null)
        {using(var m=new MemoryStream()){using(var w=new BinaryWriter(m,Encoding.UTF8,true)){w.Write((byte)kind);if(body!=null)body(w);}return m.ToArray();}}
        public static BinaryReader Reader(byte[] bytes){return new BinaryReader(new MemoryStream(bytes),Encoding.UTF8);}
        public static void Text(BinaryWriter w,string value){var b=Encoding.UTF8.GetBytes(value??"");if(b.Length>4096)throw new InvalidDataException("Text too long");w.Write(b.Length);w.Write(b);}
        public static string Text(BinaryReader r){int n=r.ReadInt32();if(n<0||n>4096||n>r.BaseStream.Length-r.BaseStream.Position)throw new InvalidDataException("Text length");return Encoding.UTF8.GetString(r.ReadBytes(n));}
        public static void End(BinaryReader r){if(r.BaseStream.Position!=r.BaseStream.Length)throw new InvalidDataException("Trailing payload");}
        public static void Input(BinaryWriter w,Controls c)
        {if(float.IsNaN(c.Move)||float.IsInfinity(c.Move)||Math.Abs(c.Move)>1)throw new InvalidDataException("Move");w.Write(c.Move);w.Write((byte)((c.Jump?1:0)|(c.Attack?2:0)|(c.Skill1?4:0)|(c.Skill2?8:0)|(c.Ultimate?16:0)|(c.Command?32:0)|(c.Guard?64:0)));}
        public static Controls Input(BinaryReader r)
        {float move=r.ReadSingle();int b=r.ReadByte();if(float.IsNaN(move)||float.IsInfinity(move)||Math.Abs(move)>1||b>127)throw new InvalidDataException("Input");return new Controls(move,(b&1)!=0,(b&2)!=0,(b&4)!=0,(b&8)!=0,(b&16)!=0){Command=(b&32)!=0,Guard=(b&64)!=0};}
        public static int JobId(BinaryReader r){int j=r.ReadInt32();if(j<0||j>=Roster.All.Length)throw new InvalidDataException("Job");return j;}
    }
    // Whitelisted public scalar fields only: never BinaryFormatter or arbitrary type deserialization.
    public static class ViewCodec
    {
        static bool Scalar(Type t){return t==typeof(float)||t==typeof(int)||t==typeof(bool)||t==typeof(string)||t==typeof(V2)||t==typeof(double)||t.IsEnum;}
        static FieldInfo[] Fields(Type t){return t.GetFields(BindingFlags.Public|BindingFlags.Instance).Where(f=>!f.Name.StartsWith("Remote")&&(Scalar(f.FieldType)||f.FieldType.IsArray&&Scalar(f.FieldType.GetElementType()))).OrderBy(f=>f.Name,StringComparer.Ordinal).ToArray();}
        static readonly FieldInfo[] fighters=Fields(typeof(Fighter)),effects=Fields(typeof(Effect)),hits=Fields(typeof(Hit)),cues=Fields(typeof(Cue)),worlds=Fields(typeof(World));
        static void WriteValue(BinaryWriter w,Type t,object v)
        {
            if(t.IsEnum||t==typeof(int))w.Write(Convert.ToInt32(v));else if(t==typeof(float))w.Write((float)v);else if(t==typeof(double))w.Write((double)v);else if(t==typeof(bool))w.Write((bool)v);else if(t==typeof(string))Wire.Text(w,(string)v);else if(t==typeof(V2)){w.Write(((V2)v).x);w.Write(((V2)v).y);}else throw new InvalidDataException("Unsupported field");
        }
        static object ReadValue(BinaryReader r,Type t)
        {
            if(t.IsEnum)return Enum.ToObject(t,r.ReadInt32());if(t==typeof(int))return r.ReadInt32();if(t==typeof(bool))return r.ReadBoolean();if(t==typeof(string))return Wire.Text(r);
            if(t==typeof(float)){float n=r.ReadSingle();if(float.IsNaN(n)||float.IsInfinity(n))throw new InvalidDataException("Non-finite state");return n;}
            if(t==typeof(double)){double n=r.ReadDouble();if(double.IsNaN(n)||double.IsInfinity(n))throw new InvalidDataException("Non-finite state");return n;}
            if(t==typeof(V2))return new V2((float)ReadValue(r,typeof(float)),(float)ReadValue(r,typeof(float)));throw new InvalidDataException("Unsupported field");
        }
        static void WriteFields(BinaryWriter w,object obj,FieldInfo[] fields)
        {foreach(var f in fields){var a=f.GetValue(obj) as Array;if(a!=null){w.Write(a.Length);foreach(var v in a)WriteValue(w,f.FieldType.GetElementType(),v);}else WriteValue(w,f.FieldType,f.GetValue(obj));}}
        static void ReadFields(BinaryReader r,object obj,FieldInfo[] fields)
        {foreach(var f in fields){if(f.FieldType.IsArray){var a=(Array)f.GetValue(obj);if(r.ReadInt32()!=a.Length)throw new InvalidDataException("Array schema mismatch");for(int i=0;i<a.Length;i++)a.SetValue(ReadValue(r,f.FieldType.GetElementType()),i);}else{object value=ReadValue(r,f.FieldType);if(f.IsInitOnly){if(!Equals(f.GetValue(obj),value))throw new InvalidDataException("Identity mismatch");}else f.SetValue(obj,value);}}}
        static int Count(BinaryReader r,int max){int n=r.ReadInt32();if(n<0||n>max)throw new InvalidDataException("Collection limit");return n;}
        public static byte[] Encode(World world,int stage,int match,int sequence,int ack)
        {
            using(var raw=new MemoryStream())
            {
                using(var w=new BinaryWriter(raw,Encoding.UTF8,true))
                {
                    w.Write(match);w.Write(sequence);w.Write(ack);w.Write(stage);w.Write((int)world.Players[0].NativeJob);w.Write((int)world.Players[1].NativeJob);
                    WriteFields(w,world,worlds);
                    foreach(var f in world.Players){WriteFields(w,f,fighters);w.Write(world.TimingReturnReady(f));w.Write(world.TimingInterceptReady(f));}
                    if(world.Effects.Count>4096||world.Cues.Count>4096)throw new InvalidDataException("View capacity exceeded");
                    w.Write(world.Effects.Count);foreach(var e in world.Effects){WriteFields(w,e,effects);w.Write(e.Hit!=null);if(e.Hit!=null)WriteFields(w,e.Hit,hits);}
                    w.Write(world.Cues.Count);foreach(var c in world.Cues)WriteFields(w,c,cues);
                }
                if(raw.Length>Wire.MaxInflated)throw new InvalidDataException("View too large");
                using(var result=new MemoryStream()){result.WriteByte((byte)Packet.Snapshot);using(var z=new DeflateStream(result,CompressionLevel.Fastest,true)){var b=raw.ToArray();z.Write(b,0,b.Length);}if(result.Length>Wire.MaxFrame)throw new InvalidDataException("Compressed view too large");return result.ToArray();}
            }
        }
        public static World Decode(byte[] bytes,out int match,out int sequence,out int ack)
        {
            if(bytes.Length<2||bytes.Length>Wire.MaxFrame||bytes[0]!=(byte)Packet.Snapshot)throw new InvalidDataException("Snapshot header");
            using(var packed=new MemoryStream(bytes,1,bytes.Length-1))using(var z=new DeflateStream(packed,CompressionMode.Decompress))using(var raw=new MemoryStream())
            {
                byte[] buf=new byte[8192];int n;while((n=z.Read(buf,0,buf.Length))>0){if(raw.Length+n>Wire.MaxInflated)throw new InvalidDataException("Inflated limit");raw.Write(buf,0,n);}raw.Position=0;
                using(var r=new BinaryReader(raw,Encoding.UTF8,true))
                {
                    match=r.ReadInt32();sequence=r.ReadInt32();ack=r.ReadInt32();int stage=r.ReadInt32();if(stage<0||stage>=Arena.Count)throw new InvalidDataException("Stage");
                    var w=new World((Job)Wire.JobId(r),(Job)Wire.JobId(r),stage,1);ReadFields(r,w,worlds);
                    for(int i=0;i<2;i++){ReadFields(r,w.Players[i],fighters);if(w.Players[i].Id!=i||(int)w.Players[i].Job<0||(int)w.Players[i].Job>=Roster.All.Length)throw new InvalidDataException("Fighter identity");w.RemoteReturn[i]=r.ReadBoolean();w.RemoteIntercept[i]=r.ReadBoolean();}
                    w.Effects.Clear();n=Count(r,4096);for(int i=0;i<n;i++){var e=new Effect();ReadFields(r,e,effects);if(r.ReadBoolean()){e.Hit=new Hit();ReadFields(r,e.Hit,hits);}if(e.Owner<0||e.Owner>1)throw new InvalidDataException("Effect owner");w.Effects.Add(e);}
                    w.Cues.Clear();n=Count(r,4096);for(int i=0;i<n;i++){var c=new Cue();ReadFields(r,c,cues);if(c.Owner<0||c.Owner>1)throw new InvalidDataException("Cue owner");w.Cues.Add(c);}
                    Wire.End(r);w.RemoteView=true;return w;
                }
            }
        }
    }
}
