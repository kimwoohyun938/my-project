using System;
using StickmanBrawler.Core;
namespace StickmanBrawler.Online
{
    // Presentation only. These positions must never be passed back into World.Tick.
    public sealed class ViewPresentation
    {
        readonly V2[] from=new V2[2],target=new V2[2];World last;float elapsed=1;int match=-1;
        public void Update(World view,int matchId,float delta)
        {
            if(view==null)return;
            if(!object.ReferenceEquals(last,view))
            {
                for(int i=0;i<2;i++)
                {
                    V2 previous=V2.Lerp(from[i],target[i],elapsed*30);target[i]=view.Players[i].Pos;
                    var f=view.Players[i];bool snap=last==null||match!=matchId||view.Phase!=Phase.Fight||V2.Distance(previous,target[i])>2.5f||view.InHitstop(f)||f.RootUntil>view.Time||f.Dead;
                    from[i]=snap?target[i]:previous;
                }
                last=view;match=matchId;elapsed=0;
            }
            elapsed+=Math.Max(0,delta);
        }
        public V2 Position(int id,Controls local,int localSeat,bool anticipation,double pingMs)
        {
            if(last==null)return new V2();var f=last.Players[id];V2 p=V2.Lerp(from[id],target[id],elapsed*30);
            // A deliberately bounded visual lead, not hit/skill prediction or rollback.
            if(!local.Guard&&!last.IsGuarding(f)&&anticipation&&id==localSeat&&last.Phase==Phase.Fight&&f.Grounded&&!last.InHitstop(f)&&!last.InHitstun(f)&&f.StunUntil<=last.Time&&f.FreezeUntil<=last.Time&&!(f.PowerJob==Job.TimeMurder&&f.BuffUntil>last.Time&&f.InvulnUntil>last.Time)&&f.RootUntil<=last.Time&&f.CastUntil<=last.Time&&f.RecoilUntil<=last.Time&&f.UltimateCastingUntil<=last.Time)
            {
                float lead=(float)Math.Min(.08,Math.Max(0,pingMs/2000+.016));p.x+=local.Move*f.Def.Speed*lead;
                foreach(var e in last.Effects)if(e.Shape==Shape.Wall&&!e.Dead&&Math.Abs(p.y-e.Pos.y)<e.Height/2+f.HalfHeight(last.Time)&&Math.Abs(p.x-e.Pos.x)<e.Width/2+f.Radius(last.Time))p=target[id];
                if(last.Arena.Closed)p.x=Rules.Clamp(p.x,last.Arena.Left+f.Radius(last.Time),last.Arena.Right-f.Radius(last.Time));
            }
            return p;
        }
    }
}
