using System;
using UnityEngine;
using StickmanBrawler.Core;
namespace StickmanBrawler
{
    public sealed partial class BrawlerApp
    {
        static readonly string[] ModeNames={"기본 대전","연속 대전","훈련 · 고정 허수아비","훈련 · 복귀 허수아비","2대2 팀전","4인 개인 난투","캐릭터 릴레이","3인 개인전","협동 보스전","이벤트 · DPS 대전"};
        string ModeLabel {get{return ModeNames[mode];}}
        bool ThreeHumans {get{return mode==(int)BattleMode.ThreeWay;}}
        int HumanCount {get{return OnlineActive?1:ThreeHumans?3:SoloMatch?1:2;}}
        int SelectableSeats {get{return ThreeHumans?3:FourPlayers?4:2;}}
        KeyCode GameKey(int player,int key){return ThreeHumans?trioKeys[player,key]:keys[player,key];}
        bool FourPlayers {get{return mode==(int)BattleMode.Teams||mode==(int)BattleMode.FreeForAll;}}
        bool SoloMatch {get{return solo||mode==(int)BattleMode.TrainingFixed||mode==(int)BattleMode.TrainingRespawn;}}
        int HumanSeat(int controller){return OnlineActive?(controller==0?online.LocalSeat:1-online.LocalSeat):ThreeHumans?controller:humanRight?1-controller:controller;}
        int ControllerFor(int seat){if(OnlineActive)return seat==online.LocalSeat?0:-1;if(ThreeHumans)return seat<3?seat:-1;if(seat==HumanSeat(0))return 0;if(!SoloMatch&&seat==HumanSeat(1))return 1;return -1;}
        string SeatLabel(int seat){if(OnlineActive)return (seat==online.LocalSeat?"나":"상대")+" ["+(seat+1)+"P]";if(mode==(int)BattleMode.BossRaid&&seat==2)return "보스";if(mode==(int)BattleMode.DpsEvent&&seat>=2)return "허수아비 "+(seat-1);int c=ControllerFor(seat);return (c<0?"CPU":"P"+(c+1))+" ["+(seat+1)+"]";}
        Job ResolveJob(int index){return (Job)(index>=Roster.All.Length?UnityEngine.Random.Range(0,Roster.All.Length):index);}
        int SeatJob(int seat){return seat==0?p1:seat==1?p2:seat==2?p3:p4;}
        void SetSeatJob(int seat,int job){if(seat==0)p1=job;else if(seat==1)p2=job;else if(seat==2)p3=job;else p4=job;}
        void ModeMenuOptions()
        {
            bool practice=mode==(int)BattleMode.TrainingFixed||mode==(int)BattleMode.TrainingRespawn;
            if(Button(new Rect(40,543,310,36),ModeLabel+"  >",Gold,14)){mode=(mode+1)%ModeNames.Length;selectedPlayer=0;if(mode==(int)BattleMode.BossRaid||mode==(int)BattleMode.DpsEvent)stage=Math.Max(3,stage);}
            if(Button(new Rect(366,543,260,36),ThreeHumans?"사람 3명 · 전용 조작":practice?"1P + 허수아비":SoloMatch?"사람 1명 + CPU":"사람 2명",Team[0],13)&&!ThreeHumans)solo=!solo;
            if(Button(new Rect(642,543,286,36),ThreeHumans?"3인전: 자리 고정":mode==(int)BattleMode.Teams&&teamCoop?(humanRight?"1P: 팀 내 자리 2":"1P: 팀 내 자리 1"):humanRight?"1P: 오른쪽 자리":"1P: 왼쪽 자리",Team[1],13)&&!ThreeHumans)humanRight=!humanRight;
            string goal=mode==(int)BattleMode.DpsEvent?"제한시간 "+eventDuration+"초":mode==(int)BattleMode.BossRaid?"보스 HP 12000 · 팀 목숨 6":practice?"훈련: 점수 없음":mode==(int)BattleMode.Classic?"기본 대전: 5점 선취":killGoal==0?"점수 제한 없음":killGoal+"점 선취";
            if(Button(new Rect(944,543,296,36),goal,Gold,13))
            {if(mode==(int)BattleMode.DpsEvent)eventDuration=eventDuration==30?60:eventDuration==60?90:30;else if(!practice&&mode!=(int)BattleMode.Classic&&mode!=(int)BattleMode.BossRaid)killGoal=killGoal==5?10:killGoal==10?0:5;}
            if(Button(new Rect(40,589,440,36),Arena.Create(stage).Name+"  >",Muted,13))stage=mode==(int)BattleMode.BossRaid||mode==(int)BattleMode.DpsEvent?3+(stage-3+1)%3:(stage+1)%Arena.Count;
            if(mode==(int)BattleMode.Teams)
            {if(Button(new Rect(496,589,744,36),teamCoop?"협동: 자리 1·2 vs 3·4 (아군 피해 없음)":"대결: 자리 1·3 vs 2·4 (아군 피해 없음)",Gold,13))teamCoop=!teamCoop;}
            else Text(new Rect(496,589,744,36),mode==(int)BattleMode.BossRaid?"사람 2명 또는 사람 + CPU · 예고를 보고 보스 공격 회피":mode==(int)BattleMode.DpsEvent?"전용 허수아비 2개 · 누적 피해와 평균 DPS 비교":mode==(int)BattleMode.Draft?"한쪽이 쓰러지면 둘 다 미사용 직업 재선택":mode==(int)BattleMode.Classic?"기존 라운드 규칙 · 한 키보드로 대전":"처치 후에도 생존자 상태 유지 · 준비 카운트 없이 복귀",13,Muted,TextAnchor.MiddleCenter);
            if(Button(new Rect(40,643,1200,46),"경기 시작    [ ENTER ]",Team[0],22))StartMatch();
            Text(new Rect(40,696,1100,20),"훈련: H 체력·게이지 충전 / Backspace 초기화   |   ESC 일시정지",11,Muted);
            Text(new Rect(1100,696,140,20),"v2.4.1",11,Gold,TextAnchor.MiddleRight);
        }
        void ResolveCpuPicks()
        {foreach(var f in world.Players)if(f.AwaitingPick&&ControllerFor(f.Id)<0)world.SelectCpuReplacement(f.Id);}
        void DraftSelectionUI()
        {
            Fighter pick=null;foreach(var f in world.Players)if(f.AwaitingPick){pick=f;break;}if(pick==null)return;
            Box(new Rect(0,0,1280,720),new Color(.01f,.02f,.04f,.97f));
            Text(new Rect(70,34,1140,55),SeatLabel(pick.Id)+" · 다음 캐릭터 선택",30,Team[pick.Id],TextAnchor.MiddleCenter,true);
            Text(new Rect(70,91,1140,40),"둘 다 미사용 직업을 고릅니다. 양쪽 선택이 끝날 때까지 전투 시간은 멈춥니다.",16,Muted,TextAnchor.MiddleCenter);
            int available=0;
            for(int i=0;i<Roster.All.Length;i++)
            {
                bool used=world.UsedJob(pick.Id,(Job)i);if(!used)available++;
                Rect rect=new Rect(60+(i%10)*116,148+(i/10)*75,110,64);
                if(used){Box(rect,Panel);Text(rect,Roster.All[i].Name+"\n사용 완료",13,Muted,TextAnchor.MiddleCenter);}
                else if(Button(rect,Roster.All[i].Name,Team[pick.Id],14)){world.SelectNextJob(pick.Id,(Job)i);pendingA=pendingB=pendingC=new Controls();accumulator=0;Sound(selectSound);return;}
            }
            if(available==0)Text(new Rect(70,610,1140,40),"남은 캐릭터가 없습니다.",18,Gold,TextAnchor.MiddleCenter);
            if(Button(new Rect(440,646,400,42),"메인 메뉴로")){menu=true;paused=false;}
        }
        string ScoreSummary()
        {
            if(world.Mode==BattleMode.DpsEvent)return "P1 "+world.EventDamage[HumanSeat(0)].ToString("0")+" (DPS "+world.EventDps(HumanSeat(0)).ToString("0.0")+") / P2 "+world.EventDamage[HumanSeat(1)].ToString("0")+" (DPS "+world.EventDps(HumanSeat(1)).ToString("0.0")+")";
            if(world.Mode==BattleMode.BossRaid)return "보스 HP "+Mathf.CeilToInt(world.Players[2].HP)+" · 팀 목숨 "+world.BossLivesRemaining;
            if(world.Mode==BattleMode.Teams)return "팀 1  "+world.TeamScores[0]+"  :  "+world.TeamScores[1]+"  팀 2";
            string result="";foreach(var f in world.Players){if(result.Length>0)result+="   /   ";result+=SeatLabel(f.Id)+" "+f.Score;}return result;
        }
        void MultiHUD()
        {
            if(world.Mode==BattleMode.DpsEvent){EventHUD();return;}
            foreach(var f in world.Players)
            {
                float x=(world.Players.Length==3?171:12)+f.Id*318;Color color=Team[f.Id];Box(new Rect(x,14,306,108),Alpha(Ink,.94f));
                Text(new Rect(x+8,17,290,25),SeatLabel(f.Id)+" · "+(f.IsBoss?"철갑 투사":f.Def.Name),16,color,TextAnchor.MiddleLeft,true);
                Text(new Rect(x+8,43,290,21),world.Mode==BattleMode.Teams?"팀 "+(f.TeamId+1)+" · 개인 처치 "+f.Score:"처치 "+f.Score,12,Muted);
                Box(new Rect(x+8,69,290,10),Panel);Box(new Rect(x+8,69,290*HealthTrail(f),10),new Color(1,.65f,.25f));Box(new Rect(x+8,69,290*Mathf.Clamp01(f.HP/f.MaxHP),10),color);
                Text(new Rect(x+8,84,290,27),f.Dead?"복귀까지 "+Mathf.Max(0,f.RespawnAt-world.Time).ToString("0.0")+"초":"HP "+Mathf.CeilToInt(f.HP)+" · 궁 "+Mathf.FloorToInt(f.Gauge)+"% · 타깃 "+(world.Enemy(f).Id+1),11,color);
            }
            Text(new Rect(190,128,900,25),ModeLabel+" · "+ScoreSummary(),15,Gold,TextAnchor.MiddleCenter,true);
            for(int controller=0;controller<HumanCount;controller++)
            {
                Fighter f=world.Players[HumanSeat(controller)];float x=ThreeHumans?20+controller*422:controller==0?30:750;float[] cd={f.QAt,f.EAt,0};string[] names={f.Def.QName,f.Def.EName,f.Def.RName};
                for(int slot=0;slot<3;slot++)
                {
                    bool locked=f.SlotLockedUntil[slot+1]>world.Time||f.SilenceUntil>world.Time||(slot<2&&f.SkillLockUntil>world.Time);
                    string state=locked?"봉쇄":f.Dead?"복귀 중":cd[slot]>world.Time?(cd[slot]-world.Time).ToString("0.0")+"초":slot==2&&f.Gauge<100?"충전 중":"준비";
                    Rect rect=new Rect(x+slot*(ThreeHumans?134:158),610,ThreeHumans?128:150,54);Box(rect,Panel);Text(new Rect(rect.x+7,rect.y+4,ThreeHumans?116:136,21),GameKey(controller,slot+4)+" · "+state,12,Team[f.Id]);Text(new Rect(rect.x+7,rect.y+25,ThreeHumans?116:136,25),names[slot],10,Muted);
                }
            }
        }
    }
}
