using System;
using StickmanBrawler.Core;
namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static World ModeReady(BattleMode mode,bool coop=false)
        {
            Job[] jobs=mode==BattleMode.Teams||mode==BattleMode.FreeForAll?new[]{Job.Knight,Job.Knight,Job.Knight,Job.Knight}:new[]{Job.Knight,Job.Knight};
            var w=new World(jobs,new MatchOptions{Mode=mode,KillLimit=5,TeamCoop=coop},0,1337);w.Phase=Phase.Fight;
            foreach(var f in w.Players){f.InvulnUntil=0;f.Grounded=true;f.Pos=new V2((f.Id-1)*2,.9f);}return w;
        }
        static void ModeTests()
        {
            var w=ModeReady(BattleMode.Continuous);var f=w.Players[0];var foe=w.Players[1];
            f.HP=432;f.Gauge=62;f.QAt=10;f.FormUntil=20;
            var field=new Effect{Owner=0,Shape=Shape.Zone,Pos=new V2(0,6),Radius=1,Expires=30};w.Effects.Add(field);
            w.ApplyHit(foe,new Hit{Owner=0,Damage=2000,TrueDamage=true,Knock=0,Stun=0});w.Tick(new Controls(),new Controls());
            Check(w.Phase==Phase.Fight,"continuous KO does not start a new round");Check(foe.Dead,"only defeated fighter waits for respawn");
            Near(f.HP,432,"survivor health retained");Near(f.QAt,10,"survivor cooldown retained");Near(f.FormUntil,20,"survivor transformation retained");Check(w.Effects.Contains(field),"survivor field retained");
            Check(f.Score==1,"continuous kill awarded");Frames(w,41);Check(!foe.Dead,"defeated fighter auto returns");Near(foe.HP,1000,"respawn full health");Near(f.HP,432,"survivor still not healed by respawn");
            w=ModeReady(BattleMode.TrainingFixed);foe=w.Players[1];
            w.ApplyHit(foe,new Hit{Owner=0,Damage=9999,TrueDamage=true,Knock=99,Stun=0});Near(foe.HP,1000,"fixed dummy never loses its health pool");Near(w.LastDamage,9999,"fixed dummy records full damage");
            foe.Pos=new V2(100,-100);w.Tick(new Controls(),new Controls());Near(foe.Pos.x,w.SpawnPosition(1).x,"fixed dummy anchored");Check(!foe.Dead&&w.Players[0].Score==0,"fixed dummy does not score");
            w=ModeReady(BattleMode.TrainingRespawn);foe=w.Players[1];foe.Pos=new V2(0,-30);w.Tick(new Controls(),new Controls());Check(foe.Dead,"return dummy can ring out");Frames(w,23);Check(!foe.Dead&&foe.HP==1000,"return dummy comes back automatically");Check(w.Players[0].Score==0,"training has no scoring");
            w=ModeReady(BattleMode.Teams);Check(w.Opponents(0,1)&&!w.Opponents(0,2),"opposing team layout");
            Check(!w.ApplyHit(w.Players[2],Strike(0)),"friendly fire rejected");Check(w.ApplyHit(w.Players[3],Strike(0)),"third enemy slot takes damage");
            foreach(var p in w.Players){p.Pos=new V2(p.Id==0?0:2,.9f);p.InvulnUntil=0;p.Vel=new V2();Hold(p);}
            w.Players[0].Facing=1;float before1=w.Players[1].HP,before3=w.Players[3].HP;
            w.Effects.Add(new Effect{Owner=0,Shape=Shape.Beam,Pos=new V2(0,.9f),Vel=new V2(1,0),Width=12,Height=3,Expires=w.Time+.2f,Hit=new Hit{Owner=0,Damage=50,Knock=0,Stun=0}});
            w.Tick(new Controls[4]);Near(w.Players[1].HP,before1-50,"beam hits first opponent");Near(w.Players[3].HP,before3-50,"same beam hits second opponent");Near(w.Players[2].HP,1000,"beam spares ally");
            w.Tick(new Controls[4]);Near(w.Players[1].HP,before1-50,"beam cannot duplicate same victim hit");
            w=ModeReady(BattleMode.Teams,true);Check(!w.Opponents(0,1)&&w.Opponents(0,2),"cooperative team layout");
            w=ModeReady(BattleMode.FreeForAll);Check(w.Opponents(0,1)&&w.Opponents(0,2)&&w.Opponents(0,3),"FFA everyone is an opponent");
            w.ApplyHit(w.Players[1],new Hit{Owner=2,Damage=2000,TrueDamage=true,Stun=0,Knock=0});w.Tick(new Controls[4]);Check(w.Players[2].Score==1&&w.Players[0].Score==0,"FFA correct killer gets score");
            w.Players[3].Pos=new V2(0,-40);w.Tick(new Controls[4]);Check(w.Players[2].Score==1,"unassisted fall awards no random FFA killer");
            w=ModeReady(BattleMode.Draft);f=w.Players[0];f.HP=650;f.Gauge=40;w.Players[1].HP=0;w.Tick(new Controls(),new Controls());
            Check(w.NeedsSelection,"relay requests both fighter picks");float time=w.Time;Frames(w,10);Near(w.Time,time,"relay pick freezes game clock");
            Check(!w.SelectNextJob(1,Job.Knight),"relay rejects used character");Check(w.SelectNextJob(1,Job.Archer),"relay accepts unused character");
            Check(w.NeedsSelection,"relay waits for winner choice too");Check(!w.SelectNextJob(0,Job.Knight),"winner cannot reuse previous job");Check(w.SelectNextJob(0,Job.Samurai),"winner chooses unused job");Check(!w.NeedsSelection&&w.Phase==Phase.Fight,"relay resumes after both picks without countdown");Near(w.Players[0].HP,950,"relay new character starts at full health");Check(w.UsedJob(1,Job.Archer)&&w.UsedJob(1,Job.Knight),"relay remembers both used jobs");
            w=ModeReady(BattleMode.Continuous);w.Options.KillLimit=1;w.ApplyHit(w.Players[1],new Hit{Owner=0,Damage=2000,TrueDamage=true,Knock=0,Stun=0});w.Tick(new Controls(),new Controls());Check(w.Phase==Phase.Finished&&w.Winner==0,"continuous match ends at selected limit");
            w=ModeReady(BattleMode.Teams);w.Options.KillLimit=1;
            w.ApplyHit(w.Players[1],new Hit{Owner=0,Damage=2000,TrueDamage=true,Knock=0,Stun=0});w.ApplyHit(w.Players[0],new Hit{Owner=1,Damage=2000,TrueDamage=true,Knock=0,Stun=0});w.Tick(new Controls[4]);Check(w.Phase==Phase.Fight&&w.SuddenDeath,"simultaneous team tie does not pick by iteration order");
            w=ModeReady(BattleMode.FreeForAll);for(int i=0;i<4;i++){w.Players[i].CyberMarks[(i+1)%4]=4;w.Players[i].FrostHits[3]=2;}w.ResetRound();foreach(var p in w.Players)Check(p.CyberMarks[3]==0&&p.FrostHits[3]==0,"all four mark slots reset");

            foreach(var definition in Roster.All)foreach(int seat in new[]{2,3})for(int slot=0;slot<4;slot++)
            {
                Job[] jobs={Job.Knight,Job.Knight,Job.Knight,Job.Knight};jobs[seat]=definition.Job;
                w=new World(jobs,new MatchOptions{Mode=BattleMode.FreeForAll,KillLimit=0},3,733);w.Phase=Phase.Fight;
                foreach(var actor in w.Players){actor.InvulnUntil=0;actor.Pos=new V2(actor.Id,.9f);actor.Gauge=100;}
                f=w.Players[seat];foe=w.Enemy(f);f.YangSwords=3;foe.QinMarkOwner=seat;foe.MarkUntil=10;foe.DinoMarkOwner=seat;foe.DinoMarkUntil=10;foe.ShadowMarks[seat]=3;foe.CyberMarks[seat]=4;
                var controls=new Controls[4];controls[seat]=new Controls(0,false,slot==0,slot==1,slot==2,slot==3);w.Tick(controls);
                for(int tick=0;tick<100;tick++)w.Tick(new Controls[4]);
                foreach(var actor in w.Players)Check(!float.IsNaN(actor.HP)&&!float.IsNaN(actor.Pos.x)&&!float.IsNaN(actor.Pos.y),"4P finite state "+definition.Job+" seat "+seat+" slot "+slot);
            }
        }
    }
}
