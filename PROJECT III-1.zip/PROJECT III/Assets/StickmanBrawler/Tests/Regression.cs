using System;
using System.Collections.Generic;
using StickmanBrawler.Core;

namespace StickmanBrawler.Tests
{
    // Executable in Unity (Tools > Stickman Brawler > Run Core Tests) or .NET 8.
    // No Unity dependencies or test-framework downloads.
    public static partial class Regression
    {
        static int passed;
        static void Check(bool ok,string message) { if(!ok)throw new Exception("FAIL: "+message);passed++; }
        static void Near(float actual,float expected,string message,float eps=.02f) { Check(Math.Abs(actual-expected)<eps,message+" actual="+actual+" expected="+expected); }
        // Legacy skill arithmetic fixture excludes contact stop; the dedicated
        // reaction suite and multi-player suites exercise the production default.
        static World Ready(Job a=Job.Knight,Job b=Job.Knight)
        { var w=new World(a,b,0,771);w.ContactStopEnabled=false;w.Phase=Phase.Fight;foreach(var f in w.Players){f.InvulnUntil=0;f.Pos=new V2(f.Id==0?-1:1,.9f);f.Grounded=true;}return w; }
        static Hit Strike(int owner=0,float damage=100)
        { return new Hit{Owner=owner,Damage=damage,Knock=8,Stun=0,Direction=new V2(1,.2f)}; }
        static void Frames(World w,int count,Controls a=new Controls(),Controls b=new Controls())
        { for(int i=0;i<count;i++){w.Tick(a,b);a.ClearEdges();b.ClearEdges();} }
        public static string RunAll()
        {
            passed=0;
            var w=Ready();w.ApplyHit(w.Players[1],Strike());Near(w.Players[1].HP,900,"normal damage");Check(w.Players[1].Vel.x>0,"knockback direction");
            var weak=Ready();weak.Players[1].HP=200;weak.ApplyHit(weak.Players[1],Strike());Check(weak.Players[1].Vel.Length>w.Players[1].Vel.Length,"low HP increases knockback");
            w=Ready();w.Players[1].InvulnUntil=5;Check(!w.ApplyHit(w.Players[1],Strike()),"invulnerability rejects hit");Near(w.Players[1].HP,1000,"invulnerability HP");
            w.Players[1].Pos.x=w.Arena.Right+1;w.Tick(new Controls(),new Controls());Check(w.Players[1].Dead&&w.Players[0].Score==1,"blast zone bypasses invulnerability");
            w=Ready();w.Control(w.Players[0],CC.Root,1);V2 start=w.Players[0].Pos;Frames(w,12,new Controls(1,true,true));Near(w.Players[0].Pos.x,start.x,"root holds x");Near(w.Players[0].Pos.y,start.y,"root holds y");Check(w.Players[0].AttackAt>0,"root permits attack");
            w=Ready();w.Control(w.Players[0],CC.Stun,.8f);Frames(w,10,new Controls(1,true,true,true,true,true));Near(w.Players[0].AttackAt,0,"stun blocks attack");Near(w.Players[0].QAt,0,"stun blocks skills");
            w=Ready();Fighter f=w.Players[0];w.Control(f,CC.Stun,1);Near(f.StunUntil,1,"first stun duration");f.StunUntil=0;w.Control(f,CC.Stun,1);Near(f.StunUntil,1,"second stun keeps original duration");f.StunUntil=0;w.Control(f,CC.Stun,1);Near(f.StunUntil,1,"third stun keeps original duration");f.StunUntil=0;w.Control(f,CC.Stun,1);Near(f.StunUntil,1,"no added fourth-stun immunity");
            w=Ready();f=w.Players[0];f.Gauge=100;w.Control(f,CC.Silence,1);w.Tick(new Controls(0,false,false,true,true,true),new Controls());Near(f.Gauge,100,"silence blocks ultimate");Near(f.QAt,0,"silence blocks skill");w.Tick(new Controls(0,false,true),new Controls());Check(f.AttackAt>0,"silence allows basic attack");
            w=Ready(Job.Master);f=w.Players[0];f.HP=200;f.Gauge=100;w.Control(f,CC.SkillLock,1);w.Tick(new Controls(0,false,false,false,false,true),new Controls());Check(f.Gauge<1,"Q/E lock allows R");
            w=Ready(Job.Knight,Job.Reflector);w.Players[1].ParryUntil=1;w.ApplyHit(w.Players[1],Strike());Near(w.Players[1].HP,1300,"parry prevents damage");Near(w.Players[0].HP,900,"parry reflects once");Near(w.Players[1].QAt,w.Time,"parry success resets cooldown");
            w=Ready(Job.Reflector,Job.Reflector);w.Players[0].ReflectUntil=w.Players[1].ReflectUntil=3;w.ApplyHit(w.Players[1],Strike());Near(w.Players[0].HP,1200,"reflection does not recurse");Near(w.Players[1].HP,1300,"reflection target preserved");
            w=Ready(Job.Knight,Job.Guardian);w.Players[1].ReflectUntil=3;w.ApplyHit(w.Players[1],Strike());Near(w.Players[0].HP,960,"guardian reflects post-mitigation 40 percent");
            w=Ready();f=w.Players[0];f.HP=500;f.LastHitAt=w.Time;w.Heal(f,100);Near(f.HP,600,"combat healing restored in full");w.SuddenDeath=true;w.Heal(f,500);Near(f.HP,600,"sudden death blocks heal");f.HP=0;w.Heal(f,500);Near(f.HP,0,"heal cannot revive");
            w=Ready();w.Players[0].HP=w.Players[1].HP=0;w.Tick(new Controls(),new Controls());Check(w.Players[0].Score==1&&w.Players[1].Score==1,"simultaneous KO awards both");
            w=Ready();w.Players[0].Score=w.Players[1].Score=4;w.Players[0].HP=w.Players[1].HP=0;w.Tick(new Controls(),new Controls());Check(w.SuddenDeath&&w.Phase==Phase.RoundOver,"simultaneous fifth KO enters sudden death");
            w=Ready();w.Players[0].Score=4;w.Players[1].HP=0;w.Tick(new Controls(),new Controls());Check(w.Winner==0&&w.Phase==Phase.Finished,"first to five finishes match");float frozen=w.Time;Frames(w,60,new Controls(1,true,true,true,true,true));Near(w.Time,frozen,"finished match cannot advance");
            w=Ready();w.Players[0].Gauge=90;w.Players[0].RootUntil=50;w.Players[0].Overclock=true;w.ResetRound();Near(w.Players[0].Gauge,50,"round gauge carry cap");Near(w.Players[0].RootUntil,0,"round clears control");Check(!w.Players[0].Overclock&&w.Effects.Count==0,"round clears effects and toggles");
            w=Ready(Job.TimeMurder);w.Players[0].HP=5;w.Players[0].Overclock=true;Frames(w,40);Near(w.Players[0].HP,0,"overclock HP cost can reach zero");Check(!w.Players[0].Overclock,"overclock stops on KO");
            w=Ready(Job.Lancer);w.Tick(new Controls(0,false,false,true),new Controls());Check(!w.Players[0].HasSpear,"throw detaches spear");w.Tick(new Controls(0,false,false,true),new Controls());Check(!w.Players[0].HasSpear,"recall waits three seconds after throw");
            w=Ready(Job.Depth);f=w.Players[0];f.Gauge=100;w.Tick(new Controls(0,false,false,false,true,true),new Controls());Near(f.Gauge,100,"mark prerequisite prevents gauge spend");Near(f.EAt,0,"invalid teleport does not spend cooldown");
            w=Ready();w.Players[0].Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),new Controls());Check(w.Players[0].CastUntil>0,"charge starts");Hold(w.Players[1]);w.Control(w.Players[0],CC.Stun,.1f);Frames(w,110);Near(w.Players[1].HP,520,"stun cannot cancel protected beam charge");
            w=Ready(Job.Hassan);f=w.Players[0];f.Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),new Controls());Frames(w,42);Check(w.Players[1].DoomAt>0,"sigil applies after tell");w.ApplyHit(f,Strike(1,150));Frames(w,2);Check(w.Players[1].DoomAt>0,"150 damage no longer breaks sigil");
            w=Ready(Job.Cross);f=w.Players[0];f.HP=500;f.LastHitAt=w.Time;Frames(w,60);Near(f.HP,510,"Cross regenerates 10 HP/s during combat",.05f);
            w=Ready();w.Players[0].Vel=new V2(0,-40);w.Players[0].Pos=new V2(0,1);Frames(w,3);Check(w.Players[0].Pos.y>=.89f,"descending platform collision");
            w=Ready(Job.Vertebrate);f=w.Players[0];f.Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),new Controls());Frames(w,15);Check(f.Grounded&&f.Pos.y>=1.48f,"giant form preserves grounded feet");
            w=Ready();w.Players[1].BuffUntil=3;w.ApplyHit(w.Players[1],Strike());Near(w.Players[1].HP,950,"Knight original 50 percent damage guard");
            w=Ready(Job.King);f=w.Players[0];f.Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),new Controls());Check(f.Gauge<1&&f.CastUntil>w.Time,"King ultimate available at zero enemy score");
            w=Ready(Job.Master);f=w.Players[0];f.Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),new Controls());Near(f.Gauge,100,"Master ultimate blocked above 40 percent HP");f.HP=400;w.Tick(new Controls(0,false,false,false,false,true),new Controls());Check(f.Gauge<1,"Master ultimate unlocked at 40 percent HP");
            w=Ready(Job.King);f=w.Players[0];w.Tick(new Controls(0,false,false,true),new Controls());Near(f.HP,925,"King Q costs 75 HP");Near(f.Gauge,40+Rules.Dt*Rules.PassiveGaugePerSecond,"King Q restores 40 gauge");
            w=Ready(Job.Guardian);f=w.Players[0];f.Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),new Controls());float before=f.HP;w.Tick(new Controls(0,false,true),new Controls());w.ApplyHit(f,Strike(1));Near(f.HP,before,"Guardian ultimate invulnerability survives attack input");
            w=Ready();w.Control(w.Players[0],CC.Stun,3);Near(w.Players[0].StunUntil,3,"three second stun is not capped");
            w=Ready();w.Control(w.Players[0],CC.Root,3);Near(w.Players[0].RootUntil,3,"three second root is not capped");
            w=Ready(Job.Hassan);f=w.Players[0];w.Players[1].DoomAt=.2f;w.Players[1].Pos=new V2(10,.9f);Frames(w,16);Check(w.Players[1].Dead,"sigil triggers 9999 damage despite separation");
            w=Ready(Job.Hassan);w.Players[1].DoomAt=.01f;w.Players[0].HP=0;Frames(w,1);Near(w.Players[1].HP,1000,"caster KO cancels sigil");
            ArsenalTests();
            NavalTests();
            V14Tests();
            FortuneDinoTests();
            ExpansionTests();
            V2Tests();TimingCyberTests();ModeTests();SpecialModeTests();HitReactionTests();
            // Every character: basic, Q, E and R smoke simulation from fresh state.
            foreach(Definition d in Roster.All)
            {
                Check(d.HP>0&&d.AttackInterval>0&&d.QCooldown>0&&d.ECooldown>0,"valid roster "+d.Name);
                for(int slot=0;slot<4;slot++)
                {
                    w=Ready(d.Job);f=w.Players[0];f.Gauge=100;w.Players[1].MarkUntil=10;w.Players[1].QinMarkOwner=0;w.Players[1].EmbeddedBlades[0]=2;if(d.Job==Job.King)w.Players[1].Score=3;if(d.Job==Job.Master)f.HP=200;
                    if(d.Job==Job.ShadowClone)w.Players[1].ShadowMarks[0]=3;
                    if(d.Job==Job.Institutor)f.YangSwords=7;
                    if(d.Job==Job.DinoMan){w.Players[1].DinoMarkOwner=0;w.Players[1].DinoMarkUntil=10;}
                    Controls c=new Controls(0,false,slot==0,slot==1,slot==2,slot==3);w.Tick(c,new Controls());Frames(w,240);
                    Check(!float.IsNaN(f.HP)&&!float.IsNaN(f.Pos.x)&&!float.IsNaN(f.Pos.y),"finite state "+d.Name+" slot "+slot);
                    Check(w.Effects.Count<150,"bounded effects "+d.Name+" slot "+slot);
                }
            }
            return passed+" assertions passed. These are engine regression tests, not a multiplayer balance study.";
        }
    }
}
