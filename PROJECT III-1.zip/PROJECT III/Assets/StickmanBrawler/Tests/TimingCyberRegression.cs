using System;
using StickmanBrawler.Core;
namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static void TimingCyberTests()
        {
            Near(Roster.Get(Job.LTiming).AttackInterval,.65f,"timing basic interval");
            Near(Roster.Get(Job.Cybercrud).AttackInterval,.8f,"code basic interval");
            int[] expected={3000,1700,1600,1000,900,1000,800};int[] counts=new int[7];
            for(int i=0;i<10000;i++)counts[World.CyberCodeIndex((i+.5f)/10000f)]++;
            for(int i=0;i<7;i++)Check(counts[i]==expected[i],"exact code probability bucket "+i);
            var w=Ready(Job.Cybercrud);var f=w.Players[0];var foe=w.Players[1];
            w.Tick(Q,new Controls());Check(w.InsideCyberZone(f),"zone protects owner inside");
            Check(!w.ApplyHit(f,Strike(1)),"zone blocks basic from outside");
            var ult=Strike(1);ult.Ultimate=true;Check(w.ApplyHit(f,ult),"zone does not block ultimate");
            f.Pos=new V2(10,.9f);Check(!w.InsideCyberZone(f),"zone stays at cast location");
            Check(w.ApplyHit(f,Strike(1)),"leaving zone removes protection");
            w=Ready(Job.Cybercrud);f=w.Players[0];foe=w.Players[1];
            for(int i=0;i<7;i++)w.ApplyHit(foe,new Hit{Owner=0,Damage=1,Knock=0,Stun=0,Tag="code:return"});
            Check(foe.CyberMarks[0]==4,"death marks cap at four");
            var haste=new Hit{Owner=0,Damage=0,Knock=0,Stun=0,Tag="cyber-throttle",Control=CC.Slow,Duration=4,Slow=.7f};
            w.ApplyHit(foe,haste);Near(foe.CyberSlowUntil-w.Time,4,"throttle attack slow four seconds");Near(f.CyberHasteUntil-w.Time,4,"zero damage hit grants haste");
            w=Ready(Job.Cybercrud);f=w.Players[0];foe=w.Players[1];f.AttackAt=20;
            w.ApplyHit(foe,new Hit{Owner=0,Damage=35,Knock=0,Stun=0,Tag="code:for"});Near(f.AttackAt,w.Time,"for resets attack delay");
            foreach(int marks in new[]{1,2,3,4})
            {
                w=Ready(Job.Cybercrud);f=w.Players[0];foe=w.Players[1];f.Gauge=100;foe.CyberMarks[0]=marks;
                w.Tick(R,new Controls());Check(foe.CyberMarks[0]==0,"ultimate consumes marks "+marks);
                Near(f.CyberUltInterval,marks==1?.6f:marks==2?.5f:.4f,"ultimate attack interval "+marks);
                Near((marks==1?foe.RootUntil:foe.StunUntil)-w.Time,marks==1?2:marks==4?4:3,"ultimate status duration "+marks);
            }
            foreach(int threshold in new[]{150,300})foreach(bool below in new[]{false,true})
            {
                w=Ready(Job.Cybercrud);f=w.Players[0];foe=w.Players[1];f.Gauge=100;foe.CyberMarks[0]=threshold==150?3:4;foe.HP=threshold-(below?1:0);
                w.Tick(R,new Controls());Check((foe.HP<=0)==below,"execute is strictly below "+threshold+" / "+below);
            }
            w=Ready(Job.Cybercrud);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());Near(f.Gauge,100,"no marks no gauge consumption");
            foreach(int side in new[]{0,1})
            {
                w=side==0?Ready(Job.LTiming,Job.YiSunGod):Ready(Job.YiSunGod,Job.LTiming);
                f=w.Players[side];foe=w.Players[1-side];foe.FormUntil=12;
                w.Tick(side==0?new Controls():Q,side==0?Q:new Controls());Near(f.HP,950,"ship laser hits before return");V2 pre=new V2(side==0?-1:1,.9f);
                w.Tick(side==0?Q:new Controls(),side==0?new Controls():Q);
                Near(f.HP,1000,"return heals actual damage player "+side);Near(foe.HP,950,"return exact damage player "+side);
                Near(f.Pos.x,pre.x,"return restores pre-hit x");Near(f.Pos.y,pre.y,"return restores pre-hit y");
                Near(f.QAt-w.Time,8,"successful return cooldown");Check(foe.FormUntil>w.Time,"return does not remove ship form");
            }
            w=Ready(Job.LTiming);f=w.Players[0];w.Tick(Q,new Controls());Near(f.QAt-w.Time,5,"failed return cooldown");
            w=Ready(Job.LTiming,Job.YiSunGod);f=w.Players[0];foe=w.Players[1];foe.FormUntil=12;
            w.Tick(new Controls(),Q);Frames(w,1);w.Tick(Q,new Controls());Near(f.HP,950,"late return does not heal");Near(f.QAt-w.Time,5,"late return failure cooldown");
            foreach(int side in new[]{0,1})
            {
                w=side==0?Ready(Job.LTiming,Job.King):Ready(Job.King,Job.LTiming);f=w.Players[side];foe=w.Players[1-side];
                w.Tick(side==0?new Controls():Q,side==0?Q:new Controls());Near(foe.HP,925,"king cast cost applied");
                w.Tick(side==0?E:new Controls(),side==0?new Controls():E);
                Near(foe.HP,1000,"instant cast cost rolled back");Near(f.HP,925,"copied royal decision executes");
                Near(foe.SlotLockedUntil[1]-w.Time,10,"interception locks exact slot");Near(f.EAt-w.Time,6,"interception cooldown");
            }
            w=Ready(Job.LTiming,Job.King);f=w.Players[0];foe=w.Players[1];w.Tick(new Controls(),Q);
            w.ApplyHit(foe,new Hit{Owner=0,Damage=10,TrueDamage=true,Knock=0,Stun=0});w.Tick(E,new Controls());Near(foe.HP,990,"rollback preserves unrelated later damage");
            w=Ready(Job.LTiming,Job.Knight);f=w.Players[0];foe=w.Players[1];foe.Gauge=100;w.Tick(new Controls(),R);w.Tick(E,new Controls());
            Check(foe.UltimateCastingUntil<=w.Time,"interception cancels protected ultimate charge");
            Check(foe.SlotLockedUntil[3]>w.Time,"interception locks R independently");
            w=Ready(Job.LTiming);f=w.Players[0];f.QAt=8;f.EAt=6;f.Gauge=100;w.Tick(R,new Controls());
            Near(f.QAt-w.Time,(8-w.Time)*.5f,"R halves existing Q remainder");
            f.TimingUltUntil=w.Time+Rules.Dt;f.QAt=w.Time+4;f.EAt=w.Time+2;w.Tick(new Controls(),new Controls());
            Near(f.QAt-w.Time,(4-Rules.Dt)*1.5f,"R expiry Q multiplier");Near(f.EAt-w.Time,(2-Rules.Dt)*1.5f,"R expiry E multiplier");
            w=Ready(Job.LTiming);f=w.Players[0];w.Tick(new Controls(0,false,true),new Controls(0,false,true));Check(f.TimingCritReady,"same tick basic trade arms next hit");
        }
    }
}
