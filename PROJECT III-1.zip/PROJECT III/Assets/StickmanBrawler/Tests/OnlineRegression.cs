using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using StickmanBrawler.Core;
using StickmanBrawler.Online;
namespace StickmanBrawler.Tests
{
 public static class OnlineRegression
 {
  static int checks;static void Check(bool ok,string name){if(!ok)throw new Exception("ONLINE FAIL: "+name);checks++;}
  static void Equal(float a,float b,string name){Check(Math.Abs(a-b)<.00001f,name+" "+a+" / "+b);}
  sealed class Sim:IRoomTransport
  {
   public Sim Peer;public int Tick,Delay;public bool Open=true,Stalled;public string Error{get;private set;}="";
   public bool Connected{get{return Open&&Peer.Open;}}
   public readonly Queue<Tuple<int,byte[]>> Incoming=new Queue<Tuple<int,byte[]>>();
   public bool TryReceive(out byte[] b){if(!Stalled&&Incoming.Count>0&&Incoming.Peek().Item1<=Tick){b=Incoming.Dequeue().Item2;return true;}b=null;return false;}
   public void Send(byte[] b,bool replaceable=false){if(Open&&Peer.Open)Peer.Incoming.Enqueue(Tuple.Create(Peer.Tick+Delay,b));}
   public void Dispose(){Open=false;}
  }
  static void Steps(RoomSession h,RoomSession c,Sim a,Sim b,int count)
  {for(int i=0;i<count;i++){a.Tick++;b.Tick++;h.Pump(Rules.Dt);c.Pump(Rules.Dt);}}
  static void ReadyPair(RoomSession h,RoomSession c,Sim a,Sim b)
  {Steps(h,c,a,b,40);Check(h.State==RoomState.Lobby&&c.State==RoomState.Lobby,"handshake/lobby");h.SetStage(3);h.Choose(0);c.Choose(5);Steps(h,c,a,b,40);h.SetReady(true);c.SetReady(true);Steps(h,c,a,b,200);Check(h.State==RoomState.Playing&&c.State==RoomState.Playing,"ready starts fight");}
  public static string RunAll()
  {
   checks=0;var mailbox=new InputMailbox();var press=new Controls(1,true,true,true);
   Check(mailbox.Push(1,press,0,2),"input accepted");Check(!mailbox.Push(1,press,0,2),"duplicate rejected");Check(!mailbox.Consume(1).Jump,"delay honoured");Check(mailbox.Consume(2).Jump,"edge consumed once");Check(!mailbox.Consume(3).Jump&&mailbox.Consume(3).Attack,"hold survives edge clearing");Check(mailbox.Consume(17).Move==0,"stale held movement neutralized");
   bool rejected=false;try{mailbox.Push(2,new Controls(float.NaN),20,0);}catch(InvalidDataException){rejected=true;}Check(rejected,"NaN input rejected");
   foreach(var def in Roster.All)for(int slot=0;slot<4;slot++)
   {
    var w=new World(def.Job,Job.Knight,3,173);w.Phase=Phase.Fight;foreach(var f in w.Players){f.InvulnUntil=0;f.Pos=new V2(f.Id==0?-1:1,.9f);f.Grounded=true;f.Gauge=100;}
    var actor=w.Players[0];var enemy=w.Players[1];actor.YangSwords=3;enemy.QinMarkOwner=0;enemy.DinoMarkOwner=0;enemy.DinoMarkUntil=99;enemy.MarkUntil=99;enemy.CyberMarks[0]=4;enemy.ShadowMarks[0]=3;
    w.Tick(new Controls(0,false,slot==0,slot==1,slot==2,slot==3),new Controls());
    for(int tick=0;tick<120;tick++)
    {
     w.Tick(new Controls(),new Controls());if(tick!=0&&tick!=15&&tick!=60&&tick!=119)continue;
     int m,s,ack;byte[] packed=ViewCodec.Encode(w,3,7,tick+1,3);var v=ViewCodec.Decode(packed,out m,out s,out ack);
     Check(m==7&&s==tick+1&&ack==3,"snapshot identity "+def.Job);Check(v.RemoteView,"remote view is non-authoritative");
     for(int i=0;i<2;i++){Equal(v.Players[i].HP,w.Players[i].HP,"HP "+def.Job);Equal(v.Players[i].Gauge,w.Players[i].Gauge,"gauge");Equal(v.Players[i].Pos.x,w.Players[i].Pos.x,"x");Equal(v.Players[i].Vel.y,w.Players[i].Vel.y,"knockback");Equal(v.Players[i].QAt,w.Players[i].QAt,"cooldown");Equal(v.Players[i].StunUntil,w.Players[i].StunUntil,"stun");Check(v.Players[i].Score==w.Players[i].Score,"score");}
     Check(v.Effects.Count==w.Effects.Count&&v.Cues.Count==w.Cues.Count,"all effects and cues serialized");
     byte[] roundtrip=ViewCodec.Encode(v,3,7,tick+1,3);Check(Convert.ToBase64String(packed)==Convert.ToBase64String(roundtrip),"all supported fields roundtrip "+def.Job);
     rejected=false;try{v.Tick(new Controls(),new Controls());}catch(InvalidOperationException){rejected=true;}Check(rejected,"client world cannot apply duplicate combat");
    }
   }
   foreach(int delay in new[]{0,3,6,9})
   {
    var a=new Sim{Delay=delay};var b=new Sim{Delay=delay};a.Peer=b;b.Peer=a;
    using(var h=new RoomSession(a,true))using(var c=new RoomSession(b,false))
    {
     ReadyPair(h,c,a,b);Check(c.Authority==null,"client has no authoritative engine");
     float before=h.Authority.Players[1].Pos.x;c.Capture(new Controls(-1,true));Steps(h,c,a,b,30);Check(h.Authority.Players[1].Pos.x<before,"remote input drives host");
     c.ClearLocalInput();Steps(h,c,a,b,30);Check(c.View!=null&&c.View.RemoteView,"client displays server state");
     c.Capture(new Controls(1,true,true,true,true,true){Guard=true});Steps(h,c,a,b,30);
     Check(h.Authority.IsGuarding(h.Authority.Players[1])&&c.View.IsGuarding(c.View.Players[1]),"remote guard reaches authority and display");
     float hp=h.Authority.Players[1].HP;h.Authority.Players[1].InvulnUntil=0;
     h.Authority.ApplyHit(h.Authority.Players[1],new Hit{Owner=0,Damage=100});Steps(h,c,a,b,25);
     Equal(h.Authority.Players[1].HP,hp-50,"host mitigates remote guard");Equal(c.View.Players[1].HP,hp-50,"client sees mitigated damage");
     c.ClearLocalInput();Steps(h,c,a,b,25);Check(!h.Authority.IsGuarding(h.Authority.Players[1])&&!c.View.IsGuarding(c.View.Players[1]),"remote guard release synchronized");
     // A late input from another match must not move the current fighter.
     b.Send(Wire.Message(Packet.Input,w=>{w.Write(h.Match-1);w.Write(999);Wire.Input(w,new Controls(1));}));Steps(h,c,a,b,20);Check(h.State==RoomState.Playing,"old match packet ignored");
     h.Authority.Players[0].Score=4;h.Authority.ApplyHit(h.Authority.Players[1],new Hit{Owner=0,Damage=99999,TrueDamage=true,Unavoidable=true,BypassInvulnerability=true});Steps(h,c,a,b,40);
     Check(h.State==RoomState.Results&&c.State==RoomState.Results,"synchronized result");Check(c.View.Winner==h.Authority.Winner&&c.View.Players[0].Score==5,"score and winner equal");
     h.Rematch();c.Rematch();Steps(h,c,a,b,40);Check(h.State==RoomState.Lobby&&c.State==RoomState.Lobby,"two votes return to character selection");
     h.SetReady(true);c.SetReady(true);Steps(h,c,a,b,40);Check(h.Match==2&&c.Match==2,"rematch has fresh identity");
     a.Stalled=b.Stalled=true;Steps(h,c,a,b,420);Check(h.State==RoomState.Closed&&c.State==RoomState.Closed,"silent disconnect timeout");
    }
   }
   {
    var a=new Sim();var b=new Sim();a.Peer=b;b.Peer=a;using(var h=new RoomSession(a,true))using(var c=new RoomSession(b,false))
    {ReadyPair(h,c,a,b);b.Send(ViewCodec.Encode(h.Authority,3,h.Match,999,0));Steps(h,c,a,b,1);Check(h.State==RoomState.Closed,"client-forged snapshot rejected");}
   }
   Loopback();return checks+" online assertions passed (serialization, authority, 0/50/100/150ms one-way delay, disconnect and real TCP loopback).";
  }
  static void Loopback()
  {
   var ht=TcpRoomTransport.Host(0);var ct=TcpRoomTransport.Join("127.0.0.1",ht.Port);
   using(var h=new RoomSession(ht,true))using(var c=new RoomSession(ct,false))
   {
    for(int i=0;i<2000&&c.State!=RoomState.Lobby;i++){h.Pump(.005f);c.Pump(.005f);Thread.Sleep(1);}
    Check(h.State==RoomState.Lobby&&c.State==RoomState.Lobby,"real socket handshake "+h.Status+" / "+c.Status);
    h.SetReady(true);c.SetReady(true);
    for(int i=0;i<1500&&c.View==null;i++){h.Pump(.005f);c.Pump(.005f);Thread.Sleep(1);}
    Check(h.State==RoomState.Playing&&c.State==RoomState.Playing&&c.View!=null,"real socket framed snapshot");
    ct.Dispose();for(int i=0;i<1000&&h.State!=RoomState.Closed;i++){h.Pump(.01f);Thread.Sleep(1);}Check(h.State==RoomState.Closed,"real socket disconnect detected");
   }
  }
 }
}
