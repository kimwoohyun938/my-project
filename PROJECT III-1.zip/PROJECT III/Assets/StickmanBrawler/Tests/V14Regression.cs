using System;
using StickmanBrawler.Core;

namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static void AddImpact(World w,int owner,float damage,Shape shape=Shape.Shot)
        {
            var victim=w.Players[1-owner];
            w.Effects.Add(new Effect{Owner=owner,Shape=shape,Pos=victim.Pos,Radius=.6f,
                Expires=w.Time+1,NextTick=w.Time,MaxHits=1,
                Hit=new Hit{Owner=owner,Damage=damage,Knock=0,Stun=.1f}});
        }
        static void V14Tests()
        {
            var w=Ready();var enemy=w.Players[1];Hold(enemy);
            for(int i=0;i<3;i++)AddImpact(w,0,20);
            w.Tick(new Controls(),new Controls());
            Near(enemy.HP,940,"three same-frame bullets apply all 60 damage");Check(w.HitSerial==3,"all three accepted hits counted");
            Near(w.Players[0].Gauge,7.8f+Rules.Dt*Rules.PassiveGaugePerSecond,"all same-frame damage grants gauge once");
            w=Ready();enemy=w.Players[1];Hold(enemy);
            for(int i=0;i<3;i++)AddImpact(w,0,20,Shape.Zone);
            Frames(w,10);Near(enemy.HP,940,"three areas stack but each area hits once");
            w=Ready();enemy=w.Players[1];enemy.ShieldUntil=10;Hold(enemy);
            for(int i=0;i<3;i++)AddImpact(w,0,20);
            w.Tick(new Controls(),new Controls());Near(enemy.HP,960,"one-hit shield blocks only one of simultaneous bullets");
            w=Ready();w.Players[0].HP=w.Players[1].HP=40;
            for(int i=0;i<3;i++){AddImpact(w,0,20);AddImpact(w,1,20);}
            w.Tick(new Controls(),new Controls());Check(w.Players[0].Score==1&&w.Players[1].Score==1,"simultaneous lethal volleys score once each");
            w=Ready(Job.King);var f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(10,.9f);Hold(enemy);
            w.Tick(new Controls(0,false,true),new Controls());
            Check(w.Effects.Count==1,"King first shot only at attack start");
            var first=w.Effects[0];Check(first.Tag=="king-gate"&&first.Pos.x<f.Pos.x&&first.Pos.y>f.Pos.y,"King first shot appears above and behind");Near(first.Hit.Damage,20,"first gate projectile damage");
            Frames(w,3);Check(w.Effects.Count==1,"second shot waits at least 0.08s");
            enemy.Pos=new V2(-10,.9f);enemy.RootPos=enemy.Pos;Frames(w,2);
            Check(w.Effects.Count==2,"King delayed second shot exists");var second=w.Effects[1];
            Check(second.Vel.x<0,"second shot auto-aims at latest enemy position");Near(second.Hit.Damage,20,"second gate projectile damage");
            w=Ready(Job.King);w.Players[0].Facing=-1;w.Players[1].Pos=new V2(-10,.9f);w.Tick(new Controls(0,false,true),new Controls());
            Check(w.Effects[0].Pos.x>w.Players[0].Pos.x&&w.Effects[0].Vel.x<0,"left-facing rear gate auto-aims left");
            foreach(var job in new[]{Job.Knight,Job.Thunder,Job.King,Job.Nisemono,Job.Hassan,Job.Berserker,Job.Samurai,Job.BladeMaster})
            {
                w=Ready(job);f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(10,.9f);Hold(enemy);f.Gauge=100;w.Tick(R,new Controls());
                float hp=f.HP;int version=f.InterruptVersion;var hit=Strike(1,100);hit.Unavoidable=true;
                Check(f.UltimateCastingUntil>w.Time,"cast protection active "+job);
                Check(!w.ApplyHit(f,hit),"cast blocks even guaranteed hits "+job);Near(f.HP,hp,"cast HP protected "+job);
                foreach(CC cc in new[]{CC.Stun,CC.Root,CC.Silence,CC.SkillLock,CC.Slow})w.Control(f,cc,1);
                Check(f.InterruptVersion==version&&f.StunUntil<=w.Time&&f.RootUntil<=w.Time&&f.SilenceUntil<=w.Time,"cast rejects interruption "+job);
            }
            w=Ready(Job.Nisemono);f=w.Players[0];enemy=w.Players[1];enemy.InvulnUntil=100;f.Gauge=100;w.Tick(R,new Controls());
            f.InterruptVersion++;Frames(w,190);Check(f.RealmUntil>w.Time,"ultimate scheduling ignores ordinary interrupt version");
            Check(f.UltimateCastingUntil<=w.Time,"cast immunity ends after chant");w.ApplyHit(f,Strike(1,100));Near(f.HP,900,"persistent realm does not keep chant immunity");
            w=Ready(Job.Knight);f=w.Players[0];enemy=w.Players[1];Hold(enemy);f.Gauge=100;w.Tick(R,new Controls());Frames(w,86);
            Check(f.UltimateCastingUntil>w.Time,"beam protected between later hits");w.ApplyHit(f,Strike(1,100));Near(f.HP,1000,"beam sequence cannot be interrupted after charge");Frames(w,24);Near(enemy.HP,520,"all protected Knight beam hits complete");
            foreach(var job in new[]{Job.Knight,Job.Thunder})
            {
                w=Ready(job);f=w.Players[0];enemy=w.Players[1];f.Pos=new V2(-10,.9f);enemy.Pos=new V2(10,6.4f);Hold(enemy);f.Gauge=100;w.Tick(R,new Controls());Frames(w,110);
                Near(enemy.HP,job==Job.Knight?520:580,"12m beam reaches vertically distant target "+job);
            }
            w=Ready(Job.Hassan);f=w.Players[0];enemy=w.Players[1];f.Pos=new V2(-8,.9f);enemy.Pos=new V2(9,.9f);Hold(enemy);f.Gauge=100;w.Tick(R,new Controls());Frames(w,45);
            Check(w.Effects.Exists(e=>e.Tag=="hassan-arm"),"Hassan homing arm visibly travels");Frames(w,35);Check(enemy.DoomAt>w.Time,"Hassan seal connects at 17m after travel");
            w=Ready(Job.Hassan);f=w.Players[0];enemy=w.Players[1];f.Pos=new V2(-10,.9f);enemy.Pos=new V2(10,.9f);Hold(enemy);f.Gauge=100;w.Tick(R,new Controls());Frames(w,90);Near(enemy.DoomAt,0,"Hassan does not exceed 18m reach");
            w=Ready(Job.Nisemono);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());f.Pos.x=w.Arena.Right+1;w.Tick(new Controls(),new Controls());
            Check(f.Dead,"cast immunity does not bypass blast zone");w.ResetRound();Near(f.UltimateCastingUntil,0,"round resets cast protection");Frames(w,200);Near(f.RealmUntil,0,"round reset cancels old ultimate callbacks");
        }
    }
}
