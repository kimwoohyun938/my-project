using System;
using StickmanBrawler.Core;

namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static void FortuneDinoTests()
        {
            Check(World.FortuneOutcome(0)==2&&World.FortuneOutcome(1f/77f-.000001f)==2,"greater outcome interval");
            Check(World.FortuneOutcome(1f/77f)==1&&World.FortuneOutcome(1f/77f+1f/7f-.000001f)==1,"normal outcome interval");
            Check(World.FortuneOutcome(1f/77f+1f/7f)==0&&World.FortuneOutcome(.999f)==0,"no-buff outcome interval");
            var w=Ready(Job.Gambler);var f=w.Players[0];var enemy=w.Players[1];Hold(enemy);f.HP=700;f.NextCrit=true;
            w.Tick(new Controls(0,false,true),new Controls());Near(enemy.HP,896,"Gambler basic crit 65 x 1.6");Near(f.HP,810,"critical hit heals 110");
            Near(f.Gauge,28+Rules.Dt*Rules.PassiveGaugePerSecond,"Gambler basic fixed gauge");f.Gauge=0;w.ApplyHit(f,Strike(1,10));Near(f.Gauge,5.5f,"Gambler received gauge");
            w=Ready(Job.Gambler);f=w.Players[0];enemy=w.Players[1];enemy.InvulnUntil=10;f.HP=700;f.NextCrit=true;w.Tick(new Controls(0,false,true),new Controls());Near(f.HP,700,"blocked crit does not heal");
            w=Ready(Job.Gambler);enemy=w.Players[1];w.Tick(Q,new Controls());Near(enemy.RootUntil-w.Time,1.75f,"doors root duration");Near(w.Players[0].QAt-w.Time,6,"doors cooldown");
            w=Ready(Job.Gambler);f=w.Players[0];f.HP=60;w.Tick(E,new Controls());Near(f.HP,60,"coin cannot spend lethal cost");Near(f.EAt,0,"invalid coin keeps cooldown");
            w=Ready(Job.Gambler);f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(5,.9f);Hold(enemy);f.HP=800;f.NextCrit=true;w.Tick(E,new Controls());Near(f.HP,740,"coin pays exact 60 upfront");Frames(w,30);
            Near(enemy.HP,960,"coin critical damage");Near(f.HP,910,"coin refunds once plus critical heal");Check(f.CoinCritUntil>w.Time,"coin crit buff starts on accepted hit");Frames(w,260);Check(f.CoinCritUntil<=w.Time,"coin buff expires");
            w=Ready(Job.Gambler);f=w.Players[0];enemy=w.Players[1];enemy.InvulnUntil=10;Hold(enemy);f.HP=800;w.Tick(E,new Controls());Frames(w,30);Near(f.HP,740,"blocked coin keeps cost without refund");Near(f.CoinCritUntil,0,"blocked coin gives no buff");
            foreach(int rank in new[]{1,2})
            {
                w=Ready(Job.Gambler);f=w.Players[0];f.FortuneRank=rank;f.FortuneUntil=10;w.ApplyHit(f,Strike(1,100));
                Near(f.HP,rank==1?907:977,"awakening damage reduction "+rank);Near(f.Vel.Length,0,"awakening negates knockback "+rank);
            }
            w=Ready(Job.Gambler);f=w.Players[0];f.FortuneRank=2;f.FortuneUntil=10;f.HP=100;
            foreach(CC cc in new[]{CC.Stun,CC.Root,CC.Slow,CC.Silence,CC.SkillLock})w.Control(f,cc,2);
            Check(f.StunUntil==0&&f.RootUntil==0&&f.SlowUntil==0&&f.SilenceUntil==0&&f.SkillLockUntil==0,"greater awakening blocks all explicit CC");
            Frames(w,30);Near(f.HP,488.5f,"greater awakening regeneration 777 per second",.1f);
            w=Ready(Job.Gambler);f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(10,.9f);f.FortuneRank=2;f.FortuneUntil=10;
            w.Tick(new Controls(0,false,true),new Controls());var h=w.Effects[0].Hit;
            Check(h.Critical,"greater awakening guarantees critical");Near(h.Damage,65*8.77f,"greater attack bonus");Near(h.CriticalMultiplier,10.06923f,"overflow critical conversion",.0001f);
            f.Gauge=100;w.Tick(R,new Controls());Near(f.Gauge,100,"active awakening cannot be refreshed");
            w=Ready(Job.Gambler);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());Check(f.Gauge<1&&f.UltimateCastingUntil>w.Time,"rune consumes gauge and protects charge");Frames(w,40);Check(f.FortuneRank>=0&&f.FortuneRank<=2,"one valid rune outcome");
            w=Ready(Job.DinoMan);f=w.Players[0];enemy=w.Players[1];Hold(enemy);w.Tick(new Controls(0,false,true),new Controls());Near(enemy.HP,950,"Dino basic damage");Near(f.Gauge,8.5f+Rules.Dt*Rules.PassiveGaugePerSecond,"Dino basic gauge");f.Gauge=0;w.ApplyHit(f,Strike(1,10));Near(f.Gauge,4.5f,"Dino received gauge");
            w=Ready(Job.DinoMan);f=w.Players[0];enemy=w.Players[1];Hold(enemy);w.Tick(Q,new Controls());Frames(w,20);Near(enemy.HP,940,"egg damage 60");Near(enemy.SlowFactor,.7f,"egg 30 percent slow");Check(enemy.SlowUntil>w.Time,"egg slow active");
            w=Ready(Job.DinoMan);f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(2.5f,.9f);Hold(enemy);w.Tick(E,new Controls());Near(enemy.HP,920,"long tail sweep damage");Check(enemy.DinoMarkOwner==0&&enemy.DinoMarkUntil>w.Time,"tail leaves owned mark");
            w=Ready(Job.DinoMan);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());Near(f.Gauge,100,"unmarked Dino ultimate does not spend gauge");
            enemy=w.Players[1];enemy.Pos=new V2(10,.9f);Hold(enemy);enemy.DinoMarkOwner=0;enemy.DinoMarkUntil=10;
            w.Effects.Add(new Effect{Owner=1,Shape=Shape.Wall,Pos=new V2(5,1),Width=1,Height=8,Expires=10});
            w.Tick(R,new Controls());Check(enemy.DinoMarkOwner==-1,"ultimate consumes mark");Frames(w,60);Near(enemy.HP,670,"pterosaur ignores wall and deals exact 330");
            w=Ready(Job.DinoMan);enemy=w.Players[1];enemy.DinoMarkOwner=1;enemy.DinoMarkUntil=10;w.Players[0].Gauge=100;w.Tick(R,new Controls());Near(w.Players[0].Gauge,100,"another owner's mark does not unlock ultimate");
            f=w.Players[0];f.FortuneRank=2;f.FortuneUntil=f.CoinCritUntil=10;w.ResetRound();Check(f.FortuneRank==0&&f.FortuneUntil==0&&f.CoinCritUntil==0&&enemy.DinoMarkOwner==-1,"reset clears new states");
        }
    }
}
