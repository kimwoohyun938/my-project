using System;
using System.IO;
using StickmanBrawler.Core;
using StickmanBrawler.Online;
namespace StickmanBrawler.Tests
{
 public static class GuardInputRegression
 {
  static int checks;
  static void Check(bool b,string n){if(!b)throw new Exception("GUARD/BUFFER: "+n);checks++;}
  static void Near(float a,float b,string n){Check(Math.Abs(a-b)<.01f,n+" "+a+" / "+b);}
  static World Ready(Job job=Job.Knight){var w=new World(job,Job.Knight,3){Phase=Phase.Fight};foreach(var f in w.Players){f.InvulnUntil=0;f.Pos=new V2(f.Id==0?-5:5,.9f);f.Grounded=true;}return w;}
  static Hit Hit(float d=100){return new Hit{Owner=1,Damage=d,Knock=10,Direction=new V2(1,0)};}
  public static string RunAll()
  {
   checks=0;var w=Ready();var f=w.Players[0];f.Gauge=100;
   var guard=new Controls(1,true,true,true,true,true){Guard=true,Command=true};
   w.Tick(guard,new Controls());Check(w.IsGuarding(f),"guard engages");Near(f.Pos.x,-5,"movement suppressed");Near(f.Pos.y,.9f,"jump suppressed");Near(f.QAt,0,"Q suppressed");Near(f.EAt,0,"E suppressed");Near(f.AttackAt,0,"attack suppressed");Near(f.Gauge,100,"R suppressed");
   var hit=Hit();w.ApplyHit(f,hit);Near(f.HP,950,"half damage");float scale=f.KnockbackScale;Near(f.Vel.x,4*scale,"forty percent knockback");
   w.ApplyHit(f,hit);w.ApplyHit(f,hit);Near(f.HP,850,"all three guarded hits count during hitstop");
   w.Tick(new Controls(),new Controls());Check(!w.IsGuarding(f),"release while in hitstop");w.ApplyHit(f,hit);Near(f.HP,750,"released guard full damage");
   w=Ready();f=w.Players[0];w.Tick(guard,new Controls());w.ApplyHit(f,new Hit{Owner=1,Damage=30,Control=CC.Stun,Duration=1});for(int i=0;i<8;i++)w.Tick(guard,new Controls());Check(f.StunUntil>w.Time&&!w.IsGuarding(f),"explicit stun breaks defense");
   w=Ready();f=w.Players[0];w.Tick(guard,new Controls());var trueHit=Hit();trueHit.TrueDamage=true;w.ApplyHit(f,trueHit);Near(f.HP,900,"true damage unmitigated");var burn=Hit(8);burn.Tag="burn";w.ApplyHit(f,burn);Near(f.HP,892,"burn unmitigated");w.ResetRound();Check(!f.Guarding,"round reset guard");
   w=Ready();f=w.Players[0];f.QAt=4*Rules.Dt;w.Tick(new Controls(0,false,false,true),new Controls());for(int i=0;i<4;i++)w.Tick(new Controls(),new Controls());Check(f.BuffUntil>w.Time&&f.BufferedUntil[1]==0,"Q buffers until cooldown then consumes");
   w=Ready();f=w.Players[0];f.QAt=20*Rules.Dt;w.Tick(new Controls(0,false,false,true),new Controls());for(int i=0;i<25;i++)w.Tick(new Controls(),new Controls());Near(f.BuffUntil,0,"expired input never fires");
   w=Ready();f=w.Players[0];f.QAt=4*Rules.Dt;w.Tick(new Controls(0,false,false,true),new Controls());w.Tick(guard,new Controls());for(int i=0;i<6;i++)w.Tick(new Controls(),new Controls());Near(f.BuffUntil,0,"guard clears prior queue");
   foreach(var job in new[]{Job.LTiming,Job.Reflector}){w=Ready(job);f=w.Players[0];f.QAt=4*Rules.Dt;w.Tick(new Controls(0,false,false,true),new Controls());Check(f.BufferedUntil[1]==0,"no counter buffering "+job);for(int i=0;i<6;i++)w.Tick(new Controls(),new Controls());Near(f.ParryUntil,0,"no delayed counter");}
   w=Ready();f=w.Players[0];f.StunUntil=3*Rules.Dt;w.Tick(new Controls(0,true),new Controls());for(int i=0;i<3;i++)w.Tick(new Controls(),new Controls());Check(f.Vel.y>0&&f.BufferedUntil[0]==0,"jump buffers and consumes");
   w=Ready();f=w.Players[0];f.AttackAt=4*Rules.Dt;w.Tick(new Controls(0,false,true),new Controls());for(int i=0;i<4;i++)w.Tick(new Controls(),new Controls());Check(f.AttackAt>w.Time&&f.BufferedUntil[4]==0,"basic tap buffers and consumes");
   using(var m=new MemoryStream()){var bw=new BinaryWriter(m);Wire.Input(bw,guard);m.Position=0;Check(Wire.Input(new BinaryReader(m)).Guard,"wire guard roundtrip");}
   var mailbox=new InputMailbox();mailbox.Push(1,guard,0,0);Check(mailbox.Consume(0).Guard&&mailbox.Consume(1).Guard,"guard held across input ticks");Check(!mailbox.Consume(16).Guard,"stale guard released");
   w=Ready();w.Tick(guard,new Controls());var bytes=ViewCodec.Encode(w,3,1,1,0); // display schema carries defense
   int match,seq,ack;var view=ViewCodec.Decode(bytes,out match,out seq,out ack);Check(view.IsGuarding(view.Players[0]),"snapshot guard state");
   return "Guard/input regression: "+checks+" assertions passed";
  }
 }
}
