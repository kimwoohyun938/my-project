using System;
using StickmanBrawler.Core;
namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static void V2Tests()
        {
            foreach(var beamJob in new[]{Job.Knight,Job.King,Job.Thunder})
            foreach(int facing in new[]{-1,1})
            {
                foreach(bool front in new[]{false,true})
                {
                    var beamWorld=Ready(beamJob);var caster=beamWorld.Players[0];var target=beamWorld.Players[1];
                    caster.Pos=new V2(0,.9f);caster.Facing=facing;target.Pos=new V2((front?1:-1)*facing*10,6.4f);Hold(target);caster.Gauge=100;
                    beamWorld.Tick(R,new Controls());Frames(beamWorld,110);
                    Near(target.HP,front?(beamJob==Job.Thunder?580:520):1000,"directional beam "+beamJob+" facing "+facing+" front "+front);
                }
                var geometry=Ready(beamJob);var emitter=geometry.Players[0];emitter.Pos=new V2(2,.9f);emitter.Facing=facing;emitter.Gauge=100;
                geometry.Players[1].Pos=new V2(-facing*10,.9f);Hold(geometry.Players[1]);geometry.Tick(R,new Controls());
                Effect beam=null;
                for(int tick=0;tick<100&&beam==null;tick++){geometry.Tick(new Controls(),new Controls());beam=geometry.Effects.Find(x=>x.Tag=="arena-beam");}
                Check(beam!=null,"beam effect emitted "+beamJob);Near(beam.Pos.x,emitter.Pos.x,"beam starts at caster");Near(beam.Vel.x,facing,"beam direction follows facing");Near(beam.Height,12,"beam height retained");
                Near(beam.Pos.x+beam.Vel.x*beam.Width,facing>0?geometry.Arena.Right:geometry.Arena.Left,"beam ends at forward boundary");
            }
            Check(Roster.All.Length==55,"v2 has 55 fighters plus random");
            Near(Roster.Get(Job.Guardian).HP,1480,"Guardian health");
            Near(Roster.Get(Job.Reflector).HP,1300,"Reflector health");
            Near(Roster.Get(Job.Assassin).Damage,40,"Assassin damage");
            Near(Roster.Get(Job.Hassan).Damage,40,"Hassan damage");
            foreach(var d in Roster.All)Near(Ready(d.Job).UltimateCooldown(new Fighter(0,d.Job)),0,"no ultimate cooldown "+d.Job);
            var w=Ready(Job.QinShi);var f=w.Players[0];var foe=w.Players[1];
            f.Gauge=100;f.UltAt=999;w.Tick(R,new Controls());Check(f.Gauge<1,"legacy R timer cannot gate cast");
            f.Gauge=100;w.Tick(R,new Controls());Check(f.Gauge<1,"R reusable when refilled");

            w=Ready(Job.Magician);f=w.Players[0];foe=w.Players[1];
            var percent=new Hit{Owner=0,CurrentPercent=.03f,Knock=0,Stun=0};
            for(int i=0;i<3;i++)w.ApplyHit(foe,percent);
            Near(foe.HP,912.673f,"current HP bullets recalculate each hit",.005f);
            f.HP=f.MaxHP*.5f;foe.HP=600;Near(w.MagicianRiftDamage(f,foe),334.56f,"rift ratio formula");
            w=Ready(Job.Magician);f=w.Players[0];foe=w.Players[1];Hold(foe);f.Gauge=100;
            w.Tick(R,new Controls());Frames(w,302);Near(foe.HP,425,"inferno 50 x 1.15 percent max HP",.1f);
            w=Ready(Job.Magician);f=w.Players[0];foe=w.Players[1];foe.Pos=new V2(5,.9f);Hold(foe);
            w.Tick(Q,new Controls());Near(f.QAt-w.Time,6,"blink cooldown six");Check(w.Effects.FindAll(e=>e.Tag=="mage-seeker").Count==3,"blink creates three seekers");

            w=Ready(Job.TimeMurder,Job.Undying);f=w.Players[0];foe=w.Players[1];Hold(f);Hold(foe);f.HP=500;f.Overclock=true;
            Frames(w,60,new Controls(0,false,true));
            Check(w.HitSerial==100,"100 rapid hits in 60 fixed steps");Near(foe.HP,2600,"rapid damage 200 per second",.1f);
            Near(f.HP,501,"rapid +10 heal minus9 cost",.1f);Near(f.Gauge,1.6f,"rapid dealt gauge is zero",.02f);
            w=Ready(Job.TimeMurder);f=w.Players[0];w.Tick(Q,new Controls());Check(!w.ApplyHit(f,Strike(1)),"time stasis invulnerable");
            Near(f.QAt-w.Time,6.5f,"stasis cooldown");float attack=f.AttackAt;Frames(w,10,new Controls(1,true,true));Near(f.AttackAt,attack,"stasis blocks own attacks");
            w=Ready(Job.TimeMurder);f=w.Players[0];foe=w.Players[1];f.Gauge=100;w.Tick(R,new Controls());Near(w.ChronoRate(foe),.9f,"time zero starts at minus10 percent");
            w.Time=foe.ChronoUntil-.1f;Near(w.ChronoRate(foe),0,"time zero reaches full stop");w.Time=foe.ChronoUntil;Near(w.ChronoRate(foe),1,"time zero expires");

            w=Ready(Job.Undying);f=w.Players[0];f.HP=100;f.Gauge=100;w.Tick(R,new Controls());
            w.ApplyHit(f,new Hit{Owner=1,Damage=500,Knock=0,Stun=0});Near(f.HP,1,"undying health floor");Near(f.UndyingDebt,500,"undying stores prevented overkill too");
            f.InvulnUntil=100;f.ShieldUntil=100;w.Time=f.UndyingUntil;w.Tick(new Controls(),new Controls());Check(f.Dead,"deferred damage cannot be blocked by invulnerability");
            w=Ready(Job.Undying);f=w.Players[0];w.Tick(Q,new Controls());w.ApplyHit(f,new Hit{Owner=1,Damage=100,Knock=0,Stun=0});Near(f.HP,2360,"undying Q reduces 60 percent");
            w=Ready(Job.Undying);f=w.Players[0];f.HP=1000;w.Tick(E,new Controls());Near(f.HP,1168,"undying E heals 12 percent missing");
            w.ApplyHit(f,new Hit{Owner=1,Damage=100,Knock=0,Stun=0});Near(f.HP,1118,"undying E reduces50 percent");

            w=Ready(Job.ShadowClone);f=w.Players[0];foe=w.Players[1];Hold(foe);foe.ShadowMarks[0]=3;f.Gauge=100;w.Tick(R,new Controls());
            float tell=f.UltimateCastingUntil-w.Time-1.25f;Check(tell>=.299f&&tell<=.601f,"shadow tell random within range");
            Frames(w,110);Near(foe.HP,620,"shadow ultimate exactly380 before mitigation",.05f);
            w=Ready(Job.ShadowClone);f=w.Players[0];foe=w.Players[1];foe.ShadowMarks[0]=3;f.Gauge=100;w.Tick(R,new Controls());foe.Pos=new V2(10,.9f);Hold(foe);Frames(w,110);Near(foe.HP,1000,"shadow locked telegraph can be escaped");

            w=Ready(Job.Reflector);f=w.Players[0];w.Tick(Q,new Controls());Near(f.ParryUntil-w.Time,.2f,"mirror parry window .2 seconds");
            f.Gauge=0;w.ApplyHit(f,new Hit{Owner=1,Damage=50,Tag="time-basic",Knock=0,Stun=0});Near(f.Gauge,10.5f,"parry gauge five plus attack normal 5.5");
            w=Ready(Job.Hassan,Job.Master);f=w.Players[0];foe=w.Players[1];foe.ShieldUntil=100;foe.DoomAt=.01f;w.Tick(new Controls(),new Controls());Check(foe.Dead,"Master one-hit shield cannot stop armed doom");
            w=Ready(Job.Werewolf);f=w.Players[0];foe=w.Players[1];foe.InvulnUntil=100;foe.Pos=new V2(9,.9f);Hold(foe);f.Gauge=100;w.Tick(R,new Controls());Frames(w,40);Near(foe.HP,760,"wolf tracks and bypasses invulnerability");

            w=Ready(Job.Lancer);f=w.Players[0];foe=w.Players[1];foe.Pos=new V2(10,.9f);Hold(foe);w.Tick(Q,new Controls());Near(f.QAt-w.Time,3,"throw starts recall wait");
            w.Tick(Q,new Controls());Check(!f.HasSpear,"early recall rejected");w.Time=f.QAt;w.Tick(Q,new Controls());Check(f.HasSpear,"recall after wait");Near(f.QAt-w.Time,4,"recall starts throw cooldown");

            w=Ready(Job.MirrorAssassin);f=w.Players[0];w.Tick(Q,new Controls());Check(w.FindSummon(f,"mirror")!=null,"mirror created");Near(f.Pos.x,-4,"mirror backward blink");
            f.QinMarkOwner=1;f.MarkUntil=10;w.Tick(E,new Controls());Check(f.QinMarkOwner==-1&&f.MarkUntil==0,"mirror clears marks");f.Gauge=100;w.Tick(R,new Controls());Check(f.MirrorUltUntil>w.Time,"mirror R activated");
            w=Ready(Job.TwinFang);f=w.Players[0];foe=w.Players[1];Hold(foe);w.FindSummon(f,"twin").Pos=f.Pos+new V2(.8f,0);w.Tick(new Controls(0,false,true),new Controls());Near(foe.HP,944,"twin simultaneous36+20");Near(f.Gauge,8+Rules.Dt*Rules.PassiveGaugePerSecond,"twin both hits charge gauge");
            w=Ready(Job.PhantomLegion);f=w.Players[0];w.Players[1].Pos=new V2(10,.9f);Hold(w.Players[1]);w.Tick(Q,new Controls());Check(w.CountSummons(f,"phantom")==2,"legion Q two phantoms");f.Gauge=100;w.Tick(R,new Controls());Check(w.CountSummons(f,"phantom")==7,"legion R adds five");w.Tick(E,new Controls());Check(w.CountSummons(f,"phantom-rush")==7,"legion E rushes every live phantom");
            w=Ready(Job.Mimic);f=w.Players[0];foe=w.Players[1];w.Tick(E,new Controls());Near(f.EAt,0,"copy no history preserves cooldown");
            foe.LastSkillJob=(int)Job.Knight;foe.LastSkillSlot=1;foe.LastSkillTime=w.Time;w.Tick(E,new Controls());Check(f.BuffUntil>w.Time,"Mimic executes copied shield skill");Check(f.Job==Job.Mimic&&f.NativeJob==Job.Mimic,"copy restores job identity");
            Near(f.QAt,0,"copy does not overwrite own Q cooldown");foe.LastUltimateJob=(int)Job.Guardian;f.Gauge=100;w.Tick(R,new Controls());Check(f.FormUntil>w.Time,"Mimic copied transformation persists");Check(!w.ApplyHit(f,Strike(1)),"copied Guardian form protects Mimic");
            w=Ready(Job.Mimic);f=w.Players[0];foe=w.Players[1];Hold(foe);foe.LastSkillJob=(int)Job.Reflector;foe.LastSkillSlot=2;foe.LastSkillTime=w.Time;
            w.Tick(E,new Controls());Frames(w,25);Near(foe.HP,937,"copied delayed skill keeps seventy percent power");Check(f.Job==Job.Mimic,"delayed callback restores native identity");
            w=Ready(Job.Mimic);f=w.Players[0];foe=w.Players[1];Hold(foe);foe.LastUltimateJob=(int)Job.Knight;f.Gauge=100;w.Tick(R,new Controls());Frames(w,110);Near(foe.HP,520,"copied ultimate full three-hit sequence");
            w=Ready(Job.Puppeteer);f=w.Players[0];w.Tick(Q,new Controls());var puppet=w.FindSummon(f,"puppet");Check(puppet!=null,"puppet Q summon");
            puppet.AccumulatedDamage=100;f.Gauge=100;w.Tick(R,new Controls());Check(w.FindSummon(f,"puppet")!=null&&w.FindSummon(f,"puppet")!=puppet,"puppet R respawns new instance");Near(w.FindSummon(f,"puppet").AccumulatedDamage,0,"new puppet resets damage store");
                        w=Ready(Job.Alchemist);f=w.Players[0];foe=w.Players[1];Hold(foe);
            for(int i=0;i<3;i++)w.ApplyHit(foe,new Hit{Owner=0,Damage=36,Knock=0,Stun=0,Tag="alchemist-basic"});
            Near(foe.HP,847,"three alchemist basics plus 45 catalyst burst");Check(foe.AlchemyStacks[0]==0&&foe.SlowUntil>w.Time,"catalyst burst resets stacks and slows");
            w=Ready(Job.Alchemist);f=w.Players[0];foe=w.Players[1];Hold(foe);w.Tick(E,new Controls());
            Near(foe.HP,945,"equivalent exchange area damage");Check(f.IronActiveShield==120&&f.AlchemistHasteUntil>w.Time,"alchemist shield and haste");
            w=Ready(Job.Ronin);f=w.Players[0];foe=w.Players[1];Hold(foe);f.HP=800;w.Tick(Q,new Controls());
            Check(f.RoninDrawReady&&f.ShieldUntil>w.Time,"ronin Q readies draw stance and shield");
            f.AttackAt=0;w.Tick(new Controls(0,false,true),new Controls());
            Check(!f.RoninDrawReady&&f.HP>800,"ronin draw strike consumes stance and heals");
            w=Ready(Job.Maestro);f=w.Players[0];foe=w.Players[1];Hold(foe);
            w.Tick(new Controls(0,false,true),new Controls());Check(f.MaestroTempo==1,"maestro initial tempo");
            w.Time=f.MaestroBeatStart+.05f;f.QAt=0;w.Tick(Q,new Controls());Check(f.MaestroTempo==2,"maestro perfect beat increments tempo");
            w=Ready(Job.Rider);f=w.Players[0];foe=w.Players[1];foe.Pos=new V2(2,.9f);foe.Facing=-1;Hold(foe);
            w.Tick(E,new Controls());Frames(w,7);Check(foe.FreezeUntil>w.Time,"rider Cybele petrifies close/facing target");
            w=Ready(Job.Luminary);f=w.Players[0];foe=w.Players[1];foe.Pos=new V2(3.5f,.9f);Hold(foe);
            w.Tick(Q,new Controls());Check(f.LuminaryShards==3,"Q charges three radiance shards");
            f.LuminaryShards=9;f.QAt=0;w.Tick(Q,new Controls());Near(f.QAt,0,"max 9 shards blocks redundant Q cast");
            w.Tick(new Controls(0,false,true),new Controls());Check(f.LuminaryShards==0,"basic attack consumes all stored radiance shards");
            Frames(w,45);Check(foe.HP<900,"dash basic and homing shards deal damage");
            w=Ready(Job.Luminary);f=w.Players[0];foe=w.Players[1];Hold(foe);
            for(int i=0;i<6;i++)w.ApplyHit(foe,new Hit{Owner=0,Damage=10,Knock=0,Stun=0,Tag="luminary-shard"});
            Check(foe.OverwhelmStacks[0]==0&&foe.HP<860,"six overwhelm stacks auto-detonate and reset to zero");
            for(int i=0;i<3;i++)w.ApplyHit(foe,new Hit{Owner=0,Damage=10,Knock=0,Stun=0,Tag="luminary-shard"});
            Check(foe.OverwhelmStacks[0]==3,"three stacks accumulated");
            float beforeDetonate=foe.HP;w.Tick(E,new Controls());Check(foe.OverwhelmStacks[0]==0&&foe.HP<beforeDetonate,"space/E consumes overwhelm stacks without duplicate burst");
            for(int stage=3;stage<6;stage++)
            {
                w=new World(Job.Knight,Job.Knight,stage);w.Phase=Phase.Fight;f=w.Players[0];f.InvulnUntil=0;f.Pos=new V2(100,-100);w.Tick(new Controls(),new Controls());
                Check(!f.Dead&&f.Pos.x<w.Arena.Right&&f.Pos.y>w.Arena.Bottom,"closed arena clamps instead of KO "+stage);
                f.HP=0;w.Tick(new Controls(),new Controls());Check(f.Dead,"closed arena still permits HP KO "+stage);
            }
        }
    }
}
