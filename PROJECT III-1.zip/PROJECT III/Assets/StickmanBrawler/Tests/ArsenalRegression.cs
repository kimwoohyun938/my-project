using System;
using StickmanBrawler.Core;

namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static Controls Q { get { return new Controls(0,false,false,true); } }
        static Controls E { get { return new Controls(0,false,false,false,true); } }
        static Controls R { get { return new Controls(0,false,false,false,false,true); } }
        static void Hold(Fighter f) { f.RootPos=f.Pos;f.RootUntil=100; }
        static void ArsenalTests()
        {
            Check(Roster.All.Length==55,"55 playable jobs");
            for(int i=0;i<Roster.All.Length;i++)Check((int)Roster.All[i].Job==i,"roster enum index "+i);
            Near(Roster.Get(Job.Magician).Damage,50,"Magician basic nerf");
            var w=Ready(Job.QinShi);var f=w.Players[0];var enemy=w.Players[1];
            w.Tick(Q,new Controls());Near(f.QAt,0,"Qin invalid Q keeps cooldown");
            w.Tick(E,new Controls());Near(f.EAt,0,"Qin invalid E keeps cooldown");
            f.Gauge=100;w.Tick(R,new Controls());Check(enemy.QinMarkOwner==0,"Qin R creates owned seal");
            f.Gauge=0;var h=Strike(0,55);h.Tag="qin-basic";h.KnockbackGain=.11f;
            w.ApplyHit(enemy,h);Near(enemy.HP,923,"marked basic damage 77");Near(enemy.KnockbackBonus,.154f,"marked basic KB gain 15.4 percent");
            Near(f.Gauge,38,"Qin basic gains flat 38 gauge");Check(enemy.QinMarkOwner==-1,"basic consumes seal");
            w.ApplyHit(f,Strike(1,10));Near(f.Gauge,60,"Qin received hit gains flat 22 gauge");
            w=Ready(Job.QinShi);f=w.Players[0];enemy=w.Players[1];enemy.QinMarkOwner=0;
            h=Strike(0,20);h.PreserveQinMark=true;
            for(int i=0;i<3;i++)w.ApplyHit(enemy,h);
            Near(enemy.HP,916,"three seekers boosted to 28 each");Check(enemy.QinMarkOwner==0,"seekers preserve seal");
            w=Ready(Job.QinShi);enemy=w.Players[1];enemy.QinMarkOwner=0;enemy.Pos=new V2(10,.9f);
            w.Tick(Q,new Controls());Check(enemy.QinMarkOwner==-1,"Q teleport consumes seal");Check(V2.Distance(w.Players[0].Pos,enemy.Pos)<1.5f,"Q teleport arrives by target");Near(w.Players[0].QAt-w.Time,5,"Q cooldown five seconds");
            w=Ready(Job.QinShi);w.Players[1].QinMarkOwner=0;w.Players[1].Pos=new V2(10,.9f);w.Tick(E,new Controls());
            Check(w.Effects.FindAll(x=>x.Tag=="qin-seeker").Count==3,"E creates three homing seekers");Near(w.Players[0].EAt-w.Time,7,"E cooldown seven seconds");
            w=Ready(Job.King);w.Players[1].Pos=new V2(10,.9f);w.Tick(new Controls(0,false,true),new Controls());
            Check(w.Effects.Count==1,"King fires first projectile immediately");Frames(w,5);Check(w.Effects.Count==2,"King fires second projectile after 0.08 seconds");foreach(var shot in w.Effects)Near(shot.Hit.Damage,20,"King projectile damage");
            w=Ready(Job.King);w.Players[0].HP=30;w.Tick(Q,new Controls());Near(w.Players[0].HP,1,"King reserve preserves one HP");
            w=Ready(Job.Lancer);f=w.Players[0];f.HasSpear=false;f.QAt=7;
            w.Effects.Add(new Effect{Owner=0,Shape=Shape.Spear,Tag="spear",Pos=f.Pos,Expires=10});w.Tick(new Controls(),new Controls());
            Check(f.HasSpear&&f.QAt<=w.Time,"physical pickup resets Q");
            w=Ready(Job.Lancer);f=w.Players[0];f.HasSpear=false;f.QAt=0;w.Tick(Q,new Controls());
            Check(f.HasSpear,"skill recall recovers spear");Near(f.QAt-w.Time,4,"skill recall starts four-second rethrow cooldown");
            w=Ready(Job.Lancer,Job.Reflector);f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(10,.9f);Hold(enemy);
            enemy.InvulnUntil=enemy.ReflectUntil=enemy.ShieldUntil=enemy.GuardUntil=100;f.Gauge=100;
            w.Effects.Add(new Effect{Owner=1,Shape=Shape.Wall,Pos=new V2(5,1),Width=1,Height=8,Expires=10});
            w.Tick(R,new Controls());Frames(w,60);
            Check(enemy.HP<=660,"Gae Bolg bypasses terrain, guard, invulnerability, shield and reflection");Near(f.HP,1000,"Gae Bolg not reflected");
            foreach(var job in new[]{Job.Knight,Job.Thunder})
            {
                w=Ready(job);f=w.Players[0];enemy=w.Players[1];f.Pos=new V2(10,.9f);f.Facing=1;enemy.Pos=new V2(-10,4);Hold(enemy);f.Gauge=100;
                w.Tick(R,new Controls());Frames(w,110);Near(enemy.HP,1000,"beam cannot hit behind caster "+job);
            }
            w=Ready(Job.Nisemono);f=w.Players[0];f.HP=299;Frames(w,60);Near(f.HP,319,"Avalon heals 20 per second",.05f);
            Check(f.AvalonActive,"Avalon persists above activation threshold");Frames(w,550);Near(f.HP,500,"Avalon stops at half HP",.05f);
            Check(!f.AvalonActive,"Avalon ends at half HP");f.HP=200;Frames(w,1);Near(f.HP,200,"Avalon cooldown blocks retrigger");
            w.Time=f.AvalonReadyAt;Frames(w,1);Check(f.AvalonActive&&f.HP>200,"Avalon retriggers after 20 seconds");
            w=Ready(Job.Nisemono);f=w.Players[0];f.HP=200;w.SuddenDeath=true;Frames(w,1);Near(f.HP,200,"sudden death disables Avalon");
            w=Ready(Job.Nisemono);enemy=w.Players[1];Hold(enemy);w.Tick(new Controls(0,false,true),new Controls());Frames(w,8);
            Near(enemy.HP,960,"Nisemono near basic 20 x 2");Check(enemy.EmbeddedBlades[0]==0,"melee leaves no thrown-blade marks");
            w=Ready(Job.Nisemono);enemy=w.Players[1];enemy.Pos=new V2(5,.9f);Hold(enemy);
            w.Tick(new Controls(0,false,true),new Controls());Frames(w,30);
            Near(enemy.HP,964,"Nisemono ranged basic 18 x 2");Check(enemy.EmbeddedBlades[0]==2,"two thrown blades leave two marks");
            w.Tick(Q,new Controls());Frames(w,30);Near(enemy.HP,884,"Caladbolg deals 80");Check(enemy.EmbeddedCaladbolgs[0]==1,"Caladbolg leaves one mark");
            w.Tick(E,new Controls());Near(enemy.HP,814,"Broken Phantasm detonates 2 x 10 + 50");Check(enemy.EmbeddedBlades[0]+enemy.EmbeddedCaladbolgs[0]==0,"detonation consumes owned marks");
            w=Ready(Job.Nisemono,Job.Reflector);enemy=w.Players[1];enemy.ReflectUntil=10;h=Strike(0,18);h.Tag="nisemono-blade";w.ApplyHit(enemy,h);
            Check(enemy.EmbeddedBlades[0]==0&&w.Players[0].EmbeddedBlades[1]==0,"reflected blade does not create owned marks");
            w=Ready(Job.Nisemono);f=w.Players[0];enemy=w.Players[1];enemy.InvulnUntil=100;f.Gauge=100;w.Tick(R,new Controls());Frames(w,170);
            Near(f.RealmUntil,0,"realm waits full charge");Frames(w,20);Check(f.RealmUntil>w.Time,"realm activates after charge");
            f.Gauge=100;f.UltAt=0;w.Tick(R,new Controls());Near(f.Gauge,100,"active realm cannot recast");Frames(w,920);
            Check(f.RealmUntil<=w.Time&&w.Effects.FindAll(x=>x.Tag=="ubw-sword").Count==0,"realm and swords expire after 15 seconds");
            Check(f.RealmVolleyIndex==60,"realm fires 60 swords across four edges");
            w=Ready(Job.Nisemono);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());w.Control(f,CC.Stun,.1f);Frames(w,190);Check(f.RealmUntil>w.Time,"realm charge resists stun and completes");
            w.Players[1].EmbeddedBlades[0]=3;w.Players[1].QinMarkOwner=0;f.KnockbackBonus=.5f;f.AvalonActive=true;f.RealmUntil=50;w.ResetRound();
            Check(w.Players[1].EmbeddedBlades[0]==0&&w.Players[1].QinMarkOwner==-1&&f.KnockbackBonus==0&&!f.AvalonActive&&f.RealmUntil==0,"round resets all new state");
        }
    }
}
