using System;
using StickmanBrawler.Core;
namespace StickmanBrawler.Tests
{
 public static partial class Regression
 {
  static World ReactionReady(Job a=Job.Knight,Job b=Job.Knight){var w=Ready(a,b);w.ContactStopEnabled=true;return w;}
  static void HitReactionTests()
  {
   var all=new Controls(1,true,true,true,true,true);var idle=new Controls();
   var w=ReactionReady();var f=w.Players[0];var enemy=w.Players[1];
   w.ApplyHit(f,new Hit{Owner=1,Damage=20,Knock=0});var pos=f.Pos;
   Check(w.InHitstop(f)&&f.HitstunUntil==0&&f.StunUntil==0,"contact stop separated from both stun types");
   f.Gauge=100;for(int i=0;i<6;i++){w.Tick(all,idle);Near(f.Pos.x,pos.x,"hitstop freezes position");Near(f.Pos.y,pos.y,"hitstop freezes gravity and jump");Near(f.Gauge,100,"ultimate denied during stop");Near(enemy.HP,1000,"attack denied during stop");}
   Check(!w.InHitstop(f)&&f.HitstunUntil==0,"six ticks then no implicit hitstun");w.Tick(new Controls(1),idle);Check(f.Pos.x>pos.x,"normal movement resumes");
   foreach(float duration in new[]{.05f,.15f})
   {
    w=ReactionReady();f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=0,Hitstun=duration});Frames(w,5);Near(f.HitstunUntil,0,"hitstun does not run during stop");Frames(w,1);Near(f.HitstunUntil-w.Time,duration,"full independent hitstun duration");Near(f.StunUntil,0,"contact stun does not set explicit stun");
   }
   w=ReactionReady();f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=0,Control=CC.Stun,Duration=1});Frames(w,6);Near(f.StunUntil-w.Time,1,"explicit stun starts after stop with full duration");
   w=ReactionReady(Job.Reflector);f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=0,Hitstun=.15f});Frames(w,6);w.Tick(new Controls(0,false,false,true),idle);Check(f.ParryUntil>w.Time,"reflector Q allowed during hitstun");
   w=ReactionReady(Job.Reflector);f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=0,Control=CC.Stun,Duration=1});w.Tick(new Controls(0,false,false,true),idle);Check(f.ParryUntil>w.Time,"reflector Q allowed during initial stop");Frames(w,5);f.QAt=0;f.ParryUntil=0;w.Tick(new Controls(0,false,false,true),idle);Near(f.ParryUntil,0,"explicit stun still blocks counter after grace");
   w=ReactionReady(Job.Reflector);f=w.Players[0];f.SilenceUntil=5;w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=0});w.Tick(new Controls(0,false,false,true),idle);Near(f.ParryUntil,0,"silence blocks counter during stop");
   w=ReactionReady();f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=20,Knock=0});Frames(w,3);w.ApplyHit(f,new Hit{Owner=1,Damage=20,Knock=0});Frames(w,3);Check(!w.InHitstop(f),"hits inside stop do not extend six ticks");Near(f.HP,960,"simultaneous and followup damage retained");
   w=ReactionReady(Job.LTiming,Job.Berserker);f=w.Players[0];w.Tick(idle,new Controls(0,false,false,false,true));Check(w.InHitstop(f),"roar enters counter stop");w.Tick(new Controls(0,false,false,true),idle);Near(f.HP,1000,"timing return inside one tick heals roar");Frames(w,8);Near(f.StunUntil,0,"canceled roar never applies queued stun");
   w=ReactionReady(Job.LTiming,Job.Berserker);f=w.Players[0];w.Tick(idle,new Controls(0,false,false,false,true));Frames(w,2);w.Tick(new Controls(0,false,false,false,true),idle);Check(w.Players[1].SlotLockedUntil[2]>w.Time,"timing interception allowed at three tick boundary");Frames(w,8);Check(f.StunUntil<=w.Time,"intercept removes pending stun");
   w=ReactionReady(Job.FrostReaper,Job.Reflector);f=w.Players[0];enemy=w.Players[1];f.Gauge=100;w.Tick(new Controls(0,false,false,false,false,true),idle);Check(w.InHitstop(enemy)&&enemy.FreezeUntil<=w.Time,"freeze waits for counter phase");Frames(w,6);Near(enemy.FreezeUntil-w.Time,3,"freeze retains duration after stop");Check(enemy.FrostThawAt>0,"thaw damage retained");
   w=ReactionReady();f=w.Players[0];w.Control(f,CC.Stun,1);w.ResetRound();w.Phase=Phase.Fight;Frames(w,8);Near(f.StunUntil,0,"reset discards pending reactions");
   w=ReactionReady();f=w.Players[0];f.HitstunUntil=.2f;w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=0});Frames(w,6);Near(f.HitstunUntil-w.Time,.2f,"existing hitstun timer paused through contact stop");
   w=ReactionReady();f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=10,Knock=8,Direction=new V2(1,.3f)});pos=f.Pos;Frames(w,6);Near(f.Pos.x,pos.x,"knockback held during stop");w.Tick(idle,idle);Check(f.Pos.x>pos.x,"knockback resumes after stop");
   foreach(var def in Roster.All)
   {
    w=ReactionReady(def.Job);f=w.Players[0];w.ApplyHit(f,new Hit{Owner=1,Damage=20,Knock=0});Frames(w,6,all);Check(!float.IsNaN(f.HP)&&!float.IsNaN(f.Pos.x),"production reaction path "+def.Job);
   }
  }
 }
}
