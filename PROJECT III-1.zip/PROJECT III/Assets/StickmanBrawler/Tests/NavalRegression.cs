using System;
using System.Collections.Generic;
using StickmanBrawler.Core;

namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static void NavalTests()
        {
            var w=Ready(Job.YiSunGod);var f=w.Players[0];var enemy=w.Players[1];
            w.Tick(new Controls(0,false,true),new Controls());Near(enemy.HP,940,"Yi slash 60");
            Near(f.Gauge,8.5f+Rules.Dt*Rules.PassiveGaugePerSecond,"Yi basic fixed 8.5 gauge");Near(f.AttackAt-w.Time,.65f,"Yi normal interval");
            f.Gauge=0;w.ApplyHit(f,Strike(1,30));Near(f.Gauge,6.5f,"Yi incoming fixed 6.5 gauge");
            w=Ready(Job.Institutor);f=w.Players[0];enemy=w.Players[1];w.Tick(new Controls(0,false,true),new Controls());
            Near(enemy.HP,970,"institutor punch 30");Near(f.Gauge,7.5f+Rules.Dt*Rules.PassiveGaugePerSecond,"institutor basic fixed 7.5 gauge");
            f.Gauge=0;w.ApplyHit(f,Strike(1,10));Near(f.Gauge,5.5f,"institutor incoming fixed 5.5 gauge");
            w=Ready(Job.YiSunGod,Job.Reflector);f=w.Players[0];enemy=w.Players[1];enemy.Pos=new V2(10,.9f);Hold(enemy);
            enemy.InvulnUntil=enemy.ShieldUntil=enemy.ReflectUntil=enemy.GuardUntil=100;
            w.Tick(Q,new Controls());Near(f.QAt-w.Time,7,"Yi soldier Q cooldown");
            int soldierHits=0;float secondAt=0;
            for(int i=0;i<135;i++)
            {
                float before=enemy.HP;w.Tick(new Controls(),new Controls());
                if(enemy.HP<before){soldierHits++;if(soldierHits==2)secondAt=w.Time;}
            }
            Near(enemy.HP,1220,"two unavoidable soldiers deal 40 each");Check(soldierHits==2&&secondAt>.7f,"second soldier is delayed");Near(f.HP,1000,"soldiers bypass reflection");
            w=Ready(Job.YiSunGod);f=w.Players[0];enemy=w.Players[1];Hold(enemy);w.Tick(E,new Controls());
            Near(f.EAt-w.Time,9,"fire arrow cooldown");Frames(w,40);Near(enemy.HP,1000,"fire arrow has travel tell");Frames(w,15);
            Near(enemy.HP,940,"fire arrow impact 60");Check(enemy.BurnTicks==5,"impact applies five burn ticks");
            float afterImpactGauge=f.Gauge;Frames(w,305);Near(enemy.HP,900,"fire arrow total 60 + 40");Check(enemy.BurnTicks==0,"burn expires");
            Near(f.Gauge,afterImpactGauge+305*Rules.Dt*Rules.PassiveGaugePerSecond,"burn does not farm gauge",.03f);
            w=Ready(Job.YiSunGod);f=w.Players[0];enemy=w.Players[1];w.Tick(E,new Controls());enemy.Pos=new V2(10,.9f);Hold(enemy);Frames(w,60);
            Near(enemy.HP,1000,"fire arrow AoE can miss moving target");Check(enemy.BurnTicks==0,"miss applies no burn");
            w=Ready(Job.YiSunGod);f=w.Players[0];enemy=w.Players[1];f.Gauge=100;f.QAt=9;f.EAt=10;w.Tick(R,new Controls());
            Check(w.IsShip(f),"R enables ship");Near(f.FormUntil-w.Time,12,"ship lasts 12 seconds");Check(f.QAt<=w.Time&&f.EAt<=w.Time,"ship conversion readies new Q/E");
            enemy.Pos=new V2(5,.9f);Hold(enemy);w.Tick(new Controls(0,false,true),new Controls());
            Near(f.AttackAt-w.Time,.85f,"ship basic interval");Frames(w,20);Near(enemy.HP,920,"ship cannon deals exact 80");
            f.Gauge=100;f.UltAt=0;w.Tick(R,new Controls());Near(f.Gauge,100,"ship cannot refresh itself while active");
            w.Tick(Q,new Controls());Near(f.QAt-w.Time,3,"ship laser cooldown");Near(enemy.HP,870,"ship laser deals exact 50");
            w.Tick(E,new Controls());Near(f.EAt-w.Time,5,"ship slow cooldown");Near(enemy.SlowFactor,.8f,"ship skill slow 20 percent");Near(enemy.SlowUntil-w.Time,3,"ship slow lasts three seconds");
            w.Time=f.FormUntil;w.Tick(new Controls(),new Controls());Check(!w.IsShip(f),"ship expires to normal form");
            f.QAt=0;w.Tick(Q,new Controls());Near(f.QAt-w.Time,7,"normal Q cooldown returns");
            w=Ready(Job.YiSunGod);f=w.Players[0];enemy=w.Players[1];f.FormUntil=12;f.Pos=new V2(-5,.9f);enemy.Pos=new V2(5,.9f);
            Frames(w,10,new Controls(1),new Controls(-1));Near(f.Vel.x,8.5f*1.1f,"ship move speed +10 percent");Near(Math.Abs(enemy.Vel.x),8.5f*.9f,"sea foe speed -10 percent");
            w=Ready(Job.Institutor);f=w.Players[0];w.Tick(Q,new Controls());Near(f.QAt,0,"empty Q no cooldown");w.Tick(E,new Controls());Near(f.EAt,0,"empty E no cooldown");
            Frames(w,175);Check(f.YangSwords==0,"passive waits three seconds");Frames(w,6);Check(f.YangSwords==1,"passive generates first sword");
            f.YangSwords=1000;f.NextYangAt=w.Time;w.Tick(new Controls(),new Controls());Check(f.YangSwords==1001,"passive sword stock has no gameplay cap");
            var positions=new HashSet<string>();for(int i=0;i<1001;i++){V2 p=w.YangPosition(f,i,1001);Check(positions.Add(p.x.ToString("R")+","+p.y.ToString("R")),"unique sword position "+i);}
            f.YangSwords=3;w.Tick(Q,new Controls());Check(f.YangSwords==2,"Q releases exactly one sword");Near(f.YangSprintUntil-w.Time,5,"Q sprint duration");Near(f.QAt-w.Time,7,"institutor Q cooldown");
            f.EAt=w.Time+10;f.Gauge=100;int count=f.YangSwords;w.Tick(R,new Controls());
            Check(f.YangSwords==count+7,"institutor R adds seven swords");Near(f.EAt-w.Time,(10-Rules.Dt)/2,"R halves remaining E cooldown once");
            Near(f.YangUltimateUntil-w.Time,5,"R sprint lasts five seconds");float due=f.EAt;Frames(w,5);Near(f.EAt,due,"cooldown not repeatedly halved");
            w=Ready(Job.Institutor);f=w.Players[0];f.YangSwords=7;enemy=w.Players[1];enemy.Pos=new V2(5,.9f);Hold(enemy);
            w.Tick(E,new Controls());Check(f.YangSwords==0,"volley releases all stock");Check(w.Effects.FindAll(x=>x.Tag=="yang-sword").Count==7,"volley launches seven simultaneous swords");Near(f.EAt-w.Time,11,"volley cooldown");
            Frames(w,50);Near(enemy.HP,580,"seven sword hits each deal 60");
            w=Ready(Job.Institutor);enemy=w.Players[1];var h=Strike(0,60);h.Tag="yang-sword";h.Stun=0;
            for(int i=0;i<7;i++)w.ApplyHit(enemy,h);Near(enemy.HP,580,"seven direct sword hits");Near(enemy.StunUntil-w.Time,1.4f,"seven swords add 1.4 seconds stun");
            w=Ready(Job.Institutor);enemy=w.Players[1];enemy.ArmorUntil=10;w.ApplyHit(enemy,h);Near(enemy.StunUntil,0,"superarmor blocks sword stun");
            w=Ready(Job.YiSunGod);f=w.Players[0];f.FormUntil=20;enemy=w.Players[1];enemy.BurnOwner=0;enemy.BurnTicks=5;f.YangSwords=10;w.ResetRound();
            Check(!w.IsShip(f)&&enemy.BurnTicks==0&&enemy.BurnOwner==-1&&f.YangSwords==0,"new states clear on round reset");
        }
    }
}
