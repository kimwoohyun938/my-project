using System;
using StickmanBrawler.Core;

namespace StickmanBrawler.Tests
{
    public static partial class Regression
    {
        static Hit ExpansionHit(int owner,float damage,string tag)
        { return new Hit{Owner=owner,Damage=damage,Tag=tag,Knock=0,Stun=0}; }
        static void ExpansionTests()
        {
            Check(Roster.All[0].Name=="성검기사","Knight display renamed without changing enum index");
            Check(WeaponArt.Strokes.Length==55&&WeaponArt.Names.Length==55&&WeaponArt.Colors.Length==55,"all 55 weapon definitions exist");
            foreach(var strokes in WeaponArt.Strokes)Check(strokes.Length>0,"nonempty weapon silhouette");
            var w=Ready(Job.FrostReaper);var f=w.Players[0];var e=w.Players[1];
            for(int i=0;i<3;i++)w.ApplyHit(e,ExpansionHit(0,45,"frost-basic"));
            Near(e.HP,865,"three frost basics");Near(f.Gauge,16.5f,"frost basic fixed gauge");Near(e.SlowFactor,.8f,"third frost hit slows 20 percent");Near(e.SlowUntil,2,"frost slow duration");
            w=Ready(Job.FrostReaper);f=w.Players[0];e=w.Players[1];Hold(e);w.Tick(Q,new Controls());Frames(w,12);Near(e.HP,930,"ice spear damage");Check(e.FreezeUntil>w.Time,"ice spear freeze visible");
            w=Ready(Job.FrostReaper);f=w.Players[0];e=w.Players[1];f.HP=500;Hold(f);Hold(e);w.Tick(E,new Controls());Frames(w,59);Near(f.HP,540,"veil heals 4 percent max HP per second",.05f);Near(w.ColdAttackRate(e),.7f,"veil attack rate reduction");
            w=Ready(Job.FrostReaper);f=w.Players[0];e=w.Players[1];Hold(e);f.Gauge=100;w.Tick(R,new Controls());Near(e.FreezeUntil-w.Time,3,"ultimate three second freeze");Near(f.UltAt,0,"ultimate has no cooldown");
            w.ApplyHit(e,ExpansionHit(0,200,"probe"));Frames(w,183);Near(e.HP,600,"thaw is 25 percent of current HP at thaw");
            w=Ready(Job.BloodApostle);f=w.Players[0];e=w.Players[1];f.HP=500;w.ApplyHit(e,ExpansionHit(0,42,"blood-basic"));Near(f.HP,514.7f,"basic lifesteal 35 percent");Near(f.Gauge,5.5f,"blood basic gauge");
            w=Ready(Job.BloodApostle);f=w.Players[0];e=w.Players[1];f.HP=500;w.Tick(Q,new Controls());Near(f.HP,425,"pact consumes 15 percent current HP");Hold(e);w.Tick(new Controls(0,false,true),new Controls());Near(e.HP,939.1f,"pact basic damage 145 percent");Near(f.HP,485.9f,"pact lifesteal 100 percent");
            w=Ready(Job.BloodApostle);f=w.Players[0];f.HP=500;Hold(f);w.Tick(E,new Controls());w.ApplyHit(f,ExpansionHit(1,100,"probe"));Near(f.HP,450,"guard halves damage");Near(f.BloodStoredDamage,50,"guard stores prevented damage");Frames(w,183);Near(f.HP,475,"guard returns half prevented damage");
            w=Ready(Job.BloodApostle);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());Near(f.MaxHP,1400,"temporary maximum HP");Near(f.HP,1400,"health fraction preserved on expansion");Check(f.BloodReviveArmed,"revival armed");
            f.HP=0;w.Tick(new Controls(),new Controls());Check(!f.Dead&&f.BloodReviveUsed,"revives once");Near(f.HP,560,"revival at forty percent active maximum");Near(w.Players[1].Score,0,"revival gives no kill");
            f.InvulnUntil=0;f.HP=0;w.Tick(new Controls(),new Controls());Check(f.Dead&&w.Players[1].Score==1,"second KO awards kill");w.ResetRound();Check(f.BloodReviveUsed,"revival limit survives round reset");
            w=Ready(Job.ShadowClone);f=w.Players[0];e=w.Players[1];f.Gauge=100;w.Tick(R,new Controls());Near(f.Gauge,100,"assault requires three marks");
            for(int i=0;i<3;i++)w.ApplyHit(e,ExpansionHit(0,38,"shadow-basic"));Near(e.HP,836,"three basics plus 5 percent maximum HP");Check(e.ShadowMarks[0]==3,"three marks retained to unlock ultimate");
            f.Gauge=100;w.Tick(R,new Controls());Check(f.ShadowAssaultUntil>w.Time&&f.Gauge<1,"marked assault starts");Near(f.UltAt,0,"ultimate has no cooldown");
            w=Ready(Job.ShadowClone);f=w.Players[0];e=w.Players[1];Hold(e);w.Tick(Q,new Controls());Frames(w,30);Check(e.HP<1000&&e.ShadowMarks[0]>0,"clone autonomously attacks and marks");Near(f.Gauge,31*Rules.Dt*Rules.PassiveGaugePerSecond,"clone does not farm gauge",.05f);
            w=Ready(Job.ShadowClone);f=w.Players[0];e=w.Players[1];Hold(e);w.Tick(E,new Controls());Check(!w.ApplyHit(f,ExpansionHit(1,100,"probe")),"stealth is hit evasion");Frames(w,50);w.Tick(new Controls(0,false,true),new Controls());Near(e.HP,943,"post stealth guaranteed 150 percent basic");
            w=Ready(Job.IronWall);f=w.Players[0];e=w.Players[1];
            for(int i=0;i<110;i++){e.HP=1000;w.ApplyHit(e,ExpansionHit(0,25,"iron-basic"));}Near(f.IronPassiveShield,500,"100 stacks cap at 500 shield HP");
            w=Ready(Job.IronWall);f=w.Players[0];w.Tick(Q,new Controls());w.ApplyHit(f,ExpansionHit(1,100,"probe"));Near(f.HP,1200,"shield absorbs actual damage");Near(w.TotalShield(f),50,"shield remaining");Frames(w,363);Near(w.TotalShield(f),0,"Q shield expires");
            w=Ready(Job.IronWall);f=w.Players[0];w.Tick(E,new Controls());w.ApplyHit(f,ExpansionHit(1,140,"probe"));Near(f.HP,1100,"40 percent armor divides damage by 1.4");w.Control(f,CC.Stun,2);w.Control(f,CC.Slow,2);Near(f.StunUntil,0,"iron control immunity");Near(f.SlowUntil,0,"iron slow immunity");
            w=Ready(Job.IronWall);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());w.ApplyHit(f,ExpansionHit(1,100,"probe"));Near(f.HP,1150,"100 percent armor halves damage without ally share");Near(f.UltAt,0,"ultimate has no cooldown");
            w=Ready(Job.VoidWalker);f=w.Players[0];float start=f.Pos.x;w.Tick(Q,new Controls());Near(f.Pos.x,start+5,"first blink five meters");float readyAt=f.QAt;w.Tick(Q,new Controls());Near(f.Pos.x,start+10,"free recast five meters");Near(f.QAt,readyAt,"recast keeps original cooldown");Check(!f.VoidRecastAvailable,"only one free recast");
            w=Ready(Job.VoidWalker);f=w.Players[0];w.Tick(E,new Controls());Hit physical=ExpansionHit(1,100,"probe");physical.Physical=true;Check(!w.ApplyHit(f,physical),"phase rejects physical damage");w.ApplyHit(f,ExpansionHit(1,100,"energy"));Near(f.HP,900,"phase still receives energy damage");physical.Unavoidable=true;Check(w.ApplyHit(f,physical),"guaranteed-hit priority survives phase");
            w=Ready(Job.VoidWalker);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());Near(w.DuelUntil-w.Time,6,"duel lasts six seconds");Near(f.UltAt,0,"ultimate has no cooldown");Hit summon=ExpansionHit(1,100,"summon");summon.Summoned=true;Check(!w.ApplyHit(f,summon),"duel blocks external summon impacts");
            f.Pos=w.DuelCenter+new V2(10,0);w.Tick(new Controls(),new Controls());Check(V2.Distance(f.Pos,w.DuelCenter)<=6.001f,"duel clamps participant positions");
            w=Ready(Job.Assassin);f=w.Players[0];w.Tick(E,new Controls());Hit ult=ExpansionHit(1,100,"ult");ult.Ultimate=true;Check(!w.ApplyHit(f,ult),"Assassin invisibility also evades ordinary ultimate hit");
            w=Ready(Job.Gambler);f=w.Players[0];f.Gauge=100;w.Tick(R,new Controls());Frames(w,40);Check(f.FortuneResult>=0&&f.FortuneResult<=2&&f.FortuneResultUntil>w.Time,"all fortune results retained for HUD including failure");
        }
    }
}
