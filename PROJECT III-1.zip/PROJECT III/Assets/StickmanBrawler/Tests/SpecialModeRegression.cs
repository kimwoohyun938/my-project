using System;
using StickmanBrawler.Core;
namespace StickmanBrawler.Tests
{
 public static partial class Regression
 {
  static World SpecialReady(BattleMode mode,float duration=60)
  {
   var jobs=mode==BattleMode.DpsEvent?new[]{Job.Knight,Job.Knight,Job.Knight,Job.Knight}:new[]{Job.Knight,Job.Knight,Job.Grappler};
   var w=new World(jobs,new MatchOptions{Mode=mode,EventDuration=duration},0,631);w.Phase=Phase.Fight;
   foreach(var f in w.Players)f.InvulnUntil=0;return w;
  }
  static void SpecialModeTests()
  {
   var w=SpecialReady(BattleMode.ThreeWay);
   Check(w.Players.Length==3&&w.Opponents(0,1)&&w.Opponents(1,2)&&w.Opponents(2,0),"three humans are opponents");
   w.ApplyHit(w.Players[0],new Hit{Owner=2,Damage=2000,TrueDamage=true});w.Tick(new Controls[3]);
   Check(w.Players[2].Score==1&&w.Players[0].Dead,"third player earns KO");Frames(w,45);Check(!w.Players[0].Dead,"three-way individual respawn");
   w=SpecialReady(BattleMode.BossRaid);Check(w.Players[2].IsBoss,"boss configured");Near(w.Players[2].MaxHP,12000,"boss health pool");
   Check(!w.Opponents(0,1)&&w.Opponents(0,2)&&w.Opponents(1,2),"co-op team shares boss enemy");
   w.ApplyHit(w.Players[2],new Hit{Owner=0,Damage=9999,TrueDamage=true});Near(w.Players[2].HP,11400,"boss single-hit cap includes execution");
   w.Players[0].HP=0;w.Tick(new Controls[3]);Check(w.BossLivesRemaining==5&&w.Players[0].Dead,"boss team loses one life");
   w.Tick(new Controls[3]);Check(w.BossLivesRemaining==5,"waiting respawn not counted twice");Frames(w,43);Check(!w.Players[0].Dead,"boss ally respawns");
   w.Players[2].HP=0;w.Tick(new Controls[3]);Check(w.Phase==Phase.Finished&&w.Winner==0,"boss defeat wins for team");
   w=SpecialReady(BattleMode.BossRaid);w.BossLivesRemaining=1;w.Players[1].HP=0;w.Tick(new Controls[3]);Check(w.Phase==Phase.Finished&&w.Winner==2,"team lives exhausted loses raid");
   w=SpecialReady(BattleMode.BossRaid);for(int i=0;i<600&&w.Phase==Phase.Fight;i++)w.Tick(new Controls[3]);
   foreach(var f in w.Players)Check(!float.IsNaN(f.HP)&&!float.IsNaN(f.Pos.x),"boss pattern simulation finite");
   w=SpecialReady(BattleMode.DpsEvent);
   Check(w.Players.Length==4&&w.IsFixedDummy(w.Players[2])&&w.IsFixedDummy(w.Players[3]),"event has two fixed dummies");
   Check(!w.ApplyHit(w.Players[1],Strike(0)),"event players cannot damage each other");
   Check(!w.ApplyHit(w.Players[3],Strike(0)),"event cannot score on other dummy");
   Check(!w.ApplyHit(w.Players[0],Strike(2)),"event player invulnerable to dummy-owned hit");
   for(int i=0;i<3;i++)w.ApplyHit(w.Players[2],new Hit{Owner=0,Damage=20,TrueDamage=true});
   Near((float)w.EventDamage[0],60,"simultaneous hits all counted");Near(w.Players[2].HP,1000,"event dummy keeps health");
   w.ApplyHit(w.Players[3],new Hit{Owner=1,Damage=40,TrueDamage=true});Near((float)w.EventDamage[1],40,"second player independent damage");
   w.Players[0].HP=1;w.Tick(new Controls[4]);Near(w.Players[0].HP,1000,"event restores health costs");
   for(int i=1;i<3600;i++)w.Tick(new Controls[4]);
   Check(w.EventTicks==3600&&w.Phase==Phase.Finished&&w.Winner==0,"60 second event ends on tick 3600");Near((float)w.EventDps(0),1,"event DPS uses battle elapsed time");
   w.Tick(new Controls[4]);Check(w.EventTicks==3600,"finished event stops timer");
   w=SpecialReady(BattleMode.DpsEvent,1);for(int i=0;i<60;i++)w.Tick(new Controls[4]);Check(w.Phase==Phase.Finished&&w.Winner==-1,"equal event score is draw");
  }
 }
}
