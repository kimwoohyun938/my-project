using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace StickmanBrawler.Editor
{
    public static class BrawlerEditor
    {
        const string ScenePath="Assets/Scenes/Arena.unity";
        [MenuItem("Tools/Stickman Brawler/Open Arena")]
        public static void OpenArena()
        {
            if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;
            AssetDatabase.Refresh();
            if(!File.Exists(ScenePath))throw new FileNotFoundException("Open the extracted Unity project root containing Assets, Packages and ProjectSettings. Missing scene: "+ScenePath);
            EditorSceneManager.OpenScene(ScenePath);
        }
        [MenuItem("Tools/Stickman Brawler/Run Core Tests")]
        public static void RunTests()
        { Debug.Log(Tests.Regression.RunAll());Debug.Log(Tests.GuardInputRegression.RunAll()); }
        [MenuItem("Tools/Stickman Brawler/Run Online Tests")]
        public static void RunOnlineTests(){Debug.Log(Tests.OnlineRegression.RunAll());}
        [MenuItem("Tools/Stickman Brawler/Build Windows x64")]
        public static void BuildWindows()
        {
            RunTests();Directory.CreateDirectory("Builds/Windows");
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{ScenePath},locationPathName="Builds/Windows/StickmanBrawler.exe",target=BuildTarget.StandaloneWindows64,options=BuildOptions.None});
            if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Build failed: "+report.summary.result);
            Debug.Log("Built: "+Path.GetFullPath("Builds/Windows/StickmanBrawler.exe"));
        }
    }
}
