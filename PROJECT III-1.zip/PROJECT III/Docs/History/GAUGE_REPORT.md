# v1.6 평타 궁 게이지 기준값

37직업 기준값의 단순 평균 **5.7946%p**입니다. 실전 적중률을 조사한 평균이 아닙니다.

평타 1회 전타 적중, 충분한 상대 HP, 기본폼·기본 카드·창 보유·니세모노 근접 기준. 치명타·버프·추가타·표식 폭발·피해 경감·보호막·자연 충전은 제외합니다.

| 직업 | 1회 총 기본 피해 | 궁 충전 |
|---|---:|---:|
| Saber | 50 | 5%p |
| Berserker | 60 | 6%p |
| Samurai | 45 | 4.5%p |
| BladeMaster | 40 | 4%p |
| Lancer | 60 | 6%p |
| Archer | 25 | 2.5%p |
| GravityMage | 30 | 3%p |
| Thunder | 40 | 4%p |
| Magician | 50 | 5%p |
| Assassin | 30 | 3%p |
| Hassan | 15 | 1.5%p |
| Dystopia | 70 | 7%p |
| TimeMurder | 50 | 5%p |
| CardMan | 30 | 3%p |
| Guardian | 20 | 2%p |
| Reflector | 20 | 2%p |
| Grappler | 70 | 7%p |
| King | 40 | 4%p |
| Werewolf | 75 | 7.5%p |
| Vertebrate | 40 | 4%p |
| Director | 35 | 3.5%p |
| Depth | 60 | 6%p |
| Cross | 40 | 4%p |
| Master | 35 | 3.5%p |
| Engineer | 32 | 3.2%p |
| Zephyr | 32 | 3.2%p |
| QinShi | 55 | 35%p |
| Nisemono | 40 | 4%p |
| YiSunGod | 60 | 7%p |
| Institutor | 30 | 6%p |
| Gambler | 65 | 25%p |
| DinoMan | 50 | 7%p |
| FrostReaper | 45 | 4%p |
| BloodApostle | 42 | 4%p |
| ShadowClone | 38 | 4%p |
| IronWall | 25 | 5%p |
| VoidWalker | 33 | 4%p |

신규 5명의 적중 충전은 고정형입니다. 피격 충전은 Frost Reaper/Shadow Clone/Void Walker 5%p, Blood Apostle 6%p, Iron Wall 7%p입니다. 일반 기존 직업의 적중 충전은 실제 HP 피해 ×0.10%p, 자연 충전은 초당 1.2%p입니다.
니세모노를 원거리 평타 36 피해로 계산하면 전체 평균은 5.7838%p입니다.
