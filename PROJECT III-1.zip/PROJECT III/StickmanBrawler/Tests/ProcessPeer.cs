using System;
using System.Diagnostics;
using System.Threading;
using StickmanBrawler.Core;
using StickmanBrawler.Online;
public static class ProcessPeer
{
 public static int Run(string[] args)
 {
  bool host=args[0]=="--host";int port=int.Parse(args[1]);var wire=host?TcpRoomTransport.Host(port):TcpRoomTransport.Join("127.0.0.1",port);
  using(var session=new RoomSession(wire,host))
  {
   if(host){Console.WriteLine("PORT "+wire.Port);Console.Out.Flush();}
   var watch=Stopwatch.StartNew();double last=watch.Elapsed.TotalSeconds;bool setup=false,ready=false;int rounds=0;float lastX=0;
   while(watch.Elapsed.TotalSeconds<15)
   {
    double now=watch.Elapsed.TotalSeconds;session.Pump((float)(now-last));last=now;
    if(session.State==RoomState.Closed){Console.Error.WriteLine(session.Status);return 2;}
    if(session.State==RoomState.Lobby&&!setup){session.Choose(host?0:5);if(host)session.SetStage(3);setup=true;}
    if(session.State==RoomState.Lobby&&setup&&!ready&&watch.Elapsed.TotalSeconds>1){session.SetReady(true);ready=true;}
    if(session.State==RoomState.Playing&&session.View!=null)
    {
     session.Capture(new Controls(host?1:-1,false,true,false,false,false));rounds++;
     if(session.View.Phase==Phase.Fight)lastX=session.View.Players[1].Pos.x;
     if(watch.Elapsed.TotalSeconds>5)
     {
      if(session.Match!=1||session.View.Phase!=Phase.Fight||session.View.HitSerial<=0||session.View.Players[0].HP+session.View.Players[1].HP>=1900){Console.Error.WriteLine("No synchronized combat: phase="+session.View.Phase+" hits="+session.View.HitSerial+" hp="+session.View.Players[0].HP+"/"+session.View.Players[1].HP);return 3;}
      Console.WriteLine((host?"HOST":"CLIENT")+" PASS match="+session.Match+" tick="+session.View.CombatTick+" hits="+session.View.HitSerial+" x="+lastX+" hp="+session.View.Players[0].HP+"/"+session.View.Players[1].HP);
      if(host)Thread.Sleep(400);return 0;
     }
    }
    Thread.Sleep(2);
   }
   Console.Error.WriteLine("Process peer timed out: "+session.Status);return 1;
  }
 }
}
