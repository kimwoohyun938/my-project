"""Static checks only. Does not compile or execute C#.
Requires: pip install tree-sitter tree-sitter-c-sharp
"""
from pathlib import Path
import json
import re
from tree_sitter import Language, Parser
import tree_sitter_c_sharp

root=Path(__file__).resolve().parents[1]
parser=Parser(Language(tree_sitter_c_sharp.language()))
checks=[]
def check(name,ok,detail=''):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
    if not ok: raise AssertionError(f'{name}: {detail}')
def walk(n):
    yield n
    for c in n.children:yield from walk(c)
files=list(root.rglob('*.cs'))
methods={}
errors=[]
for p in files:
    data=p.read_bytes();tree=parser.parse(data)
    for node in walk(tree.root_node):
        if node.type=='ERROR' or node.is_missing:errors.append(f'{p.relative_to(root)}:{node.start_point}')
        if node.type=='method_declaration':
            name=node.child_by_field_name('name')
            if name:methods[data[name.start_byte:name.end_byte].decode()]=data[node.start_byte:node.end_byte].decode()
check('C# grammar parses all source files',not errors,f'{len(files)} files; '+str(errors))
roster=json.loads((root/'Docs/roster.json').read_text())
check('26 unique playable jobs',len(roster)==26 and len({r[0] for r in roster})==26)
expected={r[0] for r in roster}
types=(root/'Assets/StickmanBrawler/Runtime/Core/Types.cs').read_text()
enum=re.search(r'enum Job\s*{([^}]+)}',types).group(1)
check('Job IDs and data have identical order',[s.strip() for s in enum.split(',')]==[r[0] for r in roster])
for method in ['Skill1','Skill2','Ultimate']:
    cases=set(re.findall(r'case Job\.(\w+)',methods[method]))
    check(f'{method}: all 26 jobs have a branch',cases==expected,str(sorted(expected-cases)))
check('Basic attack has shared fallback','default:Melee(f,d);' in methods['Basic'])
for row in roster:
    check('Stat validity '+row[0],all(float(x)>0 for x in row[2:8]))
manifest=json.loads((root/'Packages/manifest.json').read_text())
check('Required audio and GUI modules listed',all(k in manifest['dependencies'] for k in ['com.unity.modules.audio','com.unity.modules.imgui']))
scene=root/'Assets/Scenes/Arena.unity'
meta=scene.with_suffix('.unity.meta').read_text()
guid=re.search(r'guid: (\w+)',meta).group(1)
build=(root/'ProjectSettings/EditorBuildSettings.asset').read_text()
check('Build scene path and GUID agree',scene.is_file() and str(scene.relative_to(root)) in build and guid in build)
check('Legacy input backend enabled','activeInputHandler: 0' in (root/'ProjectSettings/ProjectSettings.asset').read_text())
check('Runtime bootstrap declared','RuntimeInitializeOnLoadMethod' in (root/'Assets/StickmanBrawler/Runtime/BrawlerApp.cs').read_text())
check('No unfinished implementation markers',not any(re.search(r'NotImplementedException|TODO|FIXME',p.read_text()) for p in files))
check('Core has no Unity namespace dependency',not any('UnityEngine' in p.read_text() for p in (root/'Assets/StickmanBrawler/Runtime/Core').glob('*.cs')))
report={'kind':'static source validation; NOT compilation or runtime tests','checks':checks,'passed':len(checks),'csharp_files':len(files),'runtime_tests_executed':False,'unity_build_executed':False}
(root/'Docs/static_validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({'static_checks_passed':len(checks),'csharp_files':len(files),'runtime_tests_executed':False,'unity_build_executed':False},indent=2))
