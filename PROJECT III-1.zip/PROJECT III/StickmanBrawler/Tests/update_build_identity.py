"""Regenerate the peer compatibility fingerprint after changing combat/network code."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
runtime=root/'Assets/StickmanBrawler/Runtime'
files=sorted(list((runtime/'Core').glob('*.cs'))+[p for p in (runtime/'Online').glob('*.cs') if p.name!='BuildIdentity.cs'])
hash=hashlib.sha256()
for p in files:
    hash.update(str(p.relative_to(root)).encode());hash.update(p.read_bytes())
value=hash.hexdigest()
(runtime/'Online/BuildIdentity.cs').write_text('namespace StickmanBrawler.Online { public static class BuildIdentity { public const string Value="'+value+'"; } }\n')
print(value)
