"""Static source/package audit. Does not compile C# or run Unity.
Requires: pip install tree-sitter tree-sitter-c-sharp
Run from any directory: python Tests/validate_static.py
"""
from pathlib import Path
import re,json,csv,uuid,sys,hashlib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
root=Path(__file__).resolve().parents[1]
core=root/'Assets/StickmanBrawler/Runtime/Core'
checks=[]
def ck(name,passed):
 checks.append({'check':name,'passed':bool(passed)})
 if not passed: raise AssertionError(name)
p=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 cursor=n.walk()
 while True:
  node=cursor.node
  if node.is_named:yield node
  if cursor.goto_first_child():continue
  while not cursor.goto_next_sibling():
   if not cursor.goto_parent():return
parsed={}
for file in sorted(root.rglob('*.cs')):
 print("Parsing "+file.name,flush=True)
 tree=p.parse(file.read_bytes());parsed[file]=tree
 ck('C# grammar: '+str(file.relative_to(root)),not tree.root_node.has_error)
 for node in walk(tree.root_node):
  if node.type=='switch_body':
   cases=[s.text.decode().split(':')[0].strip() for section in node.named_children for s in section.named_children if s.type=='case_switch_label']
   ck('Unique switch labels: '+file.name+':'+str(node.start_point.row+1),len(cases)==len(set(cases)))
 if 'Assets' in file.relative_to(root).parts:
  meta=Path(str(file)+'.meta')
  if not meta.exists():meta.write_text('fileFormatVersion: 2\nguid: '+uuid.uuid5(uuid.NAMESPACE_URL,'stickman-arsenal/'+str(file.relative_to(root))).hex+'\nMonoImporter:\n  externalObjects: {}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {instanceID: 0}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n')
types=(core/'Types.cs').read_text();roster=(core/'Roster.cs').read_text();world=(core/'World.cs').read_text();combat=(core/'Combat.cs').read_text();balance=(core/'BalanceV2.cs').read_text();abilities=(core/'Abilities.cs').read_text();ults=(core/'Ultimates.cs').read_text();ui=(root/'Assets/StickmanBrawler/Runtime/BrawlerUI.cs').read_text()
jobs=[x.strip() for x in re.search(r'public enum Job \{([^}]+)\}',types).group(1).split(',')]
entries=[]
for line in roster.splitlines():
 if 'new Definition(Job.' not in line:continue
 args=next(csv.reader([line.strip()[len('new Definition('):].removesuffix(',').removesuffix(')')]))
 entries.append({'id':len(entries),'job':args[0][4:],'korean':args[1],'hp':float(args[2].rstrip('f')),'speed':float(args[3].rstrip('f')),'basic_damage':float(args[4].rstrip('f')),'basic_interval':float(args[5].rstrip('f')),'q_cooldown':float(args[6].rstrip('f')),'e_cooldown':float(args[7].rstrip('f')),'role':args[8],'q':args[9],'e':args[10],'r':args[11]})
ck('55 roster entries in enum order',[e['job'] for e in entries]==jobs and len(jobs)==55)
for e in entries:ck('Positive base stats: '+e['job'],all(e[k]>0 for k in ['hp','speed','basic_damage','basic_interval','q_cooldown','e_cooldown']))
(root/'ROSTER.json').write_text(json.dumps({'version':'2.4.1','note':'Base numbers; see change notes for passives, multi-hit basics, transformations and mitigation.','fighters':entries},ensure_ascii=False,indent=2)+'\n')
art=json.loads((root/'WEAPON_CATALOG.json').read_text())
ck('55 matching weapon entries',[a['job'] for a in art]==jobs)
ck('Six selectable arenas','public const int Count=6;' in types and '(stage+1)%Arena.Count' in (root/'Assets/StickmanBrawler/Runtime/BrawlerModesUI.cs').read_text())
ck('56 selection buttons fit six rows','int row=i/10,col=i%10' in ui and (len(jobs)//10)==5)
ck('No runtime R timer gate','f.Gauge>=100' in world and not re.search(r'f\.UltAt\s*<=\s*Time',world))
ck('Compatibility R cooldown always zero','UltimateCooldown(Fighter f) { return 0; }' in (core/'Expansion.cs').read_text())
ck('R HUD no timer','float[] cds={f.QAt,f.EAt,0}' in ui)
ck('Closed map KO exemption','!Arena.Closed' in world and 'ClampArena(f)' in world)
ck('Lancer split recall/throw timings','Time+3' in balance and 'f.QAt=pickup?Time:Time+4' in balance)
ck('Current/maximum HP damage uses impact state','victim.HP*h.CurrentPercent+victim.MaxHP*h.MaximumPercent' in combat)
ck('100Hz hit budget','Rules.Dt*rate/.01f' in world and 'while(f.RapidBudget>=1)' in world)
ck('No division by zero for fully slowed attacks','if(rate<=.00001f)' in world)
ck('Copied delayed actions retain kit and scale','Run=()=>WithKit(f,kit,scale,action)' in world)
ck('Scoped copied kit restores identity','finally{f.Job=previous;f.CopyScale=old;}' in balance)
ck('Health definition remains native','Roster.Get(NativeJob)' in types)
ck('Reflection gauge reward','victim.Gauge+5+DealtGauge(source,h,returned)' in combat)
ck('Projectile knockback reduction','h.Projectile?.65f:1' in combat)
ck('Doom bypasses one-hit shield','BypassOneHitShield=true' in world)
ck('V2 render hook before generic effects',ui.index('DrawV2Effect(e,p,k,c)')<ui.index('DrawClarityEffect(e,p,k,c)'))
ck('Correct limb transform retained','GUI.matrix=previousMatrix*Matrix4x4.TRS' in ui)
ck('Version label','v2.4.1' in (root/'Assets/StickmanBrawler/Runtime/BrawlerModesUI.cs').read_text())
for job in jobs[-6:]:
 ck('New job basic / Q / E branches: '+job,abilities.count('case Job.'+job+':')==3)
 ck('New job ultimate branch: '+job,ults.count('case Job.'+job+':')==1)
# Verify references on common statically-known combat variables.
members={}
for node in walk(parsed[core/'Types.cs'].root_node):
 if node.type!='class_declaration':continue
 name=node.child_by_field_name('name').text.decode();names=set()
 for member in node.child_by_field_name('body').named_children:
  if member.type=='field_declaration':
   for sub in walk(member):
    if sub.type=='variable_declarator':names.add(sub.child_by_field_name('name').text.decode())
  elif member.type in ['method_declaration','property_declaration']:names.add(member.child_by_field_name('name').text.decode())
 members[name]=names
refs=[];methods=set();calls=[]
for file,tree in parsed.items():
 if file.parent!=core or file.name in ['Types.cs','Roster.cs','WeaponArt.cs']:continue
 for node in walk(tree.root_node):
  if node.type=='method_declaration':methods.add(node.child_by_field_name('name').text.decode())
  if node.type=='invocation_expression':
   fun=node.child_by_field_name('function')
   if fun and fun.type=='identifier':calls.append((file.name,fun.text.decode()))
  if node.type!='member_access_expression':continue
  receiver=node.child_by_field_name('expression');name=node.child_by_field_name('name')
  if receiver is None or name is None:continue
  receiver=receiver.text.decode();name=name.text.decode()
  kind='Fighter' if receiver in ['f','source','victim','target','enemy','owner','foe'] else 'Hit' if receiver in ['h','hit','reflected'] else None
  if kind and name not in members[kind] and name not in ['x','y']:refs.append((file.name,receiver,name))
ck('Known fighter/hit member references resolve',not refs)
ck('Core unqualified method calls resolve',not [(f,m) for f,m in calls if m not in methods and m not in ['action','body','Equals']])
guids=[]
for file in (root/'Assets').rglob('*.meta'):
 match=re.search(r'^guid: ([a-f0-9]{32})$',file.read_text(),re.M)
 ck('Valid asset GUID: '+str(file.relative_to(root)),match is not None)
 if match:guids.append(match.group(1))
ck('No duplicate asset GUIDs',len(guids)==len(set(guids)))
ck('Scene included',(root/'Assets/Scenes/Arena.unity').is_file())
ck('Target editor version','6000.3.14f1' in (root/'ProjectSettings/ProjectVersion.txt').read_text())
ck('Package version','bundleVersion: 2.4.1' in (root/'ProjectSettings/ProjectSettings.asset').read_text())
ck('NET harness includes all regression partials','Tests/*.cs' in (root/'Tests/StickmanBrawler.Tests.csproj').read_text())
ck('V2 regression suite is wired','V2Tests();' in (root/'Assets/StickmanBrawler/Tests/Regression.cs').read_text())
ck('Fortune probability intervals exact','value<1f/77f?2:value<1f/77f+1f/7f?1:0' in (core/'FortuneDino.cs').read_text())
timing=(core/'TimingCyber.cs').read_text()
ck('Timing tests wired','TimingCyberTests();' in (root/'Assets/StickmanBrawler/Tests/Regression.cs').read_text())
ck('Timing Q one tick and E three ticks','CombatTick-r.Tick<=1' in timing and 'CombatTick-c.Tick<=3' in timing)
ck('Canceled callbacks filtered','CastCanceled(s.CastId)' in world)
ck('Canceled effects filtered','CastCanceled(e.CastId)' in combat)
ck('Per-slot lock gates Q E R',all('f.SlotLockedUntil['+str(i)+']<=Time' in world for i in [1,2,3]))
ck('Cyber code names retained',all('"'+name+'"' in timing for name in ['using','void','for','private','static','Error','return']))
ck('Cyber marks reset','Array.Clear(CyberMarks,0,CyberMarks.Length)' in types)
ck('Cyber movement slow applied once','float speed=f.Def.Speed*ChronoRate(f);' in world and 'rate*=ColdAttackRate(f)*ChronoRate(f)*(f.CyberSlowUntil>Time?.7f:1);' in world)
ck('Exact strict execution thresholds','target.HP<150' in timing and 'target.HP<300' in timing)
ck('New VFX dispatch hooked','DrawTimingCyberEffect(e,p,k)' in ui and 'DrawTimingCyberFighter(f,p,k)' in ui)
modes=(core/'MatchModes.cs').read_text()
ck('Ten battle modes',all(name in modes for name in ['Classic','Continuous','TrainingFixed','TrainingRespawn','Teams','FreeForAll','Draft','ThreeWay','BossRaid','DpsEvent']))
ck('Mode regression suite wired','ModeTests();' in (root/'Assets/StickmanBrawler/Tests/Regression.cs').read_text())
ck('Four-player status storage','new int[4]' in types and 'new int[2]' not in types)
ck('Per-target area hits','e.PlayerHits[hitTarget.Id]' in combat)
ck('Team damage rejected','!Opponents(h.Owner,victim.Id)' in combat)
ck('Relay used-job rejection','usedJobs[player,(int)job]' in modes)
ck('Selection freezes simulation','Phase==Phase.Finished||NeedsSelection' in world)
ck('HUD for four fighters','void MultiHUD()' in (root/'Assets/StickmanBrawler/Runtime/BrawlerModesUI.cs').read_text())
ck('Special mode regression suite wired','SpecialModeTests();' in (root/'Assets/StickmanBrawler/Tests/Regression.cs').read_text())
ck('Three human keysets isolated','ThreeHumans?trioKeys[player,key]:keys[player,key]' in (root/'Assets/StickmanBrawler/Runtime/BrawlerModesUI.cs').read_text())
report={'version':'2.4.1','release_kind':'source distribution / runtime verification pending','static_checks_passed':len(checks),'checks':checks,'csharp_compilation_run':False,'runtime_regressions_run':False,'unity_play_run':False,'windows_build_run':False,'weapon_sheet_visually_inspected':True}
evidence_path=root/'RUNTIME_VALIDATION.json'
if evidence_path.is_file():
 evidence=json.loads(evidence_path.read_text())
 fresh=all((root/name).is_file() and hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in evidence['source_hashes'].items())
 report['runtime_evidence_matches_source']=fresh
 if fresh:
  report['csharp_compilation_run']=True;report['csharp_compilation_scope']='Core + Online + regression tests; Unity assemblies excluded'
  report['runtime_regressions_run']=True;report['engine_assertions_passed']=evidence['assertions_passed'];report['online_assertions_passed']=evidence.get('online_assertions_passed',0);report['guard_input_assertions_passed']=evidence.get('guard_input_assertions_passed',0)
  report['release_kind']='source distribution / engine tested / Unity integration pending'
(root/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
hashes={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((root/'Assets').rglob('*')) if f.is_file()}
(root/'SOURCE_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps({'static_checks_passed':len(checks),'fighters':len(jobs),'csharp_compiled':report['csharp_compilation_run'],'runtime_tested':report['runtime_regressions_run']}))
